/* Player (the night watchman) and his dog Rex */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U, R = U.R;
  const PL = NW.player = {
    x: 396, y: 184, r: 5.5, hp: 100, alive: true, battery: 100, cd: 0, invuln: 0, hurtT: 0, walk: 0, stepT: 0,
    mvx: 0, mvy: 0, face: 0, aim: Math.PI / 2, moving: false, kick: 0, fireAng: 0, respawn: 0, recoil: null, ox: 0, oy: 0
  };
  PL.maxHp = () => 100 + 20 * NW.store.p.upg.hp;
  PL.speed = () => 74 * (1 + 0.07 * NW.store.p.upg.speed);
  PL.lightRange = () => (110 + 14 * NW.store.p.upg.range) * (NW.weapons.defs[NW.store.p.weapon].lightBonus || 1);
  PL.reset = function (hp) {
    PL.x = 396; PL.y = 186; PL.alive = true; PL.hp = hp === undefined ? PL.maxHp() : Math.min(hp, PL.maxHp());
    PL.invuln = 1.5; PL.cd = 0; PL.recoil = null; PL.respawn = 0;
  };

  PL.hurt = function (dmg, sx, sy) {
    if (!PL.alive || PL.invuln > 0 || NW.game.state !== 'play') return false;
    PL.hp -= dmg; PL.invuln = 0.7; PL.hurtT = 0.35;
    NW.audio.sfx('hurt'); NW.game.shake(4);
    NW.fx.burst(PL.x, PL.y - 8, 7, ['#d62a3a', '#ff6a5a'], 80, 0.4);
    NW.fx.text(PL.x, PL.y - 22, '-' + Math.round(dmg), '#ff5a5a');
    if (sx !== undefined) { const a = Math.atan2(PL.y - sy, PL.x - sx); PL.recoil = { x: Math.cos(a) * 60, y: Math.sin(a) * 60 }; }
    if (PL.hp <= 0) { PL.hp = 0; PL.alive = false; PL.respawn = 5; NW.audio.sfx('lose'); NW.game.onPlayerDeath(); }
    return true;
  };
  PL.heal = function (n) { PL.hp = Math.min(PL.maxHp(), PL.hp + n); };
  PL.useMedkit = function () {
    const inv = NW.store.p.inv;
    if (!PL.alive) return;
    if (inv.medkit <= 0) { NW.ui.toast('No medkits', 'bad'); NW.audio.sfx('error'); return; }
    if (PL.hp >= PL.maxHp()) { NW.ui.toast('Health is full', 'bad'); NW.audio.sfx('error'); return; }
    inv.medkit--; PL.heal(PL.maxHp() * 0.5); NW.audio.sfx('heal');
    NW.fx.text(PL.x, PL.y - 24, '+HP', '#7dff7a'); NW.fx.burst(PL.x, PL.y - 10, 10, ['#7dff7a', '#fff'], 50, 0.7);
    NW.ui.refresh();
  };
  PL.useBattery = function () {
    const inv = NW.store.p.inv;
    if (!PL.alive) return;
    if (inv.battery <= 0) { NW.ui.toast('No batteries', 'bad'); NW.audio.sfx('error'); return; }
    if (PL.battery > 85) { NW.ui.toast('Battery is still charged', 'bad'); NW.audio.sfx('error'); return; }
    inv.battery--; PL.battery = Math.min(100, PL.battery + 60); NW.audio.sfx('battery');
    NW.fx.text(PL.x, PL.y - 24, '+BATTERY', '#ffd23a'); NW.ui.refresh();
  };

  PL.update = function (dt, c) {
    PL.cd = Math.max(0, PL.cd - dt); PL.invuln = Math.max(0, PL.invuln - dt); PL.hurtT = Math.max(0, PL.hurtT - dt); PL.kick = Math.max(0, PL.kick - dt * 8);
    if (!PL.alive) { PL.respawn -= dt; if (PL.respawn <= 0) NW.game.respawnPlayer(); return; }
    let mx = c.mx, my = c.my; const ml = Math.hypot(mx, my);
    if (ml > 1) { mx /= ml; my /= ml; }
    const sp = PL.speed();
    let vx = mx * sp, vy = my * sp;
    if (PL.recoil) { vx += PL.recoil.x; vy += PL.recoil.y; PL.recoil.x *= 0.82; PL.recoil.y *= 0.82; if (Math.abs(PL.recoil.x) + Math.abs(PL.recoil.y) < 3) PL.recoil = null; }
    NW.farm.move(PL, vx * dt, vy * dt, PL.r);
    PL.moving = ml > 0.1;
    if (PL.moving) {
      PL.mvx = mx; PL.mvy = my; PL.walk += dt * 9 * (sp / 74);
      PL.face = Math.abs(my) > Math.abs(mx) ? (my > 0 ? 0 : 3) : (mx > 0 ? 2 : 1);
      PL.stepT -= dt; if (PL.stepT <= 0) { PL.stepT = 0.3 / (sp / 74); NW.audio.sfx('step'); }
    }
    PL.aim = c.aim;
    // flashlight battery drain
    PL.battery = Math.max(0, PL.battery - dt * 0.9);
    if (PL.battery < 15 && PL.battery > 0 && !PL.lowWarn) { PL.lowWarn = true; NW.ui.toast('Flashlight battery low! (F)', 'bad'); }
    if (PL.battery > 25) PL.lowWarn = false;
    if (c.fire) NW.weapons.fire(PL, PL.aim);
  };

  const NAVY = '#2c3270', NAVY2 = '#1a1e4c', NAVYH = '#4a54a8', SKIN = '#e6b080';
  PL.draw = function (g, t) {
    if (!PL.alive) return;
    if (PL.invuln > 0 && Math.floor(t * 20) % 2 === 0 && PL.hurtT <= 0) { return; }
    const x = Math.round(PL.x), y = Math.round(PL.y);
    const hurt = PL.hurtT > 0 && Math.floor(t * 30) % 2 === 0;
    const body = hurt ? '#ffffff' : NAVY, body2 = hurt ? '#e8e8ff' : NAVY2, hl = hurt ? '#fff' : NAVYH;
    const ph = Math.sin(PL.walk), step = PL.moving ? Math.round(ph * 2) : 0, bob = PL.moving ? (Math.abs(ph) > 0.5 ? -1 : 0) : 0;
    U.ell(g, 'rgba(0,0,0,0.4)', x, y + 1, 7, 3);
    const a = PL.aim, sector = Math.abs(Math.cos(a)) > Math.abs(Math.sin(a)) ? (Math.cos(a) > 0 ? 2 : 1) : (Math.sin(a) > 0 ? 0 : 3);
    // legs (follow movement direction)
    const lateral = PL.face === 1 || PL.face === 2;
    if (lateral && PL.moving) { R(g, OUT, x - 4 + step, y - 6, 4, 7); R(g, body2, x - 3 + step, y - 6, 2, 6); R(g, OUT, x + 1 - step, y - 6, 4, 7); R(g, body2, x + 1 - step, y - 6, 2, 6); }
    else { R(g, OUT, x - 5, y - 6 + (step > 0 ? 1 : 0), 4, 7); R(g, body2, x - 4, y - 6 + (step > 0 ? 1 : 0), 2, 6); R(g, OUT, x + 1, y - 6 + (step < 0 ? 1 : 0), 4, 7); R(g, body2, x + 2, y - 6 + (step < 0 ? 1 : 0), 2, 6); }
    R(g, '#0a0a14', x - 4 + (lateral ? step : 0), y, 3, 1); R(g, '#0a0a14', x + 1 - (lateral ? step : 0), y, 3, 1);
    // flashlight arm/hand position
    const hx = x + Math.round(Math.cos(a) * 7), hy = y - 9 + bob + Math.round(Math.sin(a) * 4), kick = Math.round(PL.kick * 2);
    const fx = hx - Math.round(Math.cos(a) * kick), fy = hy - Math.round(Math.sin(a) * kick);
    // torso
    R(g, OUT, x - 6, y - 15 + bob, 12, 10); R(g, body, x - 5, y - 14 + bob, 10, 8); R(g, hl, x - 5, y - 14 + bob, 3, 8); R(g, body2, x + 3, y - 14 + bob, 2, 8);
    R(g, '#c8a030', x - 5, y - 8 + bob, 10, 1); R(g, '#ffe28a', x - 1, y - 8 + bob, 2, 1);
    if (sector === 0) { R(g, '#ffd23a', x + 1, y - 12 + bob, 2, 2); }
    // free arm
    R(g, OUT, x + (sector === 2 ? -7 : 5), y - 13 + bob, 3, 7); R(g, body, x + (sector === 2 ? -6 : 6), y - 12 + bob, 1, 5);
    R(g, OUT, x - (sector === 1 ? -5 : 8), y - 13 + bob, 3, 7);
    // flashlight + holding arm
    U.line(g, OUT, x + (hx - x) * 0.4, y - 11 + bob, hx, hy, 3); U.line(g, body, x + (hx - x) * 0.4, y - 11 + bob, hx, hy, 1);
    R(g, SKIN, fx - 1, fy - 1, 3, 3);
    const ex = fx + Math.cos(a) * 5, ey = fy + Math.sin(a) * 5;
    U.line(g, OUT, fx, fy, ex, ey, 4); U.line(g, '#4a4e6e', fx, fy, ex, ey, 2);
    const lx = Math.round(ex + Math.cos(a) * 2), ly = Math.round(ey + Math.sin(a) * 2);
    R(g, '#fff6c0', lx - 1, ly - 1, 3, 3); R(g, '#fff', lx, ly, 1, 1);
    // head
    const hy2 = y - 20 + bob;
    R(g, OUT, x - 5, hy2 - 1, 10, 9);
    if (sector === 3) { R(g, NAVY2, x - 4, hy2, 8, 7); R(g, NAVY, x - 4, hy2, 8, 3); R(g, SKIN, x - 3, hy2 + 6, 6, 1); }
    else if (sector === 0) { R(g, SKIN, x - 4, hy2 + 2, 8, 5); R(g, NAVY, x - 4, hy2, 8, 3); R(g, '#10122a', x - 5, hy2 + 2, 10, 2); R(g, OUT, x - 3, hy2 + 5, 1, 2); R(g, OUT, x + 2, hy2 + 5, 1, 2); R(g, '#fff', x - 3, hy2 + 5, 1, 1); R(g, '#fff', x + 2, hy2 + 5, 1, 1); }
    else { const d = sector === 2 ? 1 : -1; R(g, SKIN, x - 4, hy2 + 2, 8, 5); R(g, NAVY, x - 4, hy2, 8, 3); R(g, NAVY2, x - 4 - (d > 0 ? 1 : 0), hy2 + 2, 4, 4); R(g, '#10122a', d > 0 ? x : x - 6, hy2 + 2, 6, 2); R(g, OUT, x + d * 2, hy2 + 5, 1, 2); R(g, '#fff', x + d * 2, hy2 + 5, 1, 1); }
    R(g, hurt ? '#fff' : '#4a54a8', x - 3, hy2, 2, 1); R(g, '#c8a030', x - 1, hy2 + 1, 2, 1);
  };
  const OUT = '#0e0a14';

  /* ================= Rex, the dog ================= */
  const DOG = NW.dog = { x: 380, y: 196, vx: 0, vy: 0, dir: 1, walk: 0, cd: 0, bark: 0, r: 4, face: 1, wag: 0 };
  DOG.reset = function () { DOG.x = PL.x - 20; DOG.y = PL.y + 8; DOG.vx = DOG.vy = 0; };
  DOG.update = function (dt) {
    DOG.cd = Math.max(0, DOG.cd - dt); DOG.walk += dt * 11; DOG.bark = Math.max(0, DOG.bark - dt); DOG.wag += dt;
    let tx = PL.x + (DOG.x < PL.x ? -26 : 26), ty = PL.y + 8, speed = 70, target = null, best = 1e9;
    NW.enemies.list.forEach(e => {
      if (e.dead || e.type === 'ghost') return;
      const d = U.dist(e.x, e.y, PL.x, PL.y), dd = U.dist(e.x, e.y, DOG.x, DOG.y);
      if (d < 150 && dd < best) { best = dd; target = e; }
    });
    if (target && NW.game.state === 'play') {
      tx = target.x; ty = target.y; speed = 96;
      if (best < 12 + target.r && DOG.cd <= 0) {
        DOG.cd = 0.75; DOG.bark = 0.3;
        NW.enemies.damage(target, 6 + NW.game.night, Math.atan2(target.y - DOG.y, target.x - DOG.x), 30, { dog: true });
        if (Math.random() < 0.5) NW.audio.sfx('bark');
      }
    }
    const dx = tx - DOG.x, dy = ty - DOG.y, d = Math.hypot(dx, dy);
    if (d > (target ? 8 : 14)) {
      const s = d > 90 ? speed * 1.6 : speed;
      DOG.vx = dx / d * s; DOG.vy = dy / d * s;
      NW.farm.move(DOG, DOG.vx * dt, DOG.vy * dt, DOG.r);
      DOG.moving = true;
      if (Math.abs(DOG.vx) > Math.abs(DOG.vy)) { DOG.face = DOG.vx > 0 ? 1 : -1; DOG.vert = 0; } else DOG.vert = DOG.vy > 0 ? 1 : -1;
    } else DOG.moving = false;
    if (d > 260) { DOG.x = PL.x - 12; DOG.y = PL.y + 6; }
  };
  DOG.draw = function (g, t) {
    const x = Math.round(DOG.x), y = Math.round(DOG.y), w = DOG.moving ? Math.sin(DOG.walk) : 0, f = DOG.face;
    const TAN = '#c88a3a', TAN2 = '#e0a850', DARK = '#3a2412', BLK = '#1a120c';
    U.ell(g, 'rgba(0,0,0,0.4)', x, y + 1, 9, 3);
    if (DOG.vert && DOG.moving) {
      const v = DOG.vert;
      R(g, OUT, x - 5, y - 11, 10, 13); R(g, TAN, x - 4, y - 10, 8, 11); R(g, DARK, x - 3, y - 9, 6, 7);
      R(g, TAN, x - 4, y - 3 + Math.round(w * 2), 2, 4); R(g, TAN, x + 2, y - 3 - Math.round(w * 2), 2, 4);
      if (v > 0) { R(g, OUT, x - 4, y - 16, 8, 8); R(g, TAN2, x - 3, y - 15, 6, 6); R(g, BLK, x - 2, y - 11, 4, 3); R(g, OUT, x - 3, y - 14, 1, 1); R(g, OUT, x + 2, y - 14, 1, 1); R(g, TAN, x - 5, y - 17, 2, 3); R(g, TAN, x + 3, y - 17, 2, 3); }
      else { R(g, OUT, x - 4, y - 16, 8, 6); R(g, TAN, x - 3, y - 15, 6, 4); R(g, TAN, x - 5, y - 17, 2, 3); R(g, TAN, x + 3, y - 17, 2, 3); R(g, DARK, x - 1, y, 2, 4 + Math.round(Math.sin(DOG.wag * 14))); }
      return;
    }
    // side view
    [[-7, 1], [-4, 0], [3, 0], [6, 1]].forEach((l, i) => { const sw = DOG.moving ? Math.round(Math.sin(DOG.walk + (i % 2) * 3.14) * 2) : 0; R(g, OUT, x + l[0] * f - 1 + sw, y - 4, 3, 6); R(g, i % 2 ? TAN : DARK, x + l[0] * f + sw, y - 4, 1, 5); });
    U.ell(g, OUT, x, y - 7, 9, 5); U.ell(g, TAN, x, y - 7, 8, 4); U.ell(g, DARK, x - 1 * f, y - 9, 5, 2); U.ell(g, TAN2, x + 3 * f, y - 6, 3, 2);
    const hx = x + 9 * f, hy = y - 11 + (DOG.moving ? Math.round(Math.sin(DOG.walk * 2)) : 0);
    R(g, OUT, hx - 4, hy - 3, 8, 8); R(g, TAN2, hx - 3, hy - 2, 6, 6); R(g, BLK, hx + (f > 0 ? 1 : -5), hy + 1, 4, 3); R(g, OUT, hx - f, hy - 1, 1, 1);
    R(g, DARK, hx - 3 * f - 1, hy - 5, 3, 4);
    if (DOG.bark > 0) { R(g, '#fff', hx + 3 * f, hy + 3, 1, 1); R(g, '#ff6a6a', hx + 2 * f, hy + 3, 1, 1); }
    const tw = Math.round(Math.sin(DOG.wag * 12) * 2);
    R(g, OUT, x - 10 * f - 1, y - 11 + tw, 3, 5); R(g, DARK, x - 10 * f, y - 10 + tw, 1, 4);
  };
})();
