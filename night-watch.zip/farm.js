/* Farm: map layout, collisions, navigation flow-field, structures (fences, barricades, traps, turrets) */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U, W = NW.W, H = NW.H;
  const SP = NW.spr;
  const F = NW.farm = {};
  const CELL = 8, NX = W / CELL, NY = H / CELL;
  F.CELL = CELL; F.NX = NX; F.NY = NY;
  F.solids = []; F.base = []; F.lights = []; F.structs = []; F.patches = []; F.cows = []; F.crows = [];
  F.statics = []; F.overhead = []; F.garlands = [];
  F.barn = { x: 306, y: 14, w: 180, h: 132, door: { x: 372, y: 144, w: 50, h: 14 }, cx: 396, cy: 150 };
  F.shop = { x: 466, y: 240, r: 34 };
  F.spawns = {
    S: { x: 392, y: 428 }, W: { x: 4, y: 308 }, E: { x: 764, y: 308 }, NW: { x: 42, y: 4 }, NE: { x: 722, y: 4 }
  };
  F.paths = [
    { x: 366, y: 140, w: 58, h: 300 }, { x: 0, y: 297, w: 372, h: 26 }, { x: 420, y: 297, w: 348, h: 26 }
  ];
  F.build = { x1: 12, y1: 12, x2: 756, y2: 424 };

  F.STYPES = {
    fence: { name: 'Fence', cost: 10, hp: 80, icon: 'fence', solid: true, desc: 'Cheap wall. Monsters must chew through.' },
    barricade: { name: 'Barricade', cost: 30, hp: 260, icon: 'barricade', solid: true, desc: 'Strong spiked wall. Hurts attackers.' },
    trap: { name: 'Spike Trap', cost: 40, hp: 1, icon: 'trap', solid: false, uses: 14, desc: 'Damages and slows monsters.' },
    turret: { name: 'Pumpkin Sentry', cost: 150, hp: 110, icon: 'turret', solid: true, desc: 'Automatic defender. Shoots monsters.' }
  };
  F.dims = function (type, rot) {
    if (type === 'fence') return rot ? { w: 8, h: 16 } : { w: 16, h: 8 };
    if (type === 'barricade') return { w: 16, h: 16 };
    if (type === 'trap') return { w: 16, h: 16 };
    return { w: 14, h: 12 };
  };

  /* ---------------- spatial grid for collision ---------------- */
  const BK = 32, GX = Math.ceil(W / BK), GY = Math.ceil(H / BK);
  let grid = [], stamp = 0;
  F.rebuildGrid = function () {
    grid = new Array(GX * GY); for (let i = 0; i < grid.length; i++) grid[i] = [];
    const add = r => {
      const x0 = U.clamp(Math.floor(r.x / BK), 0, GX - 1), x1 = U.clamp(Math.floor((r.x + r.w) / BK), 0, GX - 1);
      const y0 = U.clamp(Math.floor(r.y / BK), 0, GY - 1), y1 = U.clamp(Math.floor((r.y + r.h) / BK), 0, GY - 1);
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) grid[y * GX + x].push(r);
    };
    F.solids.forEach(add);
    F.structs.forEach(s => { if (s.solid) add(s.rect); });
  };
  const nearOut = [];
  F.near = function (x, y, r) {
    nearOut.length = 0; stamp++;
    const x0 = U.clamp(Math.floor((x - r) / BK), 0, GX - 1), x1 = U.clamp(Math.floor((x + r) / BK), 0, GX - 1);
    const y0 = U.clamp(Math.floor((y - r) / BK), 0, GY - 1), y1 = U.clamp(Math.floor((y + r) / BK), 0, GY - 1);
    for (let gy = y0; gy <= y1; gy++) for (let gx = x0; gx <= x1; gx++) {
      const a = grid[gy * GX + gx]; if (!a) continue;
      for (let i = 0; i < a.length; i++) { const q = a[i]; if (q._q !== stamp) { q._q = stamp; nearOut.push(q); } }
    }
    return nearOut;
  };
  function resolve(e, r, out) {
    const rects = F.near(e.x, e.y, r + 1);
    for (let i = 0; i < rects.length; i++) {
      const rc = rects[i];
      const cx = U.clamp(e.x, rc.x, rc.x + rc.w), cy = U.clamp(e.y, rc.y, rc.y + rc.h);
      const dx = e.x - cx, dy = e.y - cy, d2 = dx * dx + dy * dy;
      if (d2 < r * r) {
        if (d2 > 0.0001) { const d = Math.sqrt(d2), p = r - d; e.x += dx / d * p; e.y += dy / d * p; }
        else {
          const l = e.x - rc.x, rr = rc.x + rc.w - e.x, t = e.y - rc.y, b = rc.y + rc.h - e.y, m = Math.min(l, rr, t, b);
          if (m === l) e.x = rc.x - r; else if (m === rr) e.x = rc.x + rc.w + r; else if (m === t) e.y = rc.y - r; else e.y = rc.y + rc.h + r;
        }
        if (out && rc.s) out.push(rc.s);
      }
    }
  }
  F.move = function (e, dx, dy, r, out) {
    e.x += dx; resolve(e, r, out);
    e.y += dy; resolve(e, r, out);
    e.x = U.clamp(e.x, r, W - r); e.y = U.clamp(e.y, r, H - r);
  };
  F.blockedAt = function (x, y, r) {
    const rects = F.near(x, y, r + 1);
    for (let i = 0; i < rects.length; i++) {
      const rc = rects[i], cx = U.clamp(x, rc.x, rc.x + rc.w), cy = U.clamp(y, rc.y, rc.y + rc.h);
      if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r) return true;
    }
    return false;
  };
  F.lineClear = function (x0, y0, x1, y1) {
    const d = Math.hypot(x1 - x0, y1 - y0), n = Math.ceil(d / 6);
    for (let i = 1; i < n; i++) { const t = i / n; if (F.blockedAt(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, 1)) return false; }
    return true;
  };

  /* ---------------- navigation (Dijkstra flow-field to the barn door) ---------------- */
  const baseCost = new Float32Array(NX * NY), cost = new Float32Array(NX * NY), dist = new Float32Array(NX * NY);
  F.next = new Int32Array(NX * NY).fill(-1); F.navDirty = true;
  function markRect(arr, r, fn) {
    const x0 = Math.max(0, Math.floor(r.x / CELL)), x1 = Math.min(NX - 1, Math.floor((r.x + r.w - 0.01) / CELL));
    const y0 = Math.max(0, Math.floor(r.y / CELL)), y1 = Math.min(NY - 1, Math.floor((r.y + r.h - 0.01) / CELL));
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) fn(y * NX + x, arr);
  }
  F.buildNavBase = function () {
    baseCost.fill(1);
    F.paths.forEach(p => markRect(baseCost, p, i => { baseCost[i] = 0.7; }));
    const blocked = new Uint8Array(NX * NY);
    F.solids.forEach(r => markRect(baseCost, r, i => { blocked[i] = 1; }));
    for (let y = 0; y < NY; y++) for (let x = 0; x < NX; x++) {
      const i = y * NX + x;
      if (blocked[i]) { baseCost[i] = Infinity; continue; }
      let near = false;
      for (let dy = -1; dy <= 1 && !near; dy++) for (let dx = -1; dx <= 1; dx++) {
        const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= NX || ny >= NY) continue;
        if (blocked[ny * NX + nx]) { near = true; break; }
      }
      if (near) baseCost[i] += 2.2;
    }
  };
  // binary heap
  const hk = [], hv = [];
  function hpush(k, v) { let i = hk.length; hk.push(k); hv.push(v); while (i > 0) { const p = (i - 1) >> 1; if (hk[p] <= k) break; hk[i] = hk[p]; hv[i] = hv[p]; i = p; } hk[i] = k; hv[i] = v; }
  function hpop() {
    const rv = hv[0], k = hk.pop(), v = hv.pop(), n = hk.length;
    if (n) { let i = 0; for (;;) { let c = i * 2 + 1; if (c >= n) break; if (c + 1 < n && hk[c + 1] < hk[c]) c++; if (hk[c] >= k) break; hk[i] = hk[c]; hv[i] = hv[c]; i = c; } hk[i] = k; hv[i] = v; }
    return rv;
  }
  F.computeNav = function () {
    cost.set(baseCost);
    F.structs.forEach(s => { if (s.solid) markRect(cost, s.rect, i => { if (cost[i] < Infinity) cost[i] += 10 + s.hp / 18; }); });
    dist.fill(Infinity); hk.length = 0; hv.length = 0;
    const d = F.barn.door;
    markRect(dist, { x: d.x, y: d.y, w: d.w, h: d.h }, i => { if (cost[i] < Infinity) { dist[i] = 0; hpush(0, i); } });
    while (hk.length) {
      const i = hpop(), di = dist[i], x = i % NX, y = (i / NX) | 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= NX || ny >= NY) continue;
        const j = ny * NX + nx; if (cost[j] === Infinity) continue;
        if (dx && dy && (cost[y * NX + nx] === Infinity || cost[ny * NX + x] === Infinity)) continue;
        const nd = di + cost[j] * (dx && dy ? 1.414 : 1);
        if (nd < dist[j]) { dist[j] = nd; hpush(nd, j); }
      }
    }
    for (let y = 0; y < NY; y++) for (let x = 0; x < NX; x++) {
      const i = y * NX + x; let best = -1, bd = dist[i];
      if (cost[i] === Infinity && dist[i] === Infinity) { F.next[i] = -1; continue; }
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= NX || ny >= NY) continue;
        const j = ny * NX + nx; if (cost[j] === Infinity) continue;
        if (dx && dy && (cost[y * NX + nx] === Infinity || cost[ny * NX + x] === Infinity)) continue;
        if (dist[j] < bd) { bd = dist[j]; best = j; }
      }
      F.next[i] = best;
    }
    F.dist = dist; F.navDirty = false;
  };
  // desired direction for an entity at x,y; returns {x,y} unit vector (reused object)
  const dirOut = { x: 0, y: 1, atGoal: false };
  F.flowDir = function (x, y) {
    const cx = U.clamp((x / CELL) | 0, 0, NX - 1), cy = U.clamp((y / CELL) | 0, 0, NY - 1), i = cy * NX + cx;
    let n = F.next[i];
    if (n < 0) { const d = F.barn; const dx = d.cx - x, dy = d.cy - y, l = Math.hypot(dx, dy) || 1; dirOut.x = dx / l; dirOut.y = dy / l; dirOut.atGoal = true; return dirOut; }
    // look 2 steps ahead for smoother paths
    let n2 = F.next[n]; if (n2 < 0) n2 = n;
    const tx = (n2 % NX) * CELL + CELL / 2, ty = ((n2 / NX) | 0) * CELL + CELL / 2;
    const dx = tx - x, dy = ty - y, l = Math.hypot(dx, dy) || 1;
    dirOut.x = dx / l; dirOut.y = dy / l; dirOut.atGoal = false; return dirOut;
  };

  /* ---------------- structures ---------------- */
  let sid = 1;
  F.addStruct = function (type, x, y, rot, opts) {
    const T = F.STYPES[type], d = F.dims(type, rot);
    const s = { id: sid++, type, x, y, w: d.w, h: d.h, rot: rot ? 1 : 0, hp: T.hp, max: T.hp, solid: T.solid, orig: false, uses: T.uses || 0, cd: 0, hit: 0, ang: 1.5, t: Math.random() * 6 };
    s.rect = { x, y, w: d.w, h: d.h, s };
    s.sy = y + d.h;
    if (opts) Object.assign(s, opts);
    F.structs.push(s);
    F.rebuildGrid(); F.navDirty = true; F.sortStatics();
    return s;
  };
  F.removeStruct = function (s) {
    const i = F.structs.indexOf(s); if (i < 0) return;
    F.structs.splice(i, 1); F.rebuildGrid(); F.navDirty = true; F.sortStatics();
  };
  F.damageStruct = function (s, dmg) {
    if (!s || s.dead) return false;
    if (s.type === 'trap') return false;
    s.hp -= dmg; s.hit = 0.15;
    if (s.hp <= 0) {
      s.dead = true; F.removeStruct(s);
      NW.fx && NW.fx.burst(s.x + s.w / 2, s.y + s.h / 2, 12, ['#7a4a28', '#9a6436', '#4e2e1a', '#b8814a'], 90, 0.7);
      NW.audio.sfx('wood');
      return true;
    }
    return false;
  };
  F.rectFor = function (type, x, y, rot) { const d = F.dims(type, rot); return { x, y, w: d.w, h: d.h }; };
  F.snap = function (type, mx, my, rot) {
    const d = F.dims(type, rot);
    return { x: Math.round((mx - d.w / 2) / 8) * 8, y: Math.round((my - d.h / 2) / 8) * 8 };
  };
  F.canPlace = function (type, x, y, rot, px, py) {
    const r = F.rectFor(type, x, y, rot), b = F.build;
    if (r.x < b.x1 || r.y < b.y1 || r.x + r.w > b.x2 || r.y + r.h > b.y2) return 'Out of bounds';
    const d = F.barn.door;
    if (r.x < d.x + d.w + 6 && r.x + r.w > d.x - 6 && r.y < d.y + d.h + 14 && r.y + r.h > d.y - 4) return 'Keep the door clear';
    for (const s of F.solids) if (r.x < s.x + s.w && r.x + r.w > s.x && r.y < s.y + s.h && r.y + r.h > s.y) return 'Blocked';
    for (const s of F.structs) if (r.x < s.x + s.w && r.x + r.w > s.x && r.y < s.y + s.h && r.y + r.h > s.y) return 'Blocked';
    if (px !== undefined) {
      const cx = U.clamp(px, r.x, r.x + r.w), cy = U.clamp(py, r.y, r.y + r.h);
      if (U.dist(px, py, cx, cy) < 8 && F.STYPES[type].solid) return 'Player in the way';
      if (U.dist(px, py, r.x + r.w / 2, r.y + r.h / 2) > 150) return 'Too far away';
    }
    if (NW.enemies && F.STYPES[type].solid) {
      for (const e of NW.enemies.list) {
        if (e.fly) continue;
        const cx = U.clamp(e.x, r.x, r.x + r.w), cy = U.clamp(e.y, r.y, r.y + r.h);
        if (U.dist(e.x, e.y, cx, cy) < e.r + 1) return 'Monster in the way';
      }
    }
    return null;
  };

  /* ---------------- drawing statics ---------------- */
  F.sortStatics = function () {
    const arr = F.base.slice();
    F.structs.forEach(s => arr.push({ sy: s.y + s.h, s }));
    arr.sort((a, b) => a.sy - b.sy);
    F.statics = arr;
  };
  F.drawStruct = function (g, s, t, ghost) {
    const T = s.type, hurt = s.hp < s.max * 0.5 && T !== 'trap';
    let ox = 0, oy = 0; if (s.hit > 0) { ox = (Math.random() - 0.5) * 2; }
    const x = Math.round(s.x + ox), y = Math.round(s.y + oy);
    if (T === 'fence') {
      if (s.rot) g.drawImage(hurt ? SP.fenceVh : SP.fenceV, x - 1, y - 8);
      else g.drawImage(hurt ? SP.fenceHh : SP.fenceH, x, y - 8);
    } else if (T === 'barricade') g.drawImage(hurt ? SP.barricadeH : SP.barricade, x - 2, y - 6);
    else if (T === 'trap') { g.drawImage(s.cd > 0 || s.trig > 0 ? SP.trapDown : SP.trapUp, x - 1, y - 2); }
    else if (T === 'turret') {
      g.drawImage(SP.turretBase, x - 3, y - 16);
      const hx = x + 7, hy = y - 8, a = s.ang || 0;
      U.line(g, '#0e0a14', hx, hy, hx + Math.cos(a) * 9, hy + Math.sin(a) * 9, 4);
      U.line(g, '#6a6a7e', hx, hy, hx + Math.cos(a) * 9, hy + Math.sin(a) * 9, 2);
    }
    if (!ghost && s.hp < s.max && T !== 'trap' && s.hp > 0) {
      const w = Math.max(8, s.w), bx = Math.round(s.x + s.w / 2 - w / 2), by = Math.round(s.y - 11 - (T === 'turret' ? 6 : 0));
      g.fillStyle = '#000'; g.fillRect(bx - 1, by - 1, w + 2, 4);
      g.fillStyle = s.hp / s.max > 0.5 ? '#6ad24a' : '#e8a22a'; g.fillRect(bx, by, Math.round(w * s.hp / s.max), 2);
    }
  };
  F.drawStatic = function (g, it, t) { if (it.s) F.drawStruct(g, it.s, t); else it.draw(g, t); };

  /* ---------------- map construction ---------------- */
  function addProp(spr, x, y, o) {
    // x center, y base (bottom). o: {solid:[ox,oy,w,h]} relative to base-center
    o = o || {};
    const it = { sy: y + (o.sortOff || 0), draw: o.draw || ((g) => { g.drawImage(spr, Math.round(x - spr.width / 2), Math.round(y - spr.height)); }) };
    F.base.push(it);
    if (o.solid) F.solids.push({ x: x + o.solid[0], y: y + o.solid[1], w: o.solid[2], h: o.solid[3] });
    return it;
  }
  function addLight(x, y, r, rgb, int, flick, ph) { const l = { x, y, r, rgb, int: int || 1, flick: flick || 0, ph: ph !== undefined ? ph : Math.random() * 9, base: true }; F.lights.push(l); return l; }

  function fenceLineH(x1, x2, y, skip) {
    for (let x = x1; x < x2; x += 16) { if (skip && skip(x)) continue; const s = F.addStructRaw('fence', x, y, 0); s.orig = true; }
  }
  function fenceLineV(x, y1, y2, skip) {
    for (let y = y1; y < y2; y += 16) { if (skip && skip(y)) continue; const s = F.addStructRaw('fence', x, y, 1); s.orig = true; }
  }
  F.addStructRaw = function (type, x, y, rot) {
    const T = F.STYPES[type], d = F.dims(type, rot);
    const s = { id: sid++, type, x, y, w: d.w, h: d.h, rot: rot ? 1 : 0, hp: T.hp * 0.55, max: T.hp * 0.55, solid: T.solid, orig: false, uses: 0, cd: 0, hit: 0, t: 0 };
    s.rect = { x, y, w: d.w, h: d.h, s }; F.structs.push(s); return s;
  };

  F.init = function () {
    SP.build();
    F.solids.length = 0; F.base.length = 0; F.lights.length = 0; F.structs.length = 0; F.patches.length = 0; F.cows.length = 0; F.crows.length = 0; F.overhead.length = 0; F.garlands.length = 0;
    const rnd = U.rng(2026);

    /* big buildings */
    const b = F.barn;
    F.base.push({ sy: 146, draw: g => g.drawImage(SP.barn, 301, 6) });
    F.solids.push({ x: b.x, y: b.y, w: b.w, h: b.h });
    F.base.push({ sy: 118, draw: g => g.drawImage(SP.silo, 498, 0) });
    F.solids.push({ x: 503, y: 26, w: 48, h: 92 });
    F.base.push({ sy: 118, draw: (g, t) => {
      g.drawImage(SP.windTower, 233, 24);
      const hx = 261, hy = 40, rot = t * 0.35;
      for (let k = 0; k < 4; k++) {
        const a = rot + k * Math.PI / 2, ex = hx + Math.cos(a) * 34, ey = hy + Math.sin(a) * 34;
        U.line(g, '#0e0a14', hx, hy, ex, ey, 4); U.line(g, '#6a4a2e', hx, hy, ex, ey, 2);
        for (let q = 8; q < 34; q += 5) {
          const px = hx + Math.cos(a) * q, py = hy + Math.sin(a) * q, nx = -Math.sin(a), ny = Math.cos(a);
          U.line(g, '#cdb98f', px + nx * 2, py + ny * 2, px + nx * 6, py + ny * 6, 1);
        }
      }
      U.disc(g, '#0e0a14', hx, hy, 3); U.disc(g, '#8a8aa0', hx, hy, 2);
    } });
    F.solids.push({ x: 244, y: 86, w: 34, h: 32 });
    F.base.push({ sy: 150, draw: g => g.drawImage(SP.well, 108, 92) });
    F.solids.push({ x: 114, y: 120, w: 44, h: 30 });
    F.base.push({ sy: 244, draw: g => g.drawImage(SP.shed, 598, 162) });
    F.solids.push({ x: 604, y: 192, w: 78, h: 50 });
    // shop stall
    F.base.push({ sy: 252, draw: g => g.drawImage(SP.stall, 436, 196) });
    F.solids.push({ x: 440, y: 228, w: 56, h: 22 });
    // water trough
    F.base.push({ sy: 262, draw: g => g.drawImage(SP.trough, 650, 246) });
    F.solids.push({ x: 652, y: 252, w: 36, h: 10 });

    /* carts, hay, barrels, crates */
    addProp(SP.cart[1], 616, 140, { solid: [-24, -18, 48, 16] });
    addProp(SP.hay[0], 662, 128, { solid: [-12, -12, 24, 12] });
    addProp(SP.hay[1], 684, 118, { solid: [-12, -10, 24, 10] });
    addProp(SP.hay[0], 304, 166, { solid: [-12, -12, 24, 12] });
    addProp(SP.hay[1], 328, 170, { solid: [-12, -10, 24, 10] });
    addProp(SP.barrel, 282, 152, { solid: [-6, -8, 12, 8] });
    addProp(SP.barrel, 276, 168, { solid: [-6, -8, 12, 8] });
    addProp(SP.barrel, 294, 142, { solid: [-6, -8, 12, 8] });
    addProp(SP.barrel, 290, 206, { solid: [-6, -8, 12, 8] });
    addProp(SP.crate, 312, 244, { solid: [-7, -9, 14, 9] });
    addProp(SP.crate, 330, 234, { solid: [-7, -9, 14, 9] });
    addProp(SP.crate, 306, 226, { solid: [-7, -9, 14, 9] });
    addProp(SP.crate, 520, 130, { solid: [-7, -9, 14, 9] });
    addProp(SP.cart[2], 584, 388, { solid: [-24, -18, 48, 16] });
    addProp(SP.jack, 316, 150, {});
    addProp(SP.barrel, 82, 120, { solid: [-6, -8, 12, 8] });
    addProp(SP.barrel, 98, 112, { solid: [-6, -8, 12, 8] });
    addProp(SP.barrel, 60, 348, { solid: [-6, -8, 12, 8] });

    /* jack-o-lanterns with lights */
    [[88, 112], [338, 370], [446, 370], [236, 134], [690, 100], [520, 114]].forEach(p => {
      addProp(SP.jack, p[0], p[1], {});
      addLight(p[0], p[1] - 6, 38, '255,150,40', 0.85, 0.3);
    });

    /* scarecrow + pumpkin field */
    addProp(SP.scarecrow, 172, 226, { solid: [-4, -6, 8, 6] });
    addLight(172, 205, 42, '255,170,50', 0.9, 0.35);
    const rows = [[84, 196], [124, 196], [214, 196], [254, 196], [84, 232], [124, 238], [214, 238], [254, 232], [100, 262], [148, 264], [198, 264], [244, 262]];
    rows.forEach((p, i) => {
      const patch = { x: p[0], y: p[1] + 8, ready: true, s: i };
      F.patches.push(patch);
      addProp(SP.pumpkin, p[0], p[1] + 8, { draw: g => {
        if (patch.ready) g.drawImage(SP.pumpkin, p[0] - 7, p[1] - 4);
        else { U.R(g, '#2a1c12', p[0] - 5, p[1] + 4, 10, 3); U.R(g, '#4a7a2a', p[0] - 1, p[1] + 2, 3, 3); }
      } });
    });

    /* lantern posts (with lights & garland anchor points) */
    const posts = [[62, 186], [276, 262], [510, 200], [700, 270], [96, 336], [622, 322], [334, 320], [454, 320], [240, 90], [160, 118], [694, 100], [60, 78], [724, 332]];
    posts.forEach((p, i) => {
      const spr = SP.post;
      addProp(spr, p[0], p[1], { solid: [-2, -3, 4, 3], draw: g => g.drawImage(spr, Math.round(p[0] - 6), Math.round(p[1] - spr.height + 2)) });
      addLight(p[0] + 6, p[1] - spr.height + 10, 74, '255,160,50', 1, i % 4 === 0 ? 0.9 : 0.35);
    });

    /* barn lantern above the door + candles beside it */
    F.base.push({ sy: 147, draw: g => {
      U.R(g, '#0e0a14', 392, 88, 4, 8); U.R(g, '#0e0a14', 389, 94, 10, 12); U.R(g, '#1a1220', 390, 95, 8, 10); U.R(g, '#ffb53a', 391, 97, 6, 6); U.R(g, '#fff0a0', 393, 98, 2, 3);
    } });
    addLight(394, 100, 110, '255,170,60', 1.15, 0.5);
    addLight(396, 128, 70, '255,130,40', 0.75, 0.6);
    [[362, 154], [430, 154], [356, 160], [436, 160]].forEach((p, i) => {
      F.base.push({ sy: p[1], draw: (g, t) => {
        U.R(g, '#0e0a14', p[0] - 2, p[1] - 7, 5, 8); U.R(g, '#e8e0c0', p[0] - 1, p[1] - 6, 3, 6); U.R(g, '#b8b090', p[0] + 1, p[1] - 6, 1, 6);
        const f = 1 + Math.round(Math.sin(t * 9 + i * 2)); U.R(g, '#ff9a2e', p[0] - 1, p[1] - 9 - f, 3, 3 + f); U.R(g, '#fff0a0', p[0], p[1] - 8 - f, 1, 2);
      } });
      addLight(p[0], p[1] - 8, 40, '255,170,70', 0.8, 0.8);
    });

    /* gate pillars & arch */
    const pillar = (x) => addProp(null, x, 334, { solid: [-7, -16, 14, 16], draw: g => {
      U.R(g, '#0e0a14', x - 8, 304, 16, 30); U.R(g, SP.P.stone2, x - 7, 305, 14, 28); U.R(g, SP.P.stone, x - 7, 305, 5, 28); U.R(g, SP.P.stone3, x - 7, 305, 14, 2);
      for (let y = 311; y < 332; y += 7) U.R(g, '#3a384e', x - 7, y, 14, 1);
    } });
    pillar(353); pillar(435);
    F.overhead.push({ draw: g => {
      U.R(g, '#0e0a14', 338, 290, 112, 12); U.R(g, SP.P.wood2, 339, 291, 110, 10); U.R(g, SP.P.woodL, 339, 291, 110, 2); U.R(g, SP.P.wood3, 339, 298, 110, 3);
      U.R(g, '#0e0a14', 392, 301, 4, 9); U.R(g, '#0e0a14', 388, 308, 12, 13); U.R(g, '#1a1220', 389, 309, 10, 11); U.R(g, '#ffb53a', 391, 311, 6, 7); U.R(g, '#fff0a0', 393, 313, 2, 3);
    } });
    addLight(394, 314, 90, '255,170,60', 1.1, 0.5);

    /* graveyard */
    [[650, 372, 0], [678, 392, 1], [716, 362, 2], [742, 402, 0], [700, 410, 1], [664, 418, 2], [738, 346, 1]].forEach(p => {
      addProp(SP.grave[p[2]], p[0], p[1], { solid: [-5, -5, 10, 5] });
    });
    addProp(SP.skeleton, 712, 384, {});
    addProp(SP.skull, 66, 372, {}); addProp(SP.skull, 420, 330, {});
    // iron graveyard fence (decor)
    F.base.push({ sy: 345, draw: g => { for (let x = 630; x < 768; x += 6) { U.R(g, '#0e0a14', x, 328, 2, 18); U.R(g, '#2a2838', x, 330, 1, 15); U.R(g, '#0e0a14', x - 1, 327, 4, 3); } U.R(g, '#1a1826', 630, 336, 138, 2); } });

    /* crows */
    [[162, 70], [642, 346]].forEach(p => F.crows.push({ x: p[0], y: p[1], t: Math.random() * 9 }));
    F.base.push({ sy: 400, draw: (g, t) => { F.crows.forEach(c => { g.drawImage(SP.crow, Math.round(c.x - 6), Math.round(c.y - 10 + (Math.sin(t * 2 + c.t) > 0.92 ? -1 : 0))); }); } });

    /* cows (animated) */
    for (let i = 0; i < 2; i++) F.cows.push({ x: 560 + i * 60, y: 236 + i * 14, tx: 560, ty: 240, dir: 1, t: Math.random() * 9, wait: Math.random() * 3, head: 0 });
    F.base.push({ sy: 0, cows: true, draw: () => { } });

    /* trees: forest ring */
    const T = SP.tree, TB = SP.treeBig;
    function tree(x, y, big, i) {
      const spr = big ? TB[i % TB.length] : T[Math.floor(rnd() * T.length)];
      addProp(spr, x, y, { solid: [-6, -5, 12, 5], draw: (g, t) => {
        const sw = Math.sin(t * 0.6 + x * 0.05) * 0.0; g.drawImage(spr, Math.round(x - spr.width / 2 + sw), Math.round(y - spr.height));
      } });
    }
    const gapY = (y) => y > 276 && y < 340;
    for (let y = 26; y < 432; y += 21) {
      const jy = y + rnd() * 8;
      if (!gapY(jy)) { tree(8 + rnd() * 10, jy + 10, false); tree(748 + rnd() * 10, jy + 10, false); }
    }
    for (let x = 0; x < 768; x += 24) {
      const jx = x + rnd() * 10;
      const top = (jx > 26 && jx < 62) || (jx > 700 && jx < 744) || (jx > 80 && jx < 200) || (jx > 296 && jx < 560);
      if (!top) tree(jx, 22 + rnd() * 12, false);
      if (!(jx > 340 && jx < 440) && !(jx > 70 && jx < 270 && false)) tree(jx, 428 + rnd() * 4, false);
    }
    for (let x = 270; x < 700; x += 38) { if (x > 480 && x < 560) continue; tree(x + rnd() * 10, 46, false); }
    tree(14, 96, true, 0); tree(752, 150, true, 1); tree(748, 394, true, 1); tree(14, 388, true, 0); tree(26, 232, false); tree(742, 236, false);
    for (let i = 0; i < 6; i++) tree(90 + i * 40 + rnd() * 20, 352 + rnd() * 70, false);
    // pond & dock are painted in bg; pond is a solid
    F.solids.push({ x: 98, y: 372, w: 150, h: 36 }); F.solids.push({ x: 112, y: 364, w: 120, h: 12 }); F.solids.push({ x: 112, y: 406, w: 120, h: 10 });

    /* fences */
    fenceLineH(60, 300, 66);
    fenceLineH(494, 706, 66);
    fenceLineV(58, 66, 150); fenceLineV(704, 66, 150);
    // pumpkin field
    fenceLineH(60, 284, 168); fenceLineH(60, 284, 278);
    fenceLineV(58, 168, 284); fenceLineV(280, 168, 284, y => y >= 224 && y < 248);
    // animal pen
    fenceLineH(506, 706, 174); fenceLineH(506, 706, 280);
    fenceLineV(504, 174, 288, y => y >= 224 && y < 256); fenceLineV(702, 174, 288);
    // farm perimeter at the gate
    fenceLineH(24, 330, 326); fenceLineH(442, 744, 326);
    fenceLineV(24, 326, 342); fenceLineV(740, 326, 342);

    F.rebuildGrid(); F.buildNavBase(); F.computeNav();
    F.sortStatics();
  };

  F.saveStructs = function () { return F.structs.map(s => ({ t: s.type, x: s.x, y: s.y, r: s.rot, hp: Math.round(s.hp), m: s.max, o: s.orig ? 1 : 0, u: s.uses })); };
  F.loadStructs = function (list) {
    F.structs.length = 0;
    list.forEach(d => {
      const T = F.STYPES[d.t]; if (!T) return; const dm = F.dims(d.t, d.r);
      const s = { id: sid++, type: d.t, x: d.x, y: d.y, w: dm.w, h: dm.h, rot: d.r ? 1 : 0, hp: d.hp, max: d.m, solid: T.solid, orig: !!d.o, uses: d.u || 0, cd: 0, hit: 0, ang: 1.5, t: Math.random() * 6 };
      s.rect = { x: d.x, y: d.y, w: dm.w, h: dm.h, s }; s.sy = d.y + dm.h; F.structs.push(s);
    });
    F.rebuildGrid(); F.computeNav(); F.sortStatics();
  };

  /* repair/restore fences each night (cheap bonus) */
  F.healAll = function (frac) { F.structs.forEach(s => { if (s.type !== 'trap') s.hp = Math.min(s.max, s.hp + s.max * frac); }); };

  /* cows */
  F.updateCows = function (dt) {
    F.cows.forEach(c => {
      c.t += dt; c.wait -= dt;
      if (c.wait <= 0) { c.tx = 530 + Math.random() * 150; c.ty = 214 + Math.random() * 56; c.wait = 3 + Math.random() * 6; if (Math.random() < 0.15) NW.audio.sfx('moo'); }
      const dx = c.tx - c.x, dy = c.ty - c.y, d = Math.hypot(dx, dy);
      if (d > 3) { c.x += dx / d * 8 * dt; c.y += dy / d * 8 * dt; c.dir = dx > 0 ? 1 : -1; c.walk = true; } else c.walk = false;
      c.head = Math.sin(c.t * (c.walk ? 3 : 1.2)) * (c.walk ? 1 : 0.5);
    });
  };
  F.drawCow = function (g, c) {
    const x = Math.round(c.x), y = Math.round(c.y), d = c.dir, leg = c.walk ? Math.floor(c.t * 4) % 2 : 0;
    U.ell(g, 'rgba(0,0,0,0.35)', x, y + 6, 12, 3);
    const R = U.R;
    R(g, '#0e0a14', x - 11 * d - (d < 0 ? 0 : 0), y - 8, 1, 1);
    // legs
    [-8, -4, 4, 8].forEach((lx, i) => { R(g, '#0e0a14', x + lx - 1, y + 1, 3, 7 + ((i + leg) % 2)); R(g, '#d8d4cc', x + lx, y + 1, 1, 6 + ((i + leg) % 2)); });
    // body
    U.ell(g, '#0e0a14', x, y - 2, 12, 7); U.ell(g, '#e8e4dc', x, y - 3, 11, 6);
    U.ell(g, '#2a2630', x - 3, y - 4, 4, 3); U.ell(g, '#2a2630', x + 5, y - 1, 3, 2);
    // head
    const hx = x + 12 * d, hy = y - 5 + Math.round(c.head);
    R(g, '#0e0a14', hx - 5, hy - 4, 10, 9); R(g, '#e8e4dc', hx - 4, hy - 3, 8, 7); R(g, '#e8a8a0', hx + (d > 0 ? 1 : -4), hy + 1, 4, 3);
    R(g, '#2a2630', hx - 4, hy - 3, 4, 3); R(g, '#0e0a14', hx + d * 1, hy - 1, 1, 1);
    R(g, '#d8d4cc', hx - 6 * (d > 0 ? 1 : -1) - 1, hy - 5, 2, 2); R(g, '#d8d4cc', hx + 5 * (d > 0 ? 1 : -1) - 1, hy - 5, 2, 2);
    // tail
    R(g, '#2a2630', x - 12 * d, y - 6 + Math.round(Math.sin(c.t * 3)), 2, 5);
  };

  /* ---------------- painted background ---------------- */
  F.buildBg = function () {
    const [c, g] = U.mk(W, H), rnd = U.rng(77);
    const R = U.R;
    R(g, '#0b1022', 0, 0, W, H);
    // grass base
    R(g, '#35502a', 0, 0, W, H);
    for (let i = 0; i < 9000; i++) {
      const x = rnd() * W, y = rnd() * H, k = rnd();
      R(g, k < 0.35 ? '#2c4424' : k < 0.7 ? '#3e5e30' : k < 0.85 ? '#2a3d2c' : '#456834', x, y, 2, 2);
    }
    for (let i = 0; i < 1600; i++) {
      const x = rnd() * W, y = rnd() * H;
      R(g, '#5a8a40', x, y, 1, 3); R(g, '#5a8a40', x + 2, y + 1, 1, 2);
    }
    // dirt helper with rough edges
    function dirt(x, y, w, h, base, jag) {
      for (let yy = 0; yy < h; yy++) {
        const l = Math.round((rnd() - 0.5) * jag), r = Math.round((rnd() - 0.5) * jag);
        R(g, base, x + l, y + yy, w - l + r, 1);
      }
      for (let i = 0; i < w * h / 14; i++) { const k = rnd(); R(g, k < 0.4 ? '#4e3320' : k < 0.8 ? '#85603e' : '#9a7448', x + rnd() * w, y + rnd() * h, 2, 1); }
    }
    // soft paths
    F.paths.forEach(p => { dirt(p.x - 3, p.y, p.w + 6, p.h, '#5e4028', 7); dirt(p.x + 3, p.y, p.w - 6, p.h, '#6c4a2e', 5); });
    // wear near barn door
    for (let i = 0; i < 70; i++) R(g, '#3a2418', 366 + rnd() * 58, 146 + rnd() * 30, 3, 2);
    // pumpkin field soil
    dirt(64, 172, 214, 102, '#4a3220', 5);
    for (let y = 182; y < 270; y += 14) for (let x = 70; x < 270; x += 3) { if (rnd() < 0.9) R(g, '#5c4028', x, y, 3, 2); R(g, '#33201a', x, y + 3, 3, 1); }
    // pen straw
    dirt(512, 180, 188, 96, '#4e5a30', 6);
    for (let i = 0; i < 160; i++) R(g, '#c8a040', 516 + rnd() * 180, 184 + rnd() * 86, 4, 1);
    // graveyard ground
    for (let i = 0; i < 160; i++) { const x = 630 + rnd() * 138, y = 340 + rnd() * 92; R(g, rnd() < 0.5 ? '#2a3a2a' : '#1f2a26', x, y, 4, 3); }
    // pond
    U.ell(g, '#2a2a1c', 170, 390, 90, 36); U.ell(g, '#3a4a2a', 170, 389, 86, 33);
    U.ell(g, '#0c1a2a', 170, 390, 80, 29); U.ell(g, '#143048', 168, 388, 72, 24); U.ell(g, '#1c4460', 150, 384, 40, 12);
    for (let i = 0; i < 26; i++) R(g, '#3a7a9a', 100 + rnd() * 140, 372 + rnd() * 34, 6 + rnd() * 6, 1);
    [[120, 392], [200, 404], [210, 380]].forEach(p => { U.ell(g, '#2a6a30', p[0], p[1], 5, 3); R(g, '#143048', p[0] + 2, p[1] - 1, 3, 1); });
    // dock
    for (let i = 0; i < 6; i++) { R(g, '#0e0a14', 188, 362 + i * 6, 34, 6); R(g, i % 2 ? '#7a4a28' : '#8a5a32', 189, 363 + i * 6, 32, 4); }
    R(g, '#0e0a14', 186, 360, 4, 40); R(g, '#0e0a14', 220, 360, 4, 40);
    // sky patch & moon
    const sky = g.createLinearGradient(0, 0, 0, 52);
    sky.addColorStop(0, '#0a1030'); sky.addColorStop(1, '#2a2658');
    g.fillStyle = sky; g.fillRect(70, 0, 140, 50);
    for (let i = 0; i < 40; i++) R(g, '#cfd6ff', 72 + rnd() * 136, rnd() * 40, 1, 1);
    for (let i = 0; i < 6; i++) { g.globalAlpha = 0.5; U.ell(g, '#3a3a6a', 90 + rnd() * 100, 10 + rnd() * 30, 18 + rnd() * 14, 3); g.globalAlpha = 1; }
    g.globalAlpha = 0.18; U.disc(g, '#9ab0ff', 137, 26, 24); g.globalAlpha = 0.25; U.disc(g, '#cfd8ff', 137, 26, 19); g.globalAlpha = 1;
    U.disc(g, '#c9c4a6', 137, 26, 15); U.disc(g, '#e8e4c8', 136, 25, 14); U.disc(g, '#fffbe0', 134, 22, 8);
    [[130, 28, 3], [142, 22, 2], [138, 34, 2], [128, 20, 2]].forEach(p => U.disc(g, '#b8b498', p[0], p[1], p[2]));
    // leaves, bones, mushrooms
    for (let i = 0; i < 220; i++) {
      const x = rnd() * W, y = rnd() * H, k = rnd();
      R(g, k < 0.4 ? '#a8501a' : k < 0.7 ? '#7a3a1c' : '#c47a22', x, y, 2, 1);
    }
    for (let i = 0; i < 40; i++) { const x = 10 + rnd() * 740, y = 20 + rnd() * 400; R(g, '#2a2a38', x, y, 3, 2); R(g, '#4a4a60', x, y, 2, 1); }
    for (let i = 0; i < 14; i++) { const x = 20 + rnd() * 730, y = 30 + rnd() * 390; R(g, '#d8d0b8', x, y, 4, 1); R(g, '#d8d0b8', x, y + 1, 1, 1); R(g, '#d8d0b8', x + 3, y + 1, 1, 1); }
    // tall dark grass clumps
    for (let i = 0; i < 160; i++) { const x = rnd() * W, y = rnd() * H; R(g, '#22381f', x, y, 1, 4); R(g, '#1c2e1a', x + 1, y + 1, 1, 3); R(g, '#22381f', x + 2, y, 1, 4); }
    F.bg = c;
  };

  F.drawGarlands = function (g, t) {
    // glowing halloween string lights
    const strings = [[[304, 74], [396, 84], [488, 74]], [[347, 300], [394, 306], [438, 300]], [[62, 168], [172, 176], [282, 168]], [[508, 174], [606, 182], [704, 174]], [[24, 326], [130, 336], [236, 328]], [[552, 326], [650, 336], [738, 326]]];
    const cols = ['#ff9a2e', '#b45cff', '#7dff6a', '#ffd23a', '#ff5a3a'];
    strings.forEach((s, si) => {
      const a = s[0], m = s[1], b = s[2];
      const pts = [];
      for (let i = 0; i <= 18; i++) { const u = i / 18, x = (1 - u) * (1 - u) * a[0] + 2 * (1 - u) * u * m[0] + u * u * b[0], y = (1 - u) * (1 - u) * a[1] + 2 * (1 - u) * u * m[1] + u * u * b[1]; pts.push([x, y]); }
      for (let i = 0; i < pts.length - 1; i++) U.line(g, '#1a1220', pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], 1);
      for (let i = 1; i < pts.length; i += 2) {
        const on = Math.sin(t * 2.2 + i * 1.3 + si) > -0.6, col = cols[(i + si) % cols.length];
        if (on) { g.fillStyle = col; g.fillRect(Math.round(pts[i][0]) - 1, Math.round(pts[i][1]), 3, 3); g.fillStyle = '#fff'; g.fillRect(Math.round(pts[i][0]), Math.round(pts[i][1]), 1, 1); }
        else { g.fillStyle = '#3a3040'; g.fillRect(Math.round(pts[i][0]) - 1, Math.round(pts[i][1]), 3, 3); }
      }
    });
  };
  F.garlandLights = function (t, out) {
    // emit approximate additive colored glows for garlands (cheap: few points)
    const pts = [[330, 80, '255,150,60'], [396, 84, '190,100,255'], [460, 80, '255,200,60'], [394, 306, '255,160,60'], [172, 176, '125,255,106'], [606, 182, '255,150,60'], [130, 336, '190,100,255'], [650, 336, '255,200,60']];
    pts.forEach((p, i) => out.push({ x: p[0], y: p[1], r: 26, rgb: p[2], int: 0.35 + 0.15 * Math.sin(t * 2 + i) }));
  };
})();
