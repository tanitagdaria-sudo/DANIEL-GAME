/* UI: HUD, menus, shop, inventory, build bar, settings, touch controls (DOM, pixel style) */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U;
  const UI = NW.ui = { panel: null, cache: {} };
  const $ = (s, r) => (r || document).querySelector(s);
  const img = (name, cls) => '<img class="ic ' + (cls || '') + '" src="' + NW.spr.iconURL(name) + '" alt="">';
  UI.img = img;
  let root, toastBox;

  UI.init = function () {
    root = $('#ui');
    root.innerHTML = `
    <div id="hud" class="hidden">
      <div id="hud-top">
        <div class="pnl cell"><span id="h-coinic">${img('coin')}</span><span id="h-coins" class="num">0</span></div>
        <div class="pnl cell wide">${img('heart')}<div class="bar hp"><i id="h-hp"></i><b id="h-hptx"></b></div></div>
        <div class="pnl cell wide">${img('barn')}<div class="bar barn"><i id="h-barn"></i><b id="h-barntx"></b></div></div>
        <div class="pnl cell info"><span>NIGHT <em id="h-night">1</em></span><span>WAVE <em id="h-wave">1/2</em></span><span>ENEMIES <em id="h-en">0</em></span></div>
      </div>
      <div id="prep" class="pnl hidden"><span id="prep-tx"></span><button class="btn sm" data-act="startwave">START NOW [N]</button></div>
      <div id="boss" class="pnl hidden"><span id="boss-name">PUMPKIN KING</span><div class="bar bossbar"><i id="boss-hp"></i></div></div>
      <div id="prompt" class="hidden"></div>
      <div id="hud-bot">
        <div class="pnl cell stat" title="Flashlight battery">${img('battery')}<div class="bar bat"><i id="h-bat"></i></div><span class="num sm" id="h-batn">x0</span></div>
        <div id="hotbar" class="pnl"></div>
        <div class="pnl cell stat">${img('ammo')}<span class="num" id="h-ammo">0</span><span class="sep"></span>${img('medkit')}<span class="num sm" id="h-med">0</span></div>
      </div>
      <div id="hud-btns">
        <button class="btn" data-act="shop">SHOP <small>[T]</small></button>
        <button class="btn" data-act="inv">INVENTORY <small>[I]</small></button>
        <button class="btn" data-act="build">BUILD <small>[B]</small></button>
        <button class="btn" data-act="pause">PAUSE <small>[Esc]</small></button>
      </div>
      <div id="buildbar" class="pnl hidden"></div>
    </div>
    <div id="banner" class="hidden"><h1></h1><h2></h2></div>
    <div id="toasts"></div>
    <div id="touch" class="hidden">
      <div class="joy" id="joyL"><i></i></div><div class="joy" id="joyR"><i></i></div>
      <button class="tbtn" data-act="use" id="tb-e">E</button>
      <button class="tbtn" data-act="bat" id="tb-bat">F</button>
      <button class="tbtn" data-act="med" id="tb-med">H</button>
      <button class="tbtn" data-act="swap" id="tb-swap">Q</button>
      <button class="tbtn big hidden" data-act="place" id="tb-place">PLACE</button>
      <button class="tbtn hidden" data-act="rotate" id="tb-rot">R</button>
    </div>
    <div id="panels"></div>`;
    toastBox = $('#toasts');
    root.addEventListener('click', onClick);
    root.addEventListener('input', onInput);
    root.addEventListener('change', onInput);
    initTouch();
    UI.buildMenu();
    UI.fit();
    window.addEventListener('resize', UI.fit);
  };

  /* ---------- sizing (canvas letterbox) ---------- */
  UI.fit = function () {
    const cv = $('#game'), w = window.innerWidth, h = window.innerHeight;
    let s = Math.min(w / NW.W, h / NW.H);
    if (s > 2) s = Math.floor(s * 4) / 4;
    cv.style.width = Math.round(NW.W * s) + 'px'; cv.style.height = Math.round(NW.H * s) + 'px';
    document.documentElement.style.setProperty('--u', Math.max(0.55, Math.min(1.5, Math.min(w / 900, h / 560))));
    UI.updateTouchVisible();
  };

  /* ---------- toasts / banner / prompt ---------- */
  UI.toast = function (msg, kind) {
    if (!toastBox) return;
    const d = document.createElement('div'); d.className = 'toast ' + (kind || ''); d.textContent = msg;
    toastBox.appendChild(d);
    while (toastBox.children.length > 4) toastBox.removeChild(toastBox.firstChild);
    setTimeout(() => { d.classList.add('out'); setTimeout(() => d.remove(), 400); }, 2200);
  };
  let bannerT = 0;
  UI.banner = function (title, sub, cls, ms) {
    const b = $('#banner'); b.className = cls || ''; $('h1', b).textContent = title; $('h2', b).textContent = sub || '';
    void b.offsetWidth; b.classList.add('show');
    clearTimeout(bannerT); bannerT = setTimeout(() => { b.className = 'hidden'; }, ms || 2600);
  };
  UI.setPrompt = function (txt) {
    const p = $('#prompt'); if (UI.cache.prompt === txt) return; UI.cache.prompt = txt;
    if (txt) { p.textContent = txt; p.classList.remove('hidden'); } else p.classList.add('hidden');
  };
  UI.pulseCoins = function () { const c = $('#h-coinic'); if (!c) return; c.classList.remove('pulse'); void c.offsetWidth; c.classList.add('pulse'); };

  /* ---------- HUD refresh ---------- */
  const setTxt = (id, v) => { if (UI.cache[id] !== v) { UI.cache[id] = v; const e = document.getElementById(id); if (e) e.textContent = v; } };
  const setW = (id, pct) => { pct = Math.round(U.clamp(pct, 0, 100)); if (UI.cache['w' + id] !== pct) { UI.cache['w' + id] = pct; const e = document.getElementById(id); if (e) e.style.width = pct + '%'; } };
  UI.update = function () {
    const G = NW.game, p = NW.store.p, PL = NW.player;
    setTxt('h-coins', String(p.coins)); setTxt('h-night', String(G.night)); setTxt('h-wave', G.wave + '/' + G.waves);
    setTxt('h-en', String(G.enemiesLeft()));
    setW('h-hp', PL.hp / PL.maxHp() * 100); setTxt('h-hptx', Math.ceil(PL.hp) + '/' + PL.maxHp());
    setW('h-barn', G.barnHp / G.barnMax * 100); setTxt('h-barntx', Math.ceil(G.barnHp) + '/' + G.barnMax);
    setW('h-bat', PL.battery); setTxt('h-batn', 'x' + p.inv.battery);
    setTxt('h-ammo', String(p.inv.ammo)); setTxt('h-med', 'x' + p.inv.medkit);
    const prep = $('#prep');
    if (G.phase === 'prep' && G.state === 'play') { prep.classList.remove('hidden'); setTxt('prep-tx', 'PREPARE! ' + (G.wave === 1 ? 'Night ' + G.night : 'Wave ' + G.wave) + ' starts in ' + Math.ceil(G.prepT) + 's'); }
    else prep.classList.add('hidden');
    const boss = EN_boss();
    const bb = $('#boss');
    if (boss) { bb.classList.remove('hidden'); setW('boss-hp', boss.hp / boss.max * 100); } else bb.classList.add('hidden');
    UI.updateBuildHud();
    const hb = $('#hotbar'); const sig = NW.weapons.owned().join() + '|' + p.weapon;
    if (UI.cache.hb !== sig) { UI.cache.hb = sig; hb.innerHTML = NW.weapons.owned().map((id, i) => `<button class="slot ${p.weapon === id ? 'sel' : ''}" data-act="weapon:${id}">${img(NW.weapons.defs[id].icon)}<kbd>${i + 1}</kbd></button>`).join(''); }
    if (UI.panel === 'shop') UI.updateShopCoins();
  };
  function EN_boss() { return NW.enemies.list.find(e => e.d.boss && !e.dead); }
  UI.updateTouchVisible = function () {
    const t = $('#touch'); if (!t) return;
    const on = (NW.input.touchMode || NW.store.p.settings.touch) && NW.game && NW.game.state === 'play';
    t.classList.toggle('hidden', !on);
    document.body.classList.toggle('touch', !!(NW.input.touchMode || NW.store.p.settings.touch));
    const b = !!(NW.game && NW.game.building);
    $('#tb-place').classList.toggle('hidden', !b); $('#tb-rot').classList.toggle('hidden', !b);
  };
  UI.showHud = function (v) { $('#hud').classList.toggle('hidden', !v); UI.updateTouchVisible(); };

  /* ---------- panels ---------- */
  function panelsEl() { return $('#panels'); }
  UI.closePanel = function () { UI.panel = null; panelsEl().innerHTML = ''; UI.cache.hb = null; NW.game.onPanelClosed && NW.game.onPanelClosed(); };
  function open(id, html, cls) {
    UI.panel = id; panelsEl().innerHTML = `<div class="overlay ${cls || ''}" data-overlay="${id}">${html}</div>`;
  }
  UI.openShop = function () {
    UI.shopCat = UI.shopCat || 'weapons';
    open('shop', `<div class="pnl big" id="shop-box"><div class="ptitle"><span>MERCHANT SHOP</span><span class="coins">${img('coin')}<b id="shop-coins"></b></span></div>
      <div class="tabs" id="shop-tabs"></div><div class="grid" id="shop-grid"></div>
      <div class="foot"><span id="shop-note"></span><button class="btn" data-act="close">CLOSE [Esc]</button></div></div>`);
    UI.refreshShop(); NW.audio.sfx('shopOpen');
  };
  UI.updateShopCoins = function () { const e = document.getElementById('shop-coins'); if (e) e.textContent = NW.store.p.coins; };
  UI.refreshShop = function () {
    if (UI.panel !== 'shop') return;
    UI.updateShopCoins();
    $('#shop-tabs').innerHTML = NW.shop.cats.map(c => `<button class="tab ${UI.shopCat === c[0] ? 'sel' : ''}" data-act="cat:${c[0]}">${c[1]}</button>`).join('');
    $('#shop-grid').innerHTML = NW.shop.items.filter(i => i.cat === UI.shopCat).map(it => {
      const st = NW.shop.status(it), cnt = NW.shop.count(it);
      let btn;
      if (st.owned) btn = `<button class="btn sm ${st.label === 'EQUIPPED' ? 'ok' : ''}" data-act="buy:${it.id}" ${st.label === 'EQUIPPED' ? 'disabled' : ''}>${st.label}</button>`;
      else if (st.maxed) btn = `<button class="btn sm" disabled>MAX</button>`;
      else btn = `<button class="btn sm price" data-act="buy:${it.id}" ${st.ok ? '' : 'disabled'}>${img('coin')} ${st.label}</button>`;
      return `<div class="card ${st.ok === false && !st.owned ? 'dim' : ''}">${img(it.icon, 'lg')}<div class="ct"><b>${it.name}</b><span>${it.desc}</span><em>${cnt}</em></div>${btn}</div>`;
    }).join('');
    $('#shop-note').textContent = NW.game.phase === 'prep' || NW.game.state !== 'play' ? 'Spend your coins wisely, watchman.' : '';
  };
  UI.openInventory = function () {
    open('inv', `<div class="pnl big" id="inv-box"><div class="ptitle"><span>INVENTORY</span><span class="coins">${img('coin')}<b id="inv-coins"></b></span></div>
      <div class="grid inv" id="inv-grid"></div><div class="foot"><span id="inv-note"></span><button class="btn" data-act="close">CLOSE [Esc]</button></div></div>`);
    UI.refreshInventory(); NW.audio.sfx('click');
  };
  UI.refreshInventory = function () {
    if (UI.panel !== 'inv') return;
    const p = NW.store.p, PL = NW.player, WP = NW.weapons, G = NW.game;
    $('#inv-coins').textContent = p.coins;
    let h = '';
    WP.owned().forEach(id => { const d = WP.defs[id]; h += `<div class="card ${p.weapon === id ? 'sel' : ''}">${img(d.icon, 'lg')}<div class="ct"><b>${d.name}</b><span>${d.desc}</span><em>${id.startsWith('flash') ? 'Battery ' + Math.round(PL.battery) + '%' : 'Uses shells'}</em></div><button class="btn sm ${p.weapon === id ? 'ok' : ''}" data-act="weapon:${id}">${p.weapon === id ? 'IN HAND' : 'EQUIP'}</button></div>`; });
    h += `<div class="card">${img('ammo', 'lg')}<div class="ct"><b>Shells</b><span>Ammo for shotgun and rifle.</span><em>x${p.inv.ammo}</em></div></div>`;
    h += `<div class="card">${img('battery', 'lg')}<div class="ct"><b>Batteries</b><span>Recharge flashlight +60%.</span><em>x${p.inv.battery}</em></div><button class="btn sm" data-act="bat" ${p.inv.battery > 0 ? '' : 'disabled'}>USE [F]</button></div>`;
    h += `<div class="card">${img('medkit', 'lg')}<div class="ct"><b>Medkits</b><span>Restore 50% health.</span><em>x${p.inv.medkit}</em></div><button class="btn sm" data-act="med" ${p.inv.medkit > 0 ? '' : 'disabled'}>USE [H]</button></div>`;
    const need = G.questNeed();
    h += `<div class="card quest">${img('seed', 'lg')}<div class="ct"><b>Pumpkin Seeds <small>(quest)</small></b><span>Collect ${need} seeds from the pumpkin patches (E) or big pumpkins for a reward.</span><em>${p.inv.seed}/${need}</em></div></div>`;
    ['fence', 'barricade', 'trap', 'turret'].forEach(k => { h += `<div class="card">${img(NW.farm.STYPES[k].icon, 'lg')}<div class="ct"><b>${NW.farm.STYPES[k].name}</b><span>In stock for building.</span><em>x${p.stock[k]}</em></div></div>`; });
    $('#inv-grid').innerHTML = h;
    const u = p.upg;
    $('#inv-note').textContent = `DMG +${u.dmg * 20}%  RATE +${u.rate * 12}%  HP ${PL.maxHp()}  LIGHT +${u.range * 12}%  SPEED +${u.speed * 7}%`;
  };
  UI.refresh = function () { UI.refreshShop(); UI.refreshInventory(); UI.cache.hb = null; UI.refreshMenuInfo && UI.refreshMenuInfo(); };

  UI.openPause = function () {
    open('pause', `<div class="pnl mid"><div class="ptitle"><span>PAUSED</span></div><div class="stack">
      <button class="btn lg" data-act="resume">RESUME</button><button class="btn lg" data-act="settings">SETTINGS</button><button class="btn lg" data-act="howto">HOW TO PLAY</button><button class="btn lg" data-act="tomenu">SAVE &amp; QUIT TO MENU</button></div></div>`);
  };
  UI.openGameOver = function (info) {
    open('gameover', `<div class="pnl mid over"><div class="ptitle red"><span>THE BARN HAS FALLEN</span></div><div class="stack">
      <p>You survived <b>${info.nights}</b> night${info.nights === 1 ? '' : 's'}.</p><p>Monsters defeated: <b>${info.kills}</b></p><p>Best: <b>NIGHT ${info.best}</b></p>
      <button class="btn lg" data-act="retry">TRY AGAIN</button><button class="btn lg" data-act="tomenu">MAIN MENU</button></div></div>`);
  };

  /* ---------- build bar ---------- */
  UI.updateBuildHud = function () {
    const bb = $('#buildbar'), G = NW.game, p = NW.store.p;
    bb.classList.toggle('hidden', !G.building);
    if (!G.building) { UI.cache.bsig = null; return; }
    const sig = G.buildType + '|' + G.buildRot + '|' + p.coins + '|' + JSON.stringify(p.stock) + '|' + (G.buildErr || '');
    if (UI.cache.bsig === sig) return; UI.cache.bsig = sig;
    const T = NW.farm.STYPES;
    bb.innerHTML = '<div class="bt">BUILD MODE <small>1-4 select · LMB place · R rotate · RMB/Esc exit</small></div><div class="row">' +
      ['fence', 'barricade', 'trap', 'turret'].map((k, i) => `<button class="slot wide ${G.buildType === k ? 'sel' : ''} ${p.stock[k] <= 0 && p.coins < T[k].cost ? 'dim' : ''}" data-act="bt:${k}">${img(T[k].icon)}<span>${T[k].name}</span><em>${p.stock[k] > 0 ? 'x' + p.stock[k] : T[k].cost + 'c'}</em><kbd>${i + 1}</kbd></button>`).join('') +
      `</div><div class="bt err">${G.buildErr || '&nbsp;'}</div>`;
  };

  /* ---------- main menu / settings / how-to ---------- */
  UI.buildMenu = function () { /* menu is a panel opened via openMenu */ };
  UI.openMenu = function () {
    const p = NW.store.p, run = p.run && p.run.night > 1;
    open('menu', `<div class="menu"><div class="logo"><div class="l1">NIGHT WATCH</div><div class="l2">HALLOWEEN FARM</div><div class="l3">НОЧНОЙ ДОЗОР · ХЭЛЛОУИНСКАЯ ФЕРМА</div></div>
      <div class="stack mbtns">
        <button class="btn lg" data-act="play">${run ? 'CONTINUE · NIGHT ' + p.run.night : 'PLAY'}</button>
        ${run ? '<button class="btn lg" data-act="newgame">NEW RUN</button>' : ''}
        <button class="btn lg" data-act="menushop">SHOP</button>
        <button class="btn lg" data-act="settings">SETTINGS</button>
        <button class="btn lg" data-act="howto">HOW TO PLAY</button>
      </div><div class="minfo" id="minfo"></div></div>`, 'menuov');
    UI.refreshMenuInfo();
  };
  UI.refreshMenuInfo = function () { const e = document.getElementById('minfo'); if (e) e.innerHTML = `${img('coin')} ${NW.store.p.coins} &nbsp;·&nbsp; BEST: NIGHT ${NW.store.p.best || 0}`; };
  UI.openSettings = function (from) {
    const s = NW.store.p.settings; UI.settingsFrom = from || UI.panel;
    const chk = (k, l) => `<label class="row"><span>${l}</span><input type="checkbox" data-set="${k}" ${s[k] ? 'checked' : ''}></label>`;
    open('settings', `<div class="pnl mid"><div class="ptitle"><span>SETTINGS</span></div><div class="stack left">
      <label class="row"><span>MUSIC</span><input type="range" min="0" max="1" step="0.05" value="${s.music}" data-set="music"></label>
      <label class="row"><span>SOUND FX</span><input type="range" min="0" max="1" step="0.05" value="${s.sfx}" data-set="sfx"></label>
      ${chk('particles', 'PARTICLES')}${chk('lights', 'DYNAMIC LIGHT')}${chk('fog', 'FOG')}${chk('touch', 'TOUCH CONTROLS')}
      <button class="btn" data-act="resetsave" id="resetbtn">RESET ALL PROGRESS</button>
      <button class="btn lg" data-act="back">BACK</button></div></div>`);
  };
  UI.openHowTo = function (from) {
    UI.settingsFrom = from || UI.panel;
    open('howto', `<div class="pnl big how"><div class="ptitle"><span>HOW TO PLAY</span></div><div class="howtx">
      <p><b>Goal / Цель:</b> защити амбар от монстров из леса. Выживи как можно больше ночей. Protect the barn until dawn.</p>
      <div class="keys">
        <span><kbd>W A S D</kbd> move / движение</span><span><kbd>Mouse</kbd> aim flashlight / прицел</span>
        <span><kbd>LMB</kbd> attack / атака</span><span><kbd>E</kbd> interact / действие</span>
        <span><kbd>1-4</kbd> / <kbd>Q</kbd> weapons / оружие</span><span><kbd>F</kbd> battery · <kbd>H</kbd> medkit</span>
        <span><kbd>B</kbd> build / строить</span><span><kbd>T</kbd> shop · <kbd>I</kbd> inventory</span>
        <span><kbd>N</kbd> start wave now</span><span><kbd>Esc</kbd> / <kbd>P</kbd> pause</span>
      </div>
      <p>• Монстры идут по дорожкам к амбару и грызут заборы на пути. Monsters follow the paths and chew through fences.</p>
      <p>• Монеты падают из врагов. Тратьте их в магазине (между волнами): оружие, улучшения, защита.</p>
      <p>• BUILD: ставьте заборы, баррикады, ловушки и турели. Зелёный призрак — можно ставить, красный — нельзя.</p>
      <p>• Фонарик садится — меняйте батарейки (F). Призраки боятся света! Ghosts fear the flash.</p>
      <p>• E у куста тыкв — тыквенные семечки (квест). E у лавки — магазин.</p>
      <p>• Mobile: left stick moves, right stick aims &amp; shoots.</p>
    </div><div class="foot"><span></span><button class="btn" data-act="back">BACK</button></div></div>`);
  };

  /* ---------- events ---------- */
  function onInput(e) {
    const el = e.target, k = el.getAttribute && el.getAttribute('data-set'); if (!k) return;
    const s = NW.store.p.settings;
    s[k] = el.type === 'checkbox' ? (el.checked ? 1 : 0) : parseFloat(el.value);
    NW.audio.applyVolumes(); NW.store.save();
    if (k === 'touch') UI.updateTouchVisible();
    if (k === 'sfx' && e.type === 'change') NW.audio.sfx('coin');
  }
  function onClick(e) {
    NW.audio.init();
    const el = e.target.closest('[data-act]'); if (!el || el.disabled) return;
    const a = el.getAttribute('data-act'), G = NW.game;
    NW.audio.sfx('click');
    const [act, arg] = a.split(':');
    switch (act) {
      case 'play': G.startGame(false); break;
      case 'newgame': G.startGame(true); break;
      case 'menushop': G.menuShop = true; UI.openShop(); break;
      case 'settings': UI.openSettings(UI.panel); break;
      case 'howto': UI.openHowTo(UI.panel); break;
      case 'back': { const f = UI.settingsFrom; if (f === 'pause') UI.openPause(); else if (f === 'menu' || G.state === 'menu') UI.openMenu(); else UI.closePanel(); break; }
      case 'close': if (G.menuShop) { G.menuShop = false; UI.openMenu(); } else UI.closePanel(); break;
      case 'shop': G.toggleShop(); break;
      case 'inv': G.toggleInventory(); break;
      case 'build': G.toggleBuild(); break;
      case 'pause': G.togglePause(); break;
      case 'resume': G.togglePause(false); break;
      case 'tomenu': G.toMenu(); break;
      case 'retry': G.startGame(true); break;
      case 'startwave': G.startWaveNow(); break;
      case 'cat': UI.shopCat = arg; UI.refreshShop(); break;
      case 'buy': NW.shop.buy(arg); break;
      case 'weapon': NW.store.p.weapon = arg; UI.refresh(); break;
      case 'bat': NW.player.useBattery(); break;
      case 'med': NW.player.useMedkit(); break;
      case 'bt': G.selectBuild(arg); break;
      case 'use': G.interact(); break;
      case 'swap': G.cycleWeapon(1); break;
      case 'place': G.placeBuild(); break;
      case 'rotate': G.rotateBuild(); break;
      case 'resetsave':
        if (el.dataset.confirm) { NW.store.reset(); NW.audio.applyVolumes(); G.toMenu(); } else { el.dataset.confirm = 1; el.textContent = 'CLICK AGAIN TO CONFIRM'; }
        break;
    }
  }

  /* ---------- touch joysticks ---------- */
  function initTouch() {
    const I = NW.input;
    window.addEventListener('touchstart', () => { if (!I.touchMode) { I.touchMode = true; UI.updateTouchVisible(); } }, { passive: true });
    function joy(id, onMove, onEnd) {
      const el = document.getElementById(id), knob = el.firstElementChild; let pid = null, cx = 0, cy = 0, rad = 50;
      const set = (e) => {
        let dx = e.clientX - cx, dy = e.clientY - cy; const d = Math.hypot(dx, dy), m = Math.min(d, rad);
        if (d > 0) { dx = dx / d * m; dy = dy / d * m; }
        knob.style.transform = `translate(${dx}px,${dy}px)`; onMove(dx / rad, dy / rad);
      };
      el.addEventListener('pointerdown', e => { e.preventDefault(); NW.audio.init(); pid = e.pointerId; el.setPointerCapture(pid); const r = el.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; rad = r.width / 2 - 10; set(e); });
      el.addEventListener('pointermove', e => { if (e.pointerId === pid) set(e); });
      const end = e => { if (e.pointerId !== pid) return; pid = null; knob.style.transform = ''; onEnd(); };
      el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
    }
    joy('joyL', (x, y) => { I.move.x = x; I.move.y = y; }, () => { I.move.x = 0; I.move.y = 0; });
    joy('joyR', (x, y) => { const m = Math.hypot(x, y); I.aim.x = x; I.aim.y = y; I.aim.active = m > 0.12; I.touchFire = m > 0.45; }, () => { I.aim.active = false; I.touchFire = false; I.aim.x = I.aim.y = 0; });
  }
})();
