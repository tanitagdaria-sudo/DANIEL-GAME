/* Game controller: loop, state machine, nights & waves, build mode, interaction, rendering pipeline */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U, F = NW.farm, PL = NW.player, DOG = NW.dog, EN = NW.enemies, WP = NW.weapons, FX = NW.fx, I = NW.input;
  const G = NW.game = {
    state: 'boot', paused: false, night: 1, wave: 1, waves: 2, phase: 'prep', prepT: 30, plan: [], queue: [], waveT: 0, barnHp: 200, barnMax: 200,
    building: false, buildType: 'fence', buildRot: 0, buildErr: '', buildPos: { x: 0, y: 0 }, time: 0, shakeAmt: 0, amb: 0.72, menuShop: false, kills: 0, nightsSurvived: 0, advT: 0
  };
  let ctx, cv, last = 0, autosaveT = 0, redVig;

  G.shake = a => { G.shakeAmt = Math.max(G.shakeAmt, a); };
  G.enemiesLeft = () => EN.alive() + G.queue.length;
  G.questNeed = () => 5 + 3 * (NW.store.p.quest.done || 0);
  G.addCoins = n => { NW.store.p.coins += n; };

  /* ---------------- init ---------------- */
  G.init = function () {
    cv = document.getElementById('game'); ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    NW.spr.build(); F.init(); F.buildBg(); FX.initAmbient();
    const [rc, rg] = U.mk(NW.W, NW.H); const gr = rg.createRadialGradient(NW.W / 2, NW.H / 2, NW.H * 0.3, NW.W / 2, NW.H / 2, NW.H);
    gr.addColorStop(0, 'rgba(200,0,0,0)'); gr.addColorStop(1, 'rgba(200,0,0,0.8)'); rg.fillStyle = gr; rg.fillRect(0, 0, NW.W, NW.H); redVig = rc;
    I.bindCanvas(cv);
    // touch placement on canvas (build mode)
    const tp = e => { if (e.pointerType === 'mouse' || !G.building) return; const r = cv.getBoundingClientRect(); I.mouse.x = (e.clientX - r.left) / r.width * NW.W; I.mouse.y = (e.clientY - r.top) / r.height * NW.H; };
    cv.addEventListener('pointerdown', e => { tp(e); NW.audio.init(); });
    cv.addEventListener('pointermove', tp);
    NW.ui.init(); NW.audio.applyVolumes && 0;
    window.addEventListener('blur', () => { if (G.state === 'play' && !G.paused && !NW.ui.panel) G.togglePause(true); });
    document.addEventListener('visibilitychange', () => { if (document.hidden && G.state === 'play' && !G.paused && !NW.ui.panel) G.togglePause(true); });
    const unlock = () => { NW.audio.init(); };
    window.addEventListener('pointerdown', unlock); window.addEventListener('keydown', unlock);
    G.state = 'menu'; NW.ui.showHud(false); NW.ui.openMenu();
    requestAnimationFrame(t => { last = t; frame(t); });
  };

  /* ---------------- run lifecycle ---------------- */
  G.snapshotRun = function () {
    if (G.state !== 'play' && G.state !== 'gameover') return;
    if (G.state === 'gameover') return;
    NW.store.p.run = { night: G.night, barnHp: Math.round(G.barnHp), structs: F.saveStructs() };
  };
  G.startGame = function (newRun) {
    const p = NW.store.p; NW.audio.init();
    if (newRun) p.run = null;
    G.menuShop = false; NW.ui.closePanel();
    F.init(); EN.clear(); WP.proj.length = 0; FX.parts.length = 0; FX.texts.length = 0; FX.coinsL.length = 0; FX.items.length = 0; FX.dyn.length = 0; FX.rings.length = 0;
    const run = p.run;
    G.night = run ? run.night : 1; G.barnHp = run ? Math.min(G.barnMax, run.barnHp) : G.barnMax;
    if (run && run.structs && run.structs.length) F.loadStructs(run.structs);
    if (!newRun || !run) { /* fresh map */ }
    G.kills = 0; G.paused = false; G.building = false;
    PL.reset(); PL.battery = 100; DOG.reset();
    p.plays = (p.plays || 0) + 1;
    G.state = 'play'; NW.ui.showHud(true); document.body.classList.add('play');
    G.startNight(G.night);
    if (p.plays === 1) { NW.ui.toast('WASD move · Mouse aim · LMB attack · E interact', 'good'); setTimeout(() => NW.ui.toast('Pumpkins & zombies come at night. Protect the barn!', ''), 2600); }
    NW.store.save();
  };
  G.toMenu = function () {
    G.snapshotRun(); NW.store.save();
    G.state = 'menu'; G.paused = false; G.building = false; EN.clear(); WP.proj.length = 0;
    document.body.classList.remove('play'); NW.ui.showHud(false); NW.ui.openMenu(); NW.audio.setIntensity(0);
  };
  G.startNight = function (n) {
    G.night = n; G.waves = n < 3 ? 2 : 3; G.wave = 1; G.phase = 'prep'; G.prepT = n === 1 ? 40 : 30; G.plan = nightPlan(n, G.waves); G.queue = [];
    F.patches.forEach(p => { p.ready = true; });
    NW.ui.banner('NIGHT ' + n, n === 1 ? 'Defend the barn until dawn' : 'Prepare your defenses', '', 3000);
    NW.audio.sfx('wave'); NW.audio.setIntensity(0.15);
    G.snapshotRun(); NW.store.save();
  };
  G.startWaveNow = function () { if (G.phase === 'prep' && G.state === 'play') G.prepT = 0; };
  G.startWave = function () {
    const list = G.plan[G.wave - 1] || [];
    if (NW.ui.panel === 'shop' || NW.ui.panel === 'inv') { NW.ui.closePanel(); NW.ui.toast('The wave begins!', 'bad'); }
    G.phase = 'wave'; G.waveT = 0; G.queue = [];
    const keys = spawnKeys(G.night), gap = Math.max(0.4, 1.25 - G.night * 0.07);
    let t = 1.2;
    list.forEach(type => {
      if (type === 'king') { G.queue.push({ t: 3.5, type, key: 'S' }); return; }
      t += gap * U.rnd(0.5, 1.4);
      G.queue.push({ t, type, key: type === 'ghost' ? 'G' : (type === 'fast' && Math.random() < 0.5 ? 'S' : U.pick(keys)) });
    });
    G.queue.sort((a, b) => a.t - b.t);
    const boss = list.indexOf('king') >= 0;
    if (boss) { NW.ui.banner('BOSS INCOMING', 'The Pumpkin King awakens!', 'boss', 3200); NW.audio.sfx('boss'); NW.audio.setIntensity(1); }
    else { NW.ui.banner('WAVE ' + G.wave, list.length + ' monsters approach', '', 2200); NW.audio.sfx('wave'); NW.audio.setIntensity(0.55); }
  };
  function waveComplete() {
    const bonus = 10 + 8 * G.night;
    G.addCoins(bonus); FX.text(PL.x, PL.y - 30, 'WAVE BONUS +' + bonus, '#ffd23a', true);
    NW.audio.sfx('win'); NW.audio.setIntensity(0.15);
    PL.heal(PL.maxHp() * 0.2);
    if (G.wave < G.waves) {
      NW.ui.banner('WAVE COMPLETED', 'Next wave in a moment...', 'good', 2800);
      G.wave++; G.phase = 'prep'; G.prepT = 24; F.healAll(0.12);
    } else {
      NW.ui.banner('WAVE COMPLETED', 'NIGHT ' + G.night + ' SURVIVED — dawn is near', 'good', 3600);
      NW.store.p.best = Math.max(NW.store.p.best || 0, G.night);
      G.nightsSurvived = G.night;
      G.phase = 'dawn'; G.advT = 4;
      F.healAll(0.35); G.barnHp = Math.min(G.barnMax, G.barnHp + G.barnMax * 0.2); PL.heal(PL.maxHp() * 0.4);
      NW.store.p.run = { night: G.night + 1, barnHp: Math.round(G.barnHp), structs: F.saveStructs() };
      NW.store.save();
    }
    NW.ui.refresh();
  }
  G.damageBarn = function (n) {
    if (G.state !== 'play') return;
    G.barnHp -= n; G.shake(2.5); G.barnHit = 0.3;
    FX.text(396 + U.rnd(-14, 14), 136, '-' + Math.round(n), '#ff6a4a');
    if (G.barnHp <= 0) { G.barnHp = 0; G.gameOver(); }
  };
  G.onKill = function (e) { G.kills++; };
  G.onPlayerDeath = function () {
    const lost = Math.min(Math.floor(NW.store.p.coins * 0.15), 120);
    NW.store.p.coins -= lost;
    NW.ui.banner('YOU FELL', lost ? 'Lost ' + lost + ' coins — respawning...' : 'Respawning...', 'boss', 2800);
    G.building = false; NW.ui.updateTouchVisible();
  };
  G.respawnPlayer = function () { PL.reset(PL.maxHp() * 0.6); PL.invuln = 3; NW.audio.sfx('heal'); NW.fx.burst(PL.x, PL.y - 8, 14, ['#ffd23a', '#fff'], 80, 0.7); };
  G.gameOver = function () {
    G.state = 'gameover'; G.building = false;
    const p = NW.store.p; p.best = Math.max(p.best || 0, G.night - 1);
    p.run = null; NW.store.save();
    NW.audio.sfx('lose'); NW.audio.setIntensity(0); NW.ui.banner('', '', 'hidden', 1);
    document.body.classList.remove('play');
    setTimeout(() => NW.ui.openGameOver({ nights: Math.max(0, G.night - 1), kills: G.kills, best: p.best }), 1400);
    NW.ui.showHud(false);
  };

  /* ---------------- wave composition ---------------- */
  function spawnKeys(n) { return n < 2 ? ['S', 'W'] : n < 3 ? ['S', 'W', 'E'] : ['S', 'W', 'E', 'NW', 'NE']; }
  function nightPlan(n, waves) {
    const c = {
      pumpkin: Math.min(60, n <= 6 ? 5 * n : 30 + 3 * (n - 6)),
      zombie: Math.min(40, n === 1 ? 3 : n === 2 ? 5 : 3 + 2 * (n - 1)),
      fast: n >= 3 ? Math.min(30, 3 + 2 * (n - 3)) : 0,
      ghost: n >= 4 ? Math.min(12, 2 + (n - 4)) : 0,
      big: n >= 4 ? Math.max(1, Math.floor(n / 3)) : 0,
      king: n % 5 === 0 ? Math.floor(n / 5) : 0
    };
    const shares = waves === 2 ? [0.4, 0.6] : [0.25, 0.35, 0.4];
    const plan = []; for (let i = 0; i < waves; i++) plan.push([]);
    Object.keys(c).forEach(type => {
      let left = c[type];
      if (type === 'king') { for (let k = 0; k < left; k++) plan[waves - 1].push('king'); return; }
      if (type === 'big') { for (let k = 0; k < left; k++) plan[waves - 1 - (k % Math.min(2, waves))].push('big'); return; }
      for (let w = 0; w < waves; w++) {
        const q = w === waves - 1 ? left : Math.floor(c[type] * shares[w]);
        for (let k = 0; k < q; k++) plan[w].push(type); left -= q;
      }
    });
    plan.forEach(a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } const ki = a.indexOf('king'); if (ki >= 0) { a.splice(ki, 1); a.unshift('king'); } });
    return plan;
  }

  /* ---------------- quest & interaction ---------------- */
  G.checkQuest = function () {
    const p = NW.store.p, need = G.questNeed();
    if (p.inv.seed >= need) {
      p.inv.seed -= need; p.quest.done++;
      const reward = 80 + 40 * p.quest.done; p.coins += reward; p.inv.medkit++; p.inv.battery++;
      NW.audio.sfx('win'); NW.ui.toast('QUEST COMPLETE! +' + reward + ' coins, +medkit, +battery', 'good');
      FX.text(PL.x, PL.y - 30, 'QUEST +' + reward, '#9affc0', true);
    } else NW.ui.toast('Pumpkin seeds: ' + p.inv.seed + '/' + need, 'good');
    NW.ui.refresh();
  };
  function nearest() {
    const s = F.shop, cx = s.x, cy = s.y;
    if (U.dist(PL.x, PL.y, cx, cy) < s.r + 12) return { type: 'shop' };
    let best = null, bd = 28;
    F.patches.forEach(p => { const d = U.dist(PL.x, PL.y, p.x, p.y); if (p.ready && d < bd) { bd = d; best = p; } });
    if (best) return { type: 'patch', p: best };
    if (U.dist(PL.x, PL.y, 396, 160) < 44 && G.barnHp < G.barnMax) return { type: 'barn' };
    return null;
  }
  G.interact = function () {
    if (G.state !== 'play' || !PL.alive) return;
    const n = nearest(); if (!n) return;
    if (n.type === 'shop') G.toggleShop();
    else if (n.type === 'patch') {
      n.p.ready = false; NW.store.p.inv.seed++; NW.audio.sfx('pickup');
      FX.burst(n.p.x, n.p.y - 4, 10, ['#e8741e', '#4a7a2a', '#e8b860'], 60, 0.6);
      FX.text(n.p.x, n.p.y - 14, '+SEED', '#e8d08a'); G.checkQuest();
    } else if (n.type === 'barn') {
      const cost = 10, p = NW.store.p;
      if (p.coins < cost) { NW.audio.sfx('error'); NW.ui.toast('Repair costs ' + cost + ' coins', 'bad'); return; }
      p.coins -= cost; G.barnHp = Math.min(G.barnMax, G.barnHp + 12); NW.audio.sfx('place'); FX.text(396, 150, '+12', '#7dff7a'); NW.ui.refresh();
    }
  };
  G.toggleShop = function () {
    if (G.state !== 'play') return;
    if (NW.ui.panel === 'shop') { NW.audio.sfx('shopClose'); NW.ui.closePanel(); return; }
    if (G.phase === 'wave') { NW.audio.sfx('error'); NW.ui.toast('The merchant hides until the wave is over!', 'bad'); return; }
    if (G.paused) return;
    G.building = false; NW.ui.closePanel(); NW.ui.openShop();
  };
  G.toggleInventory = function () {
    if (G.state !== 'play' || G.paused) return;
    if (NW.ui.panel === 'inv') { NW.ui.closePanel(); return; }
    G.building = false; NW.ui.closePanel(); NW.ui.openInventory();
  };
  G.togglePause = function (force) {
    if (G.state !== 'play') return;
    const want = force === undefined ? !G.paused : force;
    if (want === G.paused) return;
    G.paused = want;
    if (want) { G.building = false; NW.ui.closePanel(); NW.ui.openPause(); NW.audio.sfx('click'); } else NW.ui.closePanel();
  };
  G.onPanelClosed = function () { G.menuShop = false; NW.ui.updateTouchVisible(); };
  G.cycleWeapon = function (d) {
    const o = WP.owned(), p = NW.store.p; if (o.length < 2) return;
    let i = o.indexOf(p.weapon); i = (i + d + o.length) % o.length; p.weapon = o[i]; NW.audio.sfx('click'); NW.ui.refresh();
  };

  /* ---------------- build mode ---------------- */
  G.toggleBuild = function () {
    if (G.state !== 'play' || G.paused || !PL.alive) return;
    if (NW.ui.panel) NW.ui.closePanel();
    G.building = !G.building; NW.audio.sfx('click'); NW.ui.updateTouchVisible();
    if (G.building) NW.ui.toast('BUILD MODE — place defences on the farm', 'good');
  };
  G.selectBuild = function (t) { G.buildType = t; G.buildRot = 0; NW.audio.sfx('click'); };
  G.rotateBuild = function () { if (G.buildType === 'fence') { G.buildRot = G.buildRot ? 0 : 1; NW.audio.sfx('click'); } };
  function updateBuild() {
    const T = F.STYPES[G.buildType], p = NW.store.p;
    const pos = F.snap(G.buildType, I.mouse.x, I.mouse.y, G.buildRot);
    G.buildPos = pos;
    let err = F.canPlace(G.buildType, pos.x, pos.y, G.buildRot, PL.x, PL.y);
    if (!err && p.stock[G.buildType] <= 0 && p.coins < T.cost) err = 'Not enough coins (' + T.cost + ')';
    G.buildErr = err || (p.stock[G.buildType] > 0 ? 'Ready — uses 1 from stock' : 'Ready — costs ' + T.cost + ' coins');
    G.buildOK = !err;
  }
  G.placeBuild = function () {
    if (!G.building) return;
    updateBuild();
    if (!G.buildOK) { NW.audio.sfx('error'); return; }
    const T = F.STYPES[G.buildType], p = NW.store.p, pos = G.buildPos;
    if (p.stock[G.buildType] > 0) p.stock[G.buildType]--; else p.coins -= T.cost;
    F.addStruct(G.buildType, pos.x, pos.y, G.buildRot);
    NW.audio.sfx('place'); FX.burst(pos.x + 8, pos.y + 8, 8, ['#6a4a2e', '#8a6a46', '#4a3220'], 50, 0.5);
    FX.text(pos.x + 8, pos.y - 6, T.name.toUpperCase(), '#c8f0ff');
    NW.ui.refresh();
  };

  /* ---------------- input & update ---------------- */
  function handleKeys() {
    const p = NW.store.p;
    if (G.state === 'menu') { if (I.hit('Escape') && NW.ui.panel && NW.ui.panel !== 'menu') { if (NW.ui.panel === 'shop' && G.menuShop) { G.menuShop = false; NW.ui.openMenu(); } else NW.ui.openMenu(); } return; }
    if (G.state !== 'play') return;
    if (I.hit('Escape') || I.hit('KeyP')) {
      if (G.building) { G.building = false; NW.ui.updateTouchVisible(); }
      else if (NW.ui.panel === 'shop' || NW.ui.panel === 'inv') NW.ui.closePanel();
      else if (NW.ui.panel === 'settings' || NW.ui.panel === 'howto') NW.ui.openPause();
      else G.togglePause();
      return;
    }
    if (G.paused) return;
    if (I.hit('KeyT')) G.toggleShop();
    if (I.hit('KeyI') || I.hit('Tab')) G.toggleInventory();
    if (I.hit('KeyB')) G.toggleBuild();
    if (NW.ui.panel) return;
    if (I.hit('KeyN')) G.startWaveNow();
    if (I.hit('KeyE')) G.interact();
    if (I.hit('KeyF')) PL.useBattery();
    if (I.hit('KeyH')) PL.useMedkit();
    if (I.hit('KeyQ')) G.cycleWeapon(1);
    if (I.wheel && !G.building) G.cycleWeapon(I.wheel > 0 ? 1 : -1);
    if (G.building) {
      const bt = ['fence', 'barricade', 'trap', 'turret'];
      for (let i = 0; i < 4; i++) if (I.hit('Digit' + (i + 1))) G.selectBuild(bt[i]);
      if (I.hit('KeyR')) G.rotateBuild();
      if (I.hit('MouseRight')) { G.building = false; NW.ui.updateTouchVisible(); }
      if (I.hit('MouseLeft')) G.placeBuild();
    } else {
      const o = WP.owned();
      for (let i = 0; i < 4; i++) if (I.hit('Digit' + (i + 1)) && o[i]) { p.weapon = o[i]; NW.audio.sfx('click'); NW.ui.refresh(); }
    }
  }
  function playerControl() {
    let mx = 0, my = 0;
    if (I.down('KeyW') || I.down('ArrowUp')) my -= 1; if (I.down('KeyS') || I.down('ArrowDown')) my += 1;
    if (I.down('KeyA') || I.down('ArrowLeft')) mx -= 1; if (I.down('KeyD') || I.down('ArrowRight')) mx += 1;
    if (I.move.x || I.move.y) { mx = I.move.x; my = I.move.y; }
    let aim = PL.aim, fire = false;
    if (I.aim.active) { aim = Math.atan2(I.aim.y, I.aim.x); fire = I.touchFire; }
    else if (I.touchMode && (mx || my) && !I.mouse.active) aim = Math.atan2(my, mx);
    else if (!I.touchMode || I.mouse.active) aim = Math.atan2(I.mouse.y - (PL.y - 6), I.mouse.x - PL.x);
    if (I.mouse.down && !I.touchMode) fire = true;
    if (G.building || NW.ui.panel || G.paused) fire = false;
    return { mx, my, aim, fire };
  }
  function updateTurrets(dt) {
    F.structs.forEach(s => {
      s.hit = Math.max(0, s.hit - dt); if (s.trig > 0) s.trig -= dt;
      if (s.type !== 'turret') return;
      s.cd -= dt; if (s.cd > 0) return;
      let best = null, bd = 130;
      EN.list.forEach(e => { if (e.dead) return; const d = U.dist(s.x + 7, s.y - 8, e.x, e.y - e.r * 0.6); if (d < bd && (e.type !== 'ghost' || e.ph < 0.8)) { bd = d; best = e; } });
      if (best) { s.cd = Math.max(0.28, 0.55 - 0.02 * G.night); WP.turretShot(s, best.x, best.y - best.r * 0.6); }
      else s.ang = (s.ang || 0) + dt * 0.7;
    });
  }
  function updateSim(dt) {
    const p = NW.store.p;
    const c = playerControl();
    PL.update(dt, c);
    if (G.building) updateBuild();
    DOG.update(dt);
    EN.update(dt, true);
    WP.update(dt);
    F.updateCows(dt);
    updateTurrets(dt);
    if (F.navDirty) F.computeNav();
    // phases
    if (G.phase === 'prep') { G.prepT -= dt; if (G.prepT <= 0) G.startWave(); }
    else if (G.phase === 'wave') {
      G.waveT += dt;
      while (G.queue.length && G.queue[0].t <= G.waveT) { const q = G.queue.shift(); EN.spawn(q.type, q.key); }
      if (!G.queue.length && EN.alive() === 0) waveComplete();
    } else if (G.phase === 'dawn') { G.advT -= dt; if (G.advT <= 0) G.startNight(G.night + 1); }
    G.barnHit = Math.max(0, (G.barnHit || 0) - dt);
    autosaveT += dt; if (autosaveT > 15) { autosaveT = 0; G.snapshotRun(); NW.store.save(); }
    // context prompt
    const n = nearest(); let pr = null;
    if (!G.building && n) {
      const key = I.touchMode ? 'Tap E' : 'Press E';
      if (n.type === 'shop') pr = G.phase === 'wave' ? 'Merchant is hiding until the wave ends' : key + ' — open the SHOP';
      else if (n.type === 'patch') pr = key + ' — search the pumpkin patch';
      else if (n.type === 'barn') pr = key + ' — repair the barn (10 coins)';
    }
    NW.ui.setPrompt(pr);
    // ambience: low hp warning etc.
    PL.lowHp = PL.hp < PL.maxHp() * 0.3;
    FX.update(dt, true);
  }
  G.update = function (dt) {
    G.time += dt;
    handleKeys();
    G.shakeAmt = Math.max(0, G.shakeAmt - dt * 18);
    const target = G.state === 'menu' ? 0.7 : G.phase === 'wave' ? 0.8 : 0.7;
    G.amb += (target - G.amb) * Math.min(1, dt * 1.5);
    if (G.state === 'play') {
      if (!G.paused && !NW.ui.panel) updateSim(dt); else FX.update(dt * 0.0001, false);
      NW.ui.update();
    } else if (G.state === 'menu') {
      FX.update(dt, false); F.updateCows(dt); EN.clear();
    } else if (G.state === 'gameover') { FX.update(dt, false); EN.update(dt * 0.2, false); }
  };

  /* ---------------- render ---------------- */
  const dyn = [];
  G.render = function () {
    const g = ctx, t = G.time;
    g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
    g.fillStyle = '#050310'; g.fillRect(0, 0, NW.W, NW.H);
    let sx = 0, sy = 0; if (G.shakeAmt > 0.3) { sx = Math.round((Math.random() - 0.5) * G.shakeAmt); sy = Math.round((Math.random() - 0.5) * G.shakeAmt); }
    g.save(); g.translate(sx, sy);
    g.drawImage(F.bg, 0, 0);
    const playing = G.state === 'play' || G.state === 'gameover';
    dyn.length = 0;
    if (playing) {
      EN.list.forEach(e => dyn.push({ y: e.y, e }));
      dyn.push({ y: PL.y, pl: true }); dyn.push({ y: DOG.y, dog: true });
    }
    F.cows.forEach(c => dyn.push({ y: c.y + 6, cow: c }));
    dyn.sort((a, b) => a.y - b.y);
    const S = F.statics; let si = 0;
    const drawDyn = d => { if (d.e) EN.drawOne(g, d.e); else if (d.pl) PL.draw(g, t); else if (d.dog) DOG.draw(g, t); else if (d.cow) F.drawCow(g, d.cow); };
    for (let di = 0; di < dyn.length; di++) {
      while (si < S.length && S[si].sy <= dyn[di].y) { F.drawStatic(g, S[si], t); si++; }
      drawDyn(dyn[di]);
    }
    while (si < S.length) { F.drawStatic(g, S[si], t); si++; }
    FX.drawLow(g, t);
    WP.draw(g);
    FX.drawParticles(g);
    F.overhead.forEach(o => o.draw(g, t));
    F.drawGarlands(g, t);
    FX.drawFog(g, t, 1);
    // barn hit flash
    if (G.barnHit > 0) { g.globalAlpha = G.barnHit * 1.2; g.fillStyle = '#ff2a1a'; g.fillRect(F.barn.door.x - 6, F.barn.door.y - 40, F.barn.door.w + 12, 52); g.globalAlpha = 1; }
    // lighting
    const o = { amb: G.amb };
    if (G.state === 'menu') {
      o.px = 396 + Math.cos(t * 0.25) * 190; o.py = 250 + Math.sin(t * 0.37) * 50; o.aim = Math.sin(t * 0.5) * 1.2 + 1.2; o.range = 120; o.batt = 1;
    } else if (PL.alive) {
      let batt = PL.battery > 0 ? 0.55 + 0.45 * Math.min(1, PL.battery / 30) : 0.28;
      if (PL.battery < 15 && PL.battery > 0 && Math.random() < 0.08) batt *= 0.4;
      o.px = PL.x; o.py = PL.y; o.aim = PL.aim; o.range = PL.lightRange(); o.batt = batt;
    }
    FX.render(g, t, o);
    FX.drawGhostsBg(g, t);
    FX.drawBats(g);
    // build ghost
    if (G.building && G.state === 'play') drawBuildGhost(g, t);
    FX.drawTexts(g);
    FX.drawVignette(g);
    if (G.state === 'play') {
      if (PL.hurtT > 0) { g.globalAlpha = PL.hurtT * 1.4; g.drawImage(redVig, 0, 0); g.globalAlpha = 1; }
      else if (PL.lowHp && PL.alive) { g.globalAlpha = 0.25 + 0.2 * Math.sin(t * 5); g.drawImage(redVig, 0, 0); g.globalAlpha = 1; }
      drawReticle(g);
    }
    g.restore();
  };
  function drawReticle(g) {
    if (I.touchMode || !I.mouse.active || NW.ui.panel || G.paused || !PL.alive || G.building) return;
    const x = Math.round(I.mouse.x), y = Math.round(I.mouse.y), R = U.R;
    R(g, '#0e0a14', x - 5, y - 1, 11, 3); R(g, '#0e0a14', x - 1, y - 5, 3, 11);
    R(g, '#fff0a0', x - 4, y, 3, 1); R(g, '#fff0a0', x + 2, y, 3, 1); R(g, '#fff0a0', x, y - 4, 1, 3); R(g, '#fff0a0', x, y + 2, 1, 3);
  }
  function drawBuildGhost(g, t) {
    const pos = G.buildPos, T = F.STYPES[G.buildType], d = F.dims(G.buildType, G.buildRot), ok = G.buildOK;
    const col = ok ? '#4aff7a' : '#ff4a4a';
    g.globalAlpha = 0.35; g.fillStyle = col; g.fillRect(pos.x, pos.y, d.w, d.h);
    g.globalAlpha = 0.75;
    F.drawStruct(g, { type: G.buildType, x: pos.x, y: pos.y, w: d.w, h: d.h, rot: G.buildRot, hp: 1, max: 1, hit: 0, cd: 0, ang: 1.5 }, t, true);
    g.globalAlpha = 1; g.strokeStyle = col; g.lineWidth = 1; g.strokeRect(pos.x + 0.5, pos.y + 0.5, d.w - 1, d.h - 1);
    if (G.buildType === 'turret') { g.globalAlpha = 0.3; g.strokeStyle = '#9af0ff'; g.beginPath(); g.arc(pos.x + 7, pos.y - 8, 130, 0, U.TAU); g.stroke(); g.globalAlpha = 1; }
    // placement reach ring
    g.globalAlpha = 0.12; g.strokeStyle = '#fff'; g.beginPath(); g.arc(PL.x, PL.y, 150, 0, U.TAU); g.stroke(); g.globalAlpha = 1;
    // crosshair
    const x = Math.round(I.mouse.x), y = Math.round(I.mouse.y); U.R(g, col, x - 1, y - 1, 3, 3);
  }

  function frame(ts) {
    requestAnimationFrame(frame);
    let dt = (ts - last) / 1000; last = ts; if (!(dt > 0)) dt = 0.016; dt = Math.min(dt, 0.05);
    try { G.update(dt); G.render(); } catch (err) { console.error(err); if (!G.errShown) { G.errShown = true; NW.ui.toast('Error: ' + err.message, 'bad'); } }
    I.endFrame();
  }

  window.addEventListener('load', G.init);
  if (document.readyState === 'complete') G.init();
})();
