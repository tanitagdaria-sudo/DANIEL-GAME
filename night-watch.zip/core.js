/* NIGHT WATCH: HALLOWEEN FARM — core: namespace, utils, input, save */
(function () {
  'use strict';
  const NW = window.NW = window.NW || {};
  NW.W = 768; NW.H = 432;

  const U = NW.U = {};
  U.TAU = Math.PI * 2;
  U.clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  U.lerp = (a, b, t) => a + (b - a) * t;
  U.rnd = (a, b) => (a === undefined ? Math.random() : a + Math.random() * (b - a));
  U.ri = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
  U.pick = a => a[Math.floor(Math.random() * a.length)];
  U.dist = (ax, ay, bx, by) => Math.hypot(bx - ax, by - ay);
  U.angDiff = (a, b) => {
    let d = (b - a) % U.TAU;
    if (d > Math.PI) d -= U.TAU;
    if (d < -Math.PI) d += U.TAU;
    return d;
  };
  U.rng = seed => {
    let s = seed >>> 0;
    return () => {
      s = (s + 0x6D2B79F5) >>> 0;
      let t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  U.mk = (w, h) => {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h));
    const g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    return [c, g];
  };
  U.R = (g, c, x, y, w, h) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };
  U.disc = (g, c, cx, cy, r) => {
    g.fillStyle = c;
    for (let y = -r; y <= r; y++) {
      const w = Math.floor(Math.sqrt(Math.max(0, r * r - y * y)) + 0.5);
      g.fillRect(Math.round(cx - w), Math.round(cy + y), w * 2 + 1, 1);
    }
  };
  U.ell = (g, c, cx, cy, rx, ry) => {
    g.fillStyle = c;
    for (let y = -ry; y <= ry; y++) {
      const w = Math.floor(rx * Math.sqrt(Math.max(0, 1 - (y * y) / (ry * ry + 0.0001))) + 0.5);
      g.fillRect(Math.round(cx - w), Math.round(cy + y), w * 2 + 1, 1);
    }
  };
  U.line = (g, c, x0, y0, x1, y1, th) => {
    th = th || 1; g.fillStyle = c;
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let err = dx + dy, n = 0;
    while (n++ < 2000) {
      g.fillRect(x0, y0, th, th);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  };
  // grid of chars -> pixels
  U.grid = (g, rows, pal, ox, oy, s) => {
    s = s || 1;
    for (let y = 0; y < rows.length; y++) {
      const r = rows[y];
      for (let x = 0; x < r.length; x++) {
        const c = pal[r[x]];
        if (c) { g.fillStyle = c; g.fillRect(ox + x * s, oy + y * s, s, s); }
      }
    }
  };

  /* ---------------- input ---------------- */
  const I = NW.input = {
    keys: {}, pressed: {}, canvas: null,
    mouse: { x: 384, y: 216, down: false, right: false, active: false },
    move: { x: 0, y: 0 }, aim: { x: 0, y: 0, active: false }, touchFire: false,
    touchMode: false, wheel: 0
  };
  I.down = code => !!I.keys[code];
  I.hit = code => !!I.pressed[code];
  I.endFrame = () => { I.pressed = {}; I.wheel = 0; };
  const BLOCK = { Space: 1, ArrowUp: 1, ArrowDown: 1, ArrowLeft: 1, ArrowRight: 1, Tab: 1 };
  window.addEventListener('keydown', e => {
    if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    if (!I.keys[e.code]) I.pressed[e.code] = true;
    I.keys[e.code] = true;
    if (BLOCK[e.code]) e.preventDefault();
  });
  window.addEventListener('keyup', e => { I.keys[e.code] = false; });
  window.addEventListener('blur', () => { I.keys = {}; I.mouse.down = false; I.mouse.right = false; });
  window.addEventListener('contextmenu', e => { e.preventDefault(); });
  I.bindCanvas = function (cv) {
    I.canvas = cv;
    const upd = e => {
      const r = cv.getBoundingClientRect();
      I.mouse.x = (e.clientX - r.left) / r.width * NW.W;
      I.mouse.y = (e.clientY - r.top) / r.height * NW.H;
      I.mouse.active = true;
    };
    window.addEventListener('pointermove', e => { if (e.pointerType === 'mouse') upd(e); });
    cv.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse') {
        upd(e);
        if (e.button === 0) I.mouse.down = true;
        if (e.button === 2) { I.mouse.right = true; I.pressed.MouseRight = true; }
        I.pressed.MouseLeft = e.button === 0 ? true : I.pressed.MouseLeft;
      }
    });
    window.addEventListener('pointerup', e => {
      if (e.pointerType === 'mouse') { if (e.button === 0) I.mouse.down = false; if (e.button === 2) I.mouse.right = false; }
    });
    cv.addEventListener('wheel', e => { I.wheel += Math.sign(e.deltaY); e.preventDefault(); }, { passive: false });
  };

  /* ---------------- save ---------------- */
  const KEY = 'nightwatch_halloween_v1';
  const S = NW.store = { p: null };
  S.def = () => ({
    coins: 0, best: 0, totalKills: 0, plays: 0,
    owned: { flash: 1, flash2: 0, shotgun: 0, rifle: 0 },
    weapon: 'flash',
    upg: { dmg: 0, rate: 0, hp: 0, range: 0, speed: 0 },
    inv: { ammo: 12, battery: 2, medkit: 1, seed: 0 },
    stock: { fence: 4, barricade: 0, trap: 0, turret: 0 },
    quest: { done: 0 },
    settings: { music: 0.5, sfx: 0.8, particles: 1, lights: 1, fog: 1, touch: 0 },
    run: null
  });
  const merge = (d, o) => {
    if (o && typeof o === 'object') {
      for (const k in o) {
        if (d[k] && typeof d[k] === 'object' && !Array.isArray(d[k]) && o[k] && typeof o[k] === 'object') merge(d[k], o[k]);
        else d[k] = o[k];
      }
    }
    return d;
  };
  S.load = function () {
    try { const s = localStorage.getItem(KEY); S.p = s ? merge(S.def(), JSON.parse(s)) : S.def(); }
    catch (e) { S.p = S.def(); }
    return S.p;
  };
  S.save = function () { try { localStorage.setItem(KEY, JSON.stringify(S.p)); } catch (e) { /* ignore */ } };
  S.reset = function () { S.p = S.def(); S.save(); };
  S.load();

  window.addEventListener('beforeunload', () => { if (NW.game && NW.game.snapshotRun) NW.game.snapshotRun(); S.save(); });
})();
