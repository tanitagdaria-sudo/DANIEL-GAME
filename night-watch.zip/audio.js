/* Procedural audio: sfx, ambience (forest), tense music. No external files. */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U;
  const A = NW.audio = { ctx: null, master: null, musG: null, sfxG: null, ambG: null, noiseBuf: null, intensity: 0, ready: false };

  function vols() {
    const s = NW.store.p.settings;
    if (!A.ctx) return;
    A.musG.gain.value = 0.55 * s.music;
    A.sfxG.gain.value = 0.9 * s.sfx;
    A.ambG.gain.value = 0.8 * Math.max(s.sfx, 0.0001) * (s.sfx > 0 ? 1 : 0);
  }
  A.applyVolumes = vols;

  A.init = function () {
    if (A.ctx) { if (A.ctx.state === 'suspended') A.ctx.resume(); return; }
    try {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) return;
      const c = A.ctx = new C();
      A.master = c.createGain(); A.master.gain.value = 0.9; A.master.connect(c.destination);
      A.musG = c.createGain(); A.musG.connect(A.master);
      A.sfxG = c.createGain(); A.sfxG.connect(A.master);
      A.ambG = c.createGain(); A.ambG.connect(A.master);
      const len = c.sampleRate * 2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      A.noiseBuf = b;
      A.ready = true;
      vols();
      startWind(); scheduleAmbient(); startMusic();
    } catch (e) { A.ready = false; }
  };

  function tone(f, d, type, v, slide, delay, dest) {
    if (!A.ready) return;
    const c = A.ctx, t = c.currentTime + (delay || 0);
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + d);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, v || 0.2), t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(dest || A.sfxG);
    o.start(t); o.stop(t + d + 0.05);
  }
  function noise(d, v, f, type, q, fto, delay, dest) {
    if (!A.ready) return;
    const c = A.ctx, t = c.currentTime + (delay || 0);
    const s = c.createBufferSource(); s.buffer = A.noiseBuf; s.loop = true;
    const fl = c.createBiquadFilter(); fl.type = type || 'lowpass'; fl.Q.value = q || 1;
    fl.frequency.setValueAtTime(f, t);
    if (fto) fl.frequency.exponentialRampToValueAtTime(Math.max(30, fto), t + d);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, v), t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    s.connect(fl); fl.connect(g); g.connect(dest || A.sfxG);
    s.start(t, Math.random()); s.stop(t + d + 0.05);
  }
  let comboT = 0, comboN = 0;
  const SFX = {
    step() { noise(0.07, 0.07, 500 + Math.random() * 300, 'lowpass', 1, 200); },
    coin() {
      const now = performance.now();
      comboN = now - comboT < 350 ? Math.min(comboN + 1, 8) : 0; comboT = now;
      const f = 880 * Math.pow(1.0595, comboN * 2);
      tone(f, 0.09, 'square', 0.07); tone(f * 1.5, 0.16, 'square', 0.07, 0, 0.06);
    },
    buy() { tone(523, 0.09, 'triangle', 0.18); tone(659, 0.09, 'triangle', 0.18, 0, 0.08); tone(784, 0.18, 'triangle', 0.2, 0, 0.16); },
    error() { tone(160, 0.18, 'sawtooth', 0.14, -40); tone(120, 0.2, 'sawtooth', 0.14, -30, 0.1); },
    click() { tone(660, 0.05, 'square', 0.07); },
    shopOpen() { tone(392, 0.14, 'triangle', 0.14); tone(523, 0.14, 'triangle', 0.14, 0, 0.1); tone(784, 0.3, 'triangle', 0.14, 0, 0.2); noise(0.25, 0.04, 3000, 'highpass', 1, 6000, 0.1); },
    shopClose() { tone(523, 0.1, 'triangle', 0.12); tone(330, 0.2, 'triangle', 0.12, 0, 0.08); },
    flash() { noise(0.22, 0.12, 1800, 'bandpass', 2, 500); tone(300, 0.16, 'sawtooth', 0.06, -150); },
    shot() { noise(0.35, 0.5, 2400, 'lowpass', 1, 150); tone(90, 0.25, 'sine', 0.4, -50); },
    rifle() { noise(0.3, 0.45, 3500, 'lowpass', 1, 200); tone(140, 0.2, 'sawtooth', 0.2, -90); },
    turret() { tone(520, 0.06, 'square', 0.05, -200); },
    hit() { noise(0.09, 0.14, 900, 'bandpass', 3, 300); tone(180, 0.08, 'square', 0.05, -80); },
    squish() { noise(0.18, 0.2, 700, 'lowpass', 2, 120); tone(220, 0.14, 'sine', 0.12, -150); },
    kill() { noise(0.28, 0.22, 1200, 'lowpass', 1, 150); tone(260, 0.2, 'triangle', 0.12, -200); },
    growl() { tone(70 + Math.random() * 25, 0.55, 'sawtooth', 0.09, -20); noise(0.5, 0.05, 400, 'lowpass', 4, 150); },
    moan() { tone(110, 0.8, 'sawtooth', 0.07, -35); tone(112, 0.8, 'triangle', 0.07, -35, 0.02); },
    ghost() { tone(520, 0.9, 'sine', 0.06, 300); tone(530, 0.9, 'sine', 0.05, -200, 0.1); },
    boom() { noise(0.7, 0.55, 600, 'lowpass', 1, 60); tone(70, 0.5, 'sine', 0.5, -45); },
    hurt() { tone(200, 0.2, 'sawtooth', 0.18, -120); noise(0.12, 0.12, 1000, 'bandpass', 1, 300); },
    heal() { tone(440, 0.12, 'sine', 0.16); tone(554, 0.12, 'sine', 0.16, 0, 0.1); tone(880, 0.25, 'sine', 0.16, 0, 0.2); },
    battery() { tone(330, 0.07, 'square', 0.08); tone(660, 0.14, 'square', 0.08, 0, 0.07); noise(0.1, 0.05, 4000, 'highpass', 1, 6000, 0.1); },
    pickup() { tone(700, 0.07, 'triangle', 0.1); tone(1050, 0.12, 'triangle', 0.1, 0, 0.06); },
    place() { noise(0.12, 0.2, 500, 'lowpass', 1, 200); tone(110, 0.12, 'square', 0.1, -30); },
    trap() { noise(0.12, 0.25, 3500, 'highpass', 1, 1500); tone(900, 0.06, 'square', 0.07); },
    wood() { noise(0.14, 0.2, 700, 'bandpass', 2, 250); },
    wave() { tone(196, 0.5, 'sawtooth', 0.1); tone(185, 0.5, 'sawtooth', 0.1, 0, 0.0); tone(147, 0.9, 'sawtooth', 0.1, 0, 0.35); noise(0.9, 0.06, 300, 'lowpass', 1, 100); },
    boss() { tone(65, 1.4, 'sawtooth', 0.2, -10); tone(98, 1.4, 'sawtooth', 0.12, -20, 0.1); noise(1.4, 0.15, 200, 'lowpass', 1, 60); },
    win() { [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.25, 'triangle', 0.17, 0, i * 0.13)); },
    lose() { [330, 262, 220, 165].forEach((f, i) => tone(f, 0.5, 'sawtooth', 0.12, -20, i * 0.28)); },
    bark() { noise(0.1, 0.22, 1100, 'bandpass', 3, 500); tone(380, 0.1, 'sawtooth', 0.1, -150); },
    moo() { tone(150, 0.9, 'sawtooth', 0.04, 30); },
    bat() { tone(2400, 0.05, 'square', 0.015, 400); }
  };
  A.sfx = function (n) { if (A.ready && SFX[n]) { try { SFX[n](); } catch (e) { /* */ } } };

  /* ---- ambience ---- */
  function startWind() {
    const c = A.ctx;
    const s = c.createBufferSource(); s.buffer = A.noiseBuf; s.loop = true;
    const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 420; f.Q.value = 0.9;
    const g = c.createGain(); g.gain.value = 0.05;
    const lfo = c.createOscillator(); lfo.frequency.value = 0.12;
    const lg = c.createGain(); lg.gain.value = 260;
    lfo.connect(lg); lg.connect(f.frequency);
    const lfo2 = c.createOscillator(); lfo2.frequency.value = 0.07;
    const lg2 = c.createGain(); lg2.gain.value = 0.03;
    lfo2.connect(lg2); lg2.connect(g.gain);
    s.connect(f); f.connect(g); g.connect(A.ambG);
    s.start(); lfo.start(); lfo2.start();
  }
  function pan(v) {
    const c = A.ctx;
    if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = v; p.connect(A.ambG); return p; }
    return A.ambG;
  }
  const AMB = [
    () => { const p = pan(U.rnd(-1, 1)); tone(390, 0.35, 'sine', 0.05, -50, 0, p); tone(380, 0.35, 'sine', 0.05, -60, 0.5, p); tone(390, 0.5, 'sine', 0.05, -80, 0.9, p); },
    () => { const p = pan(U.rnd(-1, 1)); tone(280, 1.8, 'sine', 0.035, 260, 0, p); tone(540, 1.8, 'sine', 0.03, -160, 0.5, p); },
    () => { const p = pan(U.rnd(-1, 1)); for (let i = 0; i < 3; i++) { tone(900, 0.2, 'sawtooth', 0.025, -300, i * 0.3, p); } },
    () => { const p = pan(U.rnd(-1, 1)); for (let i = 0; i < 12; i++) tone(4200 + (i % 2) * 150, 0.04, 'square', 0.006, 0, i * 0.07, p); },
    () => { const p = pan(U.rnd(-1, 1)); tone(70, 1.2, 'sawtooth', 0.02, 40, 0, p); noise(1, 0.012, 600, 'bandpass', 5, 900, 0, p); },
    () => { const p = pan(U.rnd(-1, 1)); noise(1.6, 0.02, 800, 'bandpass', 2, 200, 0, p); }
  ];
  function scheduleAmbient() {
    if (A.ready && NW.store.p.settings.sfx > 0) U.pick(AMB)();
    setTimeout(scheduleAmbient, 3500 + Math.random() * 6000);
  }

  /* ---- music: sparse tense loop in D minor ---- */
  const hz = n => 440 * Math.pow(2, (n - 69) / 12);
  const CH = [[50, 53, 57], [46, 50, 53], [43, 46, 50], [45, 49, 52]]; // Dm, Bb, Gm, A
  const BASS = [38, 38, 41, 38, 33, 38, 36, 38];
  const SCALE = [74, 77, 79, 81, 82, 84, 85, 86, 89];
  let step = 0, nextT = 0;
  function startMusic() {
    const c = A.ctx; nextT = c.currentTime + 0.3;
    setInterval(() => {
      if (!A.ready || NW.store.p.settings.music <= 0) { nextT = Math.max(nextT, A.ctx.currentTime); return; }
      const dur = 60 / (66 + A.intensity * 24) / 2;
      while (nextT < A.ctx.currentTime + 0.5) { playStep(nextT, dur); nextT += dur; step++; }
    }, 120);
  }
  function mt(f, d, type, v, t, dest) {
    const c = A.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + Math.min(0.08, d * 0.3)); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(dest || A.musG); o.start(t); o.stop(t + d + 0.05);
  }
  function playStep(t, dur) {
    const bar = Math.floor(step / 8) % 4, st = step % 8, I = A.intensity;
    if (st === 0) { // pad chord
      CH[bar].forEach(n => { mt(hz(n), dur * 8.5, 'triangle', 0.05, t); mt(hz(n) * 1.005, dur * 8.5, 'sine', 0.04, t); });
    }
    if (st % 2 === 0) mt(hz(BASS[st]), dur * 1.8, 'sawtooth', 0.045 + I * 0.02, t, A.musG);
    if (I > 0.15 && (st === 0 || st === 4 || (I > 0.6 && st === 6))) { // heartbeat
      mt(55, 0.18, 'sine', 0.3 + I * 0.2, t); mt(50, 0.18, 'sine', 0.2, t + 0.16);
    }
    if (Math.random() < 0.28 + I * 0.15) { // music-box notes
      const n = SCALE[Math.floor(Math.random() * SCALE.length)];
      mt(hz(n), dur * 3, 'sine', 0.05, t); mt(hz(n) * 2, dur * 1.5, 'sine', 0.015, t);
    }
    if (I > 0.5 && st % 2 === 1) mt(hz(BASS[st]) * 2, dur * 0.6, 'square', 0.012, t);
  }
  A.setIntensity = v => { A.intensity = U.clamp(v, 0, 1); };
})();
