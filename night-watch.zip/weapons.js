/* Weapons: flashlight beams, shotgun, rifle, projectiles, turret shots */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U;
  const WP = NW.weapons = { proj: [], flashFx: null, shake: 0 };

  WP.defs = {
    flash: { id: 'flash', name: 'Flashlight', desc: 'Blinding flash cone. Ghosts hate it.', kind: 'beam', dmg: 8, rate: 0.4, range: 52, arc: 1.15, knock: 60, ghost: 2.6, bat: 1.1, ammo: 0, icon: 'flash', lightBonus: 1 },
    flash2: { id: 'flash2', name: 'Heavy Flashlight', desc: 'Bigger beam, double damage, wider light.', kind: 'beam', dmg: 16, rate: 0.36, range: 70, arc: 1.4, knock: 90, ghost: 3, bat: 1.4, ammo: 0, icon: 'flash2', lightBonus: 1.3 },
    shotgun: { id: 'shotgun', name: 'Shotgun', desc: 'Spread of pellets. Uses shells.', kind: 'spread', dmg: 8, pellets: 7, spread: 0.46, rate: 0.85, speed: 340, life: 0.5, pierce: 0, knock: 110, ammo: 1, icon: 'shotgun', lightBonus: 1 },
    rifle: { id: 'rifle', name: 'Lever Rifle', desc: 'Piercing high damage shot. Uses shells.', kind: 'bullet', dmg: 42, rate: 0.52, speed: 600, life: 0.7, pierce: 2, knock: 80, ammo: 1, icon: 'rifle', lightBonus: 1 }
  };
  WP.order = ['flash', 'flash2', 'shotgun', 'rifle'];

  WP.owned = () => WP.order.filter(id => NW.store.p.owned[id]);
  WP.dmgMult = () => 1 + 0.2 * NW.store.p.upg.dmg;
  WP.rateMult = () => 1 / (1 + 0.12 * NW.store.p.upg.rate);

  // returns true if fired
  WP.fire = function (pl, ang) {
    const d = WP.defs[NW.store.p.weapon]; if (!d || pl.cd > 0 || !pl.alive) return false;
    const inv = NW.store.p.inv, mult = WP.dmgMult();
    if (d.ammo && inv.ammo < d.ammo) {
      pl.cd = 0.3; NW.audio.sfx('click');
      if (!WP.warnT || WP.warnT < performance.now() - 1200) { WP.warnT = performance.now(); NW.ui.toast('Out of shells!', 'bad'); }
      return false;
    }
    pl.cd = d.rate * WP.rateMult();
    pl.kick = 1; pl.fireAng = ang;
    const ox = pl.x + Math.cos(ang) * 11, oy = pl.y - 3 + Math.sin(ang) * 11;
    if (d.kind === 'beam') {
      let dmg = d.dmg * mult, batOK = pl.battery > 0;
      if (!batOK) dmg *= 0.5;
      pl.battery = Math.max(0, pl.battery - d.bat);
      const range = d.range * (1 + 0.12 * NW.store.p.upg.range);
      WP.flashFx = { t: 0.16, max: 0.16, x: pl.x, y: pl.y - 3, ang, range, arc: d.arc };
      NW.audio.sfx('flash');
      NW.enemies.list.forEach(e => {
        const dx = e.x - pl.x, dy = e.y - (pl.y - 3), dist = Math.hypot(dx, dy);
        if (dist > range + e.r) return;
        const ad = Math.abs(U.angDiff(ang, Math.atan2(dy, dx)));
        if (ad > d.arc / 2 + Math.atan2(e.r, Math.max(dist, 1))) return;
        NW.enemies.damage(e, dmg * (e.type === 'ghost' ? d.ghost : 1), ang, d.knock, { beam: true });
      });
      // flashlight can also smack structures? no.
      NW.fx.burst(ox, oy, 6, ['#fff6b0', '#ffd23a', '#fff'], 80, 0.3, ang, 0.6);
    } else {
      inv.ammo -= d.ammo;
      const n = d.kind === 'spread' ? d.pellets : 1;
      for (let i = 0; i < n; i++) {
        const a = ang + (n > 1 ? (Math.random() - 0.5) * d.spread : 0), sp = d.speed * (0.9 + Math.random() * 0.2);
        WP.proj.push({ x: ox, y: oy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, dmg: d.dmg * mult, life: d.life, pierce: d.pierce, hit: [], knock: d.knock, kind: d.kind, a });
      }
      NW.audio.sfx(d.kind === 'spread' ? 'shot' : 'rifle');
      NW.fx.burst(ox, oy, 8, ['#fff6b0', '#ffb02a', '#ff7a1a'], 130, 0.25, ang, 0.5);
      NW.fx.addLight(ox, oy, 90, '255,200,100', 1.2, 0.09);
      WP.shake = Math.max(WP.shake, d.kind === 'spread' ? 3.2 : 2);
      pl.recoil = { x: -Math.cos(ang) * 22, y: -Math.sin(ang) * 22 };
    }
    return true;
  };

  WP.turretShot = function (s, tx, ty) {
    const ox = s.x + 7, oy = s.y - 8, a = Math.atan2(ty - oy, tx - ox);
    WP.proj.push({ x: ox + Math.cos(a) * 8, y: oy + Math.sin(a) * 8, vx: Math.cos(a) * 300, vy: Math.sin(a) * 300, dmg: 9 + NW.game.night, life: 0.6, pierce: 0, hit: [], knock: 40, kind: 'turret', a });
    NW.audio.sfx('turret');
    NW.fx.addLight(ox, oy, 40, '120,230,255', 1, 0.07);
    s.ang = a;
  };

  WP.update = function (dt) {
    if (WP.flashFx) { WP.flashFx.t -= dt; if (WP.flashFx.t <= 0) WP.flashFx = null; }
    WP.shake = Math.max(0, WP.shake - dt * 14);
    const P = WP.proj;
    for (let i = P.length - 1; i >= 0; i--) {
      const p = P[i];
      p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt;
      let dead = p.life <= 0 || p.x < 0 || p.y < 0 || p.x > NW.W || p.y > NW.H;
      if (!dead && NW.farm.blockedAt(p.x, p.y, 1)) {
        // pass over low things? bullets stop at solid
        dead = true; NW.fx.burst(p.x, p.y, 3, ['#fff6b0', '#aaa'], 40, 0.2);
      }
      if (!dead) {
        const list = NW.enemies.list;
        for (let j = 0; j < list.length; j++) {
          const e = list[j]; if (e.dead || p.hit.indexOf(e) >= 0) continue;
          if (e.type === 'ghost' && e.ph > 0.85) continue;
          if (Math.hypot(e.x - p.x, (e.y - e.r * 0.5 - (e.fly ? 6 : 0)) - p.y) < e.r + 2.5) {
            p.hit.push(e);
            NW.enemies.damage(e, p.dmg, p.a, p.knock, { bullet: true });
            if (p.pierce-- <= 0) { dead = true; break; }
          }
        }
      }
      if (dead) P.splice(i, 1);
    }
  };

  WP.draw = function (g) {
    WP.proj.forEach(p => {
      const x = Math.round(p.x), y = Math.round(p.y);
      if (p.kind === 'turret') { U.line(g, '#2e9ac8', p.x - p.vx * 0.03, p.y - p.vy * 0.03, p.x, p.y, 2); g.fillStyle = '#c8f6ff'; g.fillRect(x - 1, y - 1, 3, 3); }
      else if (p.kind === 'bullet') { U.line(g, '#ffb02a', p.x - p.vx * 0.035, p.y - p.vy * 0.035, p.x, p.y, 2); g.fillStyle = '#fff6c0'; g.fillRect(x - 1, y - 1, 3, 3); }
      else { U.line(g, '#ff9a2e', p.x - p.vx * 0.02, p.y - p.vy * 0.02, p.x, p.y, 1); g.fillStyle = '#fff0a0'; g.fillRect(x, y, 2, 2); }
    });
  };
})();
