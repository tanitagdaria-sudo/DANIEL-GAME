/* Shop catalog, prices, purchase logic */
(function () {
  'use strict';
  const NW = window.NW;
  const SH = NW.shop = {};

  const UP = (id, name, desc, icon, base, max) => ({ id, cat: 'upgrades', name, desc, icon, base, max, type: 'upgrade' });
  SH.items = [
    { id: 'flash', cat: 'weapons', name: 'Flashlight', desc: 'Starter. Flash cone, drains battery.', icon: 'flash', price: 0, type: 'weapon' },
    { id: 'flash2', cat: 'weapons', name: 'Heavy Flashlight', desc: 'x2 damage, longer beam, brighter light.', icon: 'flash2', price: 120, type: 'weapon' },
    { id: 'shotgun', cat: 'weapons', name: 'Shotgun', desc: '7 pellets per shot. Needs shells.', icon: 'shotgun', price: 260, type: 'weapon' },
    { id: 'rifle', cat: 'weapons', name: 'Lever Rifle', desc: 'Piercing shots, huge damage.', icon: 'rifle', price: 560, type: 'weapon' },
    UP('dmg', 'Damage +20%', 'All weapons hit harder.', 'dmg', 60, 8),
    UP('rate', 'Attack Speed +12%', 'Shorter delay between attacks.', 'rate', 60, 8),
    UP('hp', 'Max Health +20', 'Tougher watchman.', 'hp', 50, 8),
    UP('range', 'Light Range +12%', 'Longer flashlight and flash reach.', 'range', 45, 8),
    UP('speed', 'Move Speed +7%', 'Run faster across the farm.', 'speed', 55, 6),
    { id: 'fence', cat: 'defense', name: 'Wooden Fence x5', desc: 'Pieces for the build menu.', icon: 'fence', price: 40, qty: 5, type: 'stock' },
    { id: 'barricade', cat: 'defense', name: 'Barricade x2', desc: 'Sturdy spiked walls.', icon: 'barricade', price: 55, qty: 2, type: 'stock' },
    { id: 'trap', cat: 'defense', name: 'Spike Trap x2', desc: 'Damages and slows monsters.', icon: 'trap', price: 70, qty: 2, type: 'stock' },
    { id: 'turret', cat: 'defense', name: 'Pumpkin Sentry', desc: 'Automatic defence device.', icon: 'turret', price: 190, qty: 1, type: 'stock' },
    { id: 'repair', cat: 'defense', name: 'Repair Barn +50', desc: 'Fix the barn and all fences.', icon: 'repair', price: 40, type: 'repair' },
    { id: 'ammo', cat: 'supplies', name: 'Shells x10', desc: 'Ammo for shotgun and rifle.', icon: 'ammo', price: 30, qty: 10, type: 'inv' },
    { id: 'battery', cat: 'supplies', name: 'Battery x2', desc: 'Recharge the flashlight (F).', icon: 'battery', price: 25, qty: 2, type: 'inv' },
    { id: 'medkit', cat: 'supplies', name: 'Medkit', desc: 'Restores 50% health (H).', icon: 'medkit', price: 35, qty: 1, type: 'inv' }
  ];
  SH.cats = [['weapons', 'WEAPONS'], ['upgrades', 'UPGRADES'], ['defense', 'DEFENSE'], ['supplies', 'SUPPLIES']];

  SH.level = it => NW.store.p.upg[it.id] || 0;
  SH.price = it => it.type === 'upgrade' ? Math.round(it.base * Math.pow(1.55, SH.level(it))) : it.price;
  // returns {ok, label, reason}
  SH.status = function (it) {
    const p = NW.store.p;
    if (it.type === 'weapon') {
      if (p.owned[it.id]) return { owned: true, label: p.weapon === it.id ? 'EQUIPPED' : 'EQUIP', reason: '' };
      if (p.coins < it.price) return { ok: false, label: it.price, reason: 'Not enough coins' };
      return { ok: true, label: it.price };
    }
    if (it.type === 'upgrade') {
      if (SH.level(it) >= it.max) return { maxed: true, label: 'MAX', reason: 'Maxed' };
      const pr = SH.price(it); if (p.coins < pr) return { ok: false, label: pr, reason: 'Not enough coins' };
      return { ok: true, label: pr };
    }
    if (it.type === 'repair') {
      if (NW.game.barnHp >= NW.game.barnMax && !NW.farm.structs.some(s => s.type !== 'trap' && s.hp < s.max)) return { ok: false, label: it.price, reason: 'Nothing to repair' };
      if (p.coins < it.price) return { ok: false, label: it.price, reason: 'Not enough coins' };
      return { ok: true, label: it.price };
    }
    if (p.coins < it.price) return { ok: false, label: it.price, reason: 'Not enough coins' };
    return { ok: true, label: it.price };
  };
  SH.count = function (it) {
    const p = NW.store.p;
    if (it.type === 'upgrade') return 'LV ' + SH.level(it) + '/' + it.max;
    if (it.type === 'stock') return 'OWN ' + p.stock[it.id];
    if (it.type === 'inv') return 'OWN ' + p.inv[it.id];
    if (it.type === 'repair') return 'BARN ' + Math.round(NW.game.barnHp) + '/' + NW.game.barnMax;
    return '';
  };
  SH.buy = function (id) {
    const it = SH.items.find(i => i.id === id), p = NW.store.p; if (!it) return false;
    const st = SH.status(it);
    if (st.owned) { // equip
      p.weapon = it.id; NW.audio.sfx('click'); NW.ui.refresh(); NW.store.save(); return true;
    }
    if (!st.ok) { NW.audio.sfx('error'); NW.ui.toast(st.reason || 'Unavailable', 'bad'); return false; }
    const price = SH.price(it);
    p.coins -= price;
    if (it.type === 'weapon') { p.owned[it.id] = 1; p.weapon = it.id; }
    else if (it.type === 'upgrade') { p.upg[it.id]++; if (it.id === 'hp') { NW.player.hp += 20; } }
    else if (it.type === 'stock') p.stock[it.id] += it.qty;
    else if (it.type === 'inv') p.inv[it.id] += it.qty;
    else if (it.type === 'repair') { NW.game.barnHp = Math.min(NW.game.barnMax, NW.game.barnHp + 50); NW.farm.healAll(1); }
    NW.audio.sfx('buy');
    NW.store.save(); NW.ui.refresh();
    NW.ui.toast('Purchased: ' + it.name, 'good');
    return true;
  };
})();
