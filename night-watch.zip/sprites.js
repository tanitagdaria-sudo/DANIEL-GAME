/* Procedural pixel-art sprites: environment, props, structures, inventory icons.
   Everything is painted once into offscreen canvases (no external image files). */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U;
  const R = U.R, disc = U.disc, ell = U.ell, line = U.line;
  const OUT = '#0e0a14';
  const SP = NW.spr = { icons: {}, tree: [] };
  const P = {
    red: '#a3362b', red2: '#8a2a22', red3: '#c04a36', redD: '#5e1c19',
    wood: '#7a4a28', wood2: '#9a6436', wood3: '#4e2e1a', woodL: '#b8814a',
    hay: '#dcae45', hay2: '#b0832c', hay3: '#f0cc6a',
    stone: '#7a7886', stone2: '#55536a', stone3: '#9b99ac',
    slate: '#2f2b42', slate2: '#443f60', slate3: '#5c567e',
    cream: '#d9ceb4', orange: '#e8741e', orange2: '#b8500f', orange3: '#ff9a2e', green: '#3f7a3a', gold: '#ffd23a'
  };
  SP.P = P;

  /* ---------------- trees ---------------- */
  function mkTree(seed, H, leafy, web) {
    const rnd = U.rng(seed), w = Math.round(H * 1.0), [c, g] = U.mk(w, H);
    const segs = [], tips = [];
    function br(x, y, ang, len, th, depth) {
      for (let i = 0; i < len; i++) {
        x += Math.cos(ang); y += Math.sin(ang);
        ang += (rnd() - 0.5) * 0.22; th = Math.max(1, th * 0.987);
        segs.push([x, y, th]);
        if (depth < 3 && i > len * 0.25 && i % Math.max(4, Math.floor(len / 3)) === 0 && rnd() < 0.8) {
          const side = rnd() < 0.5 ? -1 : 1;
          br(x, y, ang + side * (0.45 + rnd() * 0.6), len * (0.45 + rnd() * 0.25), th * 0.7, depth + 1);
        }
      }
      tips.push([x, y]);
    }
    const bx = w / 2, by = H - 2;
    br(bx, by, -Math.PI / 2 + (rnd() - 0.5) * 0.2, H * 0.5, H * 0.075, 0);
    br(bx, by - H * 0.2, -Math.PI / 2 - 0.7, H * 0.32, H * 0.045, 1);
    br(bx, by - H * 0.3, -Math.PI / 2 + 0.75, H * 0.3, H * 0.045, 1);
    // roots
    for (let i = -1; i <= 1; i += 2) { for (let k = 0; k < 6; k++) segs.push([bx + i * (2 + k), by - 2 + Math.floor(k / 3), H * 0.07 - k * 0.4]); }
    segs.forEach(s => { const t = Math.max(1, Math.round(s[2])); R(g, OUT, s[0] - t / 2 - 1, s[1] - t / 2 - 1, t + 2, t + 2); });
    segs.forEach(s => { const t = Math.max(1, Math.round(s[2])); R(g, '#3b2a30', s[0] - t / 2, s[1] - t / 2, t, t); });
    segs.forEach(s => { const t = Math.round(s[2]); if (t >= 3) { R(g, '#5b5272', s[0] - t / 2, s[1] - t / 2, 1, t - 1); R(g, '#241a22', s[0] + t / 2 - 1, s[1] - t / 2, 1, t); } });
    // foliage
    tips.forEach(t => {
      if (leafy) {
        const r = 4 + Math.floor(rnd() * 5);
        disc(g, '#18281f', t[0], t[1], r); disc(g, '#233a2b', t[0] - 1, t[1] - 1, r - 1);
        if (rnd() < 0.5) disc(g, '#2b4a38', t[0] - 2, t[1] - 2, Math.max(1, r - 3));
        for (let k = 0; k < 2; k++) R(g, rnd() < 0.5 ? '#b3541c' : '#7b3a22', t[0] + (rnd() - 0.5) * r * 2, t[1] + (rnd() - 0.5) * r * 2, 2, 2);
      } else if (rnd() < 0.45) {
        for (let k = 0; k < 3; k++) R(g, rnd() < 0.5 ? '#a8501a' : '#6a3a22', t[0] + (rnd() - 0.5) * 6, t[1] + (rnd() - 0.5) * 6, 2, 2);
      }
    });
    if (web && tips.length > 2) {
      const a = tips[1], b = tips[2], m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + 3];
      g.globalAlpha = 0.55;
      line(g, '#e6ecff', a[0], a[1], m[0], m[1] + 6, 1); line(g, '#e6ecff', b[0], b[1], m[0], m[1] + 6, 1); line(g, '#e6ecff', a[0], a[1], b[0], b[1], 1);
      line(g, '#e6ecff', m[0], m[1], (a[0] + m[0]) / 2, m[1] + 4, 1); line(g, '#e6ecff', m[0], m[1], (b[0] + m[0]) / 2, m[1] + 4, 1);
      g.globalAlpha = 1;
    }
    R(g, 'rgba(0,0,0,0.35)', bx - 8, by, 16, 2);
    return c;
  }

  /* ---------------- barn / silo / windmill etc ---------------- */
  function mkBarn() {
    const [c, g] = U.mk(190, 150);
    const wx = 12, wy = 60, ww = 166, wh = 84;
    R(g, OUT, wx - 1, wy - 1, ww + 2, wh + 2);
    const rnd = U.rng(7);
    for (let x = 0; x < ww; x += 6) {
      R(g, (x / 6) % 2 ? P.red : P.red2, wx + x, wy, 6, wh);
      R(g, P.redD, wx + x, wy, 1, wh);
      for (let k = 0; k < 4; k++) R(g, rnd() < 0.5 ? P.red3 : P.redD, wx + x + 1 + rnd() * 3, wy + rnd() * wh, 1, 2 + rnd() * 3);
    }
    R(g, P.cream, wx, wy + wh - 6, ww, 6); R(g, '#a89c84', wx, wy + wh - 2, ww, 2);
    R(g, P.cream, wx, wy, 5, wh); R(g, P.cream, wx + ww - 5, wy, 5, wh); R(g, '#a89c84', wx + 4, wy, 1, wh);
    R(g, P.cream, wx, wy, ww, 3);
    // loft window
    R(g, OUT, 79, 66, 32, 24); R(g, P.cream, 80, 67, 30, 22); R(g, '#150b10', 83, 70, 24, 16);
    line(g, P.cream, 83, 70, 106, 85, 2); line(g, P.cream, 106, 70, 83, 85, 2);
    // doors
    R(g, OUT, 48, 92, 94, 52); R(g, '#0a050a', 76, 93, 38, 51);
    R(g, '#3a1a0e', 76, 138, 38, 6); R(g, '#7d4e18', 80, 128, 8, 10); R(g, P.hay, 95, 132, 14, 6);
    [[49, 93], [115, 93]].forEach(d => {
      R(g, P.cream, d[0], d[1], 26, 50); R(g, '#6a1f1b', d[0] + 3, d[1] + 3, 20, 44);
      line(g, P.cream, d[0] + 3, d[1] + 3, d[0] + 22, d[1] + 46, 2); line(g, P.cream, d[0] + 22, d[1] + 3, d[0] + 3, d[1] + 46, 2);
    });
    // roof
    for (let y = 6; y <= 64; y++) {
      const t = (y - 6) / 58, l = Math.round(30 * (1 - t)), r = 190 - l, row = Math.floor((y - 6) / 5);
      R(g, OUT, l, y, r - l, 1);
      const base = row % 2 ? P.slate : P.slate2;
      const off = (row % 2) * 5;
      for (let x = l + 1; x < r - 1; x += 10) {
        const x0 = Math.max(l + 1, x - off), x1 = Math.min(r - 1, x - off + 10);
        if (x1 > x0) { R(g, base, x0, y, x1 - x0 - 1, 1); R(g, '#1a1626', x1 - 1, y, 1, 1); }
      }
      if ((y - 6) % 5 === 4) R(g, '#1d1a2c', l + 1, y, r - l - 2, 1);
      R(g, P.slate3, l + 1, y, 2, 1);
    }
    R(g, P.slate3, 30, 6, 130, 2);
    R(g, '#07050c', 52, 28, 7, 5); R(g, '#07050c', 118, 40, 9, 5); R(g, '#07050c', 134, 20, 5, 4);
    R(g, '#1a0f14', 2, 64, 186, 5);
    // cobweb right wall corner
    g.globalAlpha = 0.6;
    for (let i = 0; i < 6; i++) line(g, '#e6ecff', 176, 70, 176 - i * 5, 70 + 22 - i * 2, 1);
    line(g, '#e6ecff', 176, 80, 160, 78, 1); line(g, '#e6ecff', 176, 88, 160, 86, 1);
    g.globalAlpha = 1;
    return c;
  }
  function mkSilo() {
    const [c, g] = U.mk(56, 124);
    const bands = ['#5a1a1e', '#7c2326', '#a32f2c', '#b9423a', '#a32f2c', '#8a2726', '#6a1d21', '#4a1519'];
    R(g, OUT, 3, 24, 50, 94);
    for (let i = 0; i < 8; i++) R(g, bands[i], 4 + i * 6, 25, 6, 92);
    for (let y = 30; y < 114; y += 10) { R(g, 'rgba(30,6,12,0.55)', 4, y, 48, 1); }
    for (let k = 0; k < 18; k++) R(g, '#5a1a1e', 6 + Math.random() * 40, 28 + Math.random() * 84, 1, 3);
    ell(g, OUT, 28, 118, 25, 5); ell(g, '#46445a', 28, 117, 24, 4);
    ell(g, OUT, 28, 26, 26, 14); ell(g, '#2f2d42', 28, 25, 25, 13); ell(g, '#4a4766', 26, 21, 20, 9); ell(g, '#625d86', 22, 17, 10, 4);
    R(g, OUT, 30, 4, 4, 8); R(g, '#3b385a', 30, 5, 3, 7);
    // ladder
    R(g, '#d0b88a', 33, 28, 2, 90); R(g, '#d0b88a', 41, 28, 2, 90);
    for (let y = 32; y < 116; y += 5) R(g, '#d0b88a', 33, y, 10, 1);
    return c;
  }
  function mkWindTower() {
    const [c, g] = U.mk(56, 96);
    for (let y = 18; y < 94; y++) {
      const t = (y - 18) / 76, hw = Math.round(7 + t * 14);
      R(g, OUT, 28 - hw - 1, y, hw * 2 + 2, 1); R(g, P.wood3, 28 - hw, y, hw * 2, 1);
    }
    for (let y = 22; y < 92; y += 14) {
      const t = (y - 18) / 76, hw = Math.round(7 + t * 14), t2 = (y + 14 - 18) / 76, hw2 = Math.round(7 + t2 * 14);
      line(g, P.wood2, 28 - hw, y, 28 + hw2, y + 14, 1); line(g, P.wood2, 28 + hw, y, 28 - hw2, y + 14, 1); R(g, P.wood2, 28 - hw2, y + 14, hw2 * 2, 1);
    }
    R(g, P.wood2, 7, 90, 3, 5); R(g, P.wood2, 46, 90, 3, 5);
    R(g, OUT, 20, 8, 16, 16); R(g, '#4b3622', 21, 9, 14, 14); R(g, '#6a4a2e', 21, 9, 14, 3);
    return c;
  }
  function mkWell() {
    const [c, g] = U.mk(56, 66);
    ell(g, OUT, 28, 48, 24, 14);
    ell(g, P.stone2, 28, 46, 23, 13); ell(g, P.stone, 28, 44, 21, 11); ell(g, '#10202c', 28, 44, 15, 7); ell(g, '#1d3a4c', 26, 43, 11, 4);
    for (let i = 0; i < 18; i++) { const a = i / 18 * U.TAU; R(g, i % 2 ? P.stone3 : P.stone2, 28 + Math.cos(a) * 21 - 2, 44 + Math.sin(a) * 11 - 1, 4, 3); }
    R(g, OUT, 6, 20, 5, 32); R(g, P.wood2, 7, 21, 3, 30); R(g, OUT, 45, 20, 5, 32); R(g, P.wood2, 46, 21, 3, 30);
    for (let y = 2; y < 24; y++) { const hw = 6 + Math.round((y - 2) * 1.3); R(g, OUT, 28 - hw, y, hw * 2, 1); R(g, y % 4 < 2 ? P.slate2 : P.slate, 28 - hw + 1, y, hw * 2 - 2, 1); }
    R(g, P.slate3, 14, 14, 10, 1);
    R(g, '#2a1c12', 20, 28, 16, 3); R(g, P.woodL, 24, 31, 1, 8);
    return c;
  }
  function mkShed() {
    const [c, g] = U.mk(92, 86);
    R(g, OUT, 5, 36, 82, 48);
    for (let x = 0; x < 80; x += 5) { R(g, (x / 5) % 2 ? P.wood : P.wood2, 6 + x, 37, 5, 46); R(g, P.wood3, 6 + x, 37, 1, 46); }
    R(g, OUT, 36, 52, 22, 32); R(g, '#150a08', 37, 53, 20, 31); R(g, P.wood3, 33, 50, 4, 34); R(g, P.wood3, 57, 50, 4, 34);
    R(g, OUT, 10, 50, 14, 14); R(g, '#d6a843', 11, 51, 12, 12); R(g, '#ffe28a', 13, 53, 8, 8); R(g, P.wood3, 16, 51, 2, 12);
    for (let y = 4; y < 40; y++) {
      const t = (y - 4) / 36, l = Math.round(16 * (1 - t) - 2), r = 92 - l, row = Math.floor((y - 4) / 4);
      R(g, OUT, l, y, r - l, 1); R(g, row % 2 ? P.slate : P.slate2, l + 1, y, r - l - 2, 1);
      for (let x = l + 2 + (row % 2) * 4; x < r - 2; x += 8) R(g, '#1a1626', x, y, 1, 1);
      R(g, P.slate3, l + 1, y, 1, 1);
    }
    R(g, '#1a0f14', 2, 40, 88, 4);
    return c;
  }
  function mkCart(kind) {
    const [c, g] = U.mk(60, 44);
    R(g, 'rgba(0,0,0,0.35)', 6, 32, 48, 8);
    R(g, OUT, 6, 14, 48, 22); R(g, P.wood, 7, 15, 46, 20);
    for (let x = 0; x < 46; x += 6) R(g, P.wood3, 7 + x, 15, 1, 20);
    R(g, P.wood2, 7, 15, 46, 3); R(g, P.wood3, 7, 33, 46, 2);
    if (kind === 1) { ell(g, P.hay2, 30, 12, 20, 10); ell(g, P.hay, 30, 10, 19, 8); ell(g, P.hay3, 26, 7, 10, 4); for (let i = 0; i < 20; i++) R(g, P.hay2, 12 + Math.random() * 36, 4 + Math.random() * 12, 3, 1); }
    if (kind === 2) { [[16, 12, 6], [28, 9, 7], [41, 12, 6], [22, 6, 5], [35, 5, 5]].forEach(p => { disc(g, OUT, p[0], p[1], p[2] + 1); disc(g, P.orange, p[0], p[1], p[2]); disc(g, P.orange3, p[0] - 2, p[1] - 2, Math.max(1, p[2] - 3)); R(g, P.orange2, p[0] + 1, p[1] - p[2] + 1, 1, p[2] * 2 - 2); R(g, '#3f6a2a', p[0] - 1, p[1] - p[2] - 2, 2, 3); }); }
    [[12, 36], [48, 36]].forEach(w => { disc(g, OUT, w[0], w[1], 7); disc(g, P.wood3, w[0], w[1], 6); disc(g, P.wood, w[0], w[1], 5); disc(g, P.wood3, w[0], w[1], 2); line(g, P.wood3, w[0] - 5, w[1], w[0] + 5, w[1], 1); line(g, P.wood3, w[0], w[1] - 5, w[0], w[1] + 5, 1); });
    R(g, P.wood3, 0, 22, 8, 3); R(g, OUT, 0, 21, 2, 5);
    return c;
  }
  function mkHay(v) {
    const [c, g] = U.mk(32, 28);
    ell(g, 'rgba(0,0,0,0.35)', 16, 24, 15, 3);
    ell(g, OUT, 16, 17, 15, 10); ell(g, P.hay2, 16, 16, 14, 9); ell(g, P.hay, 15, 13, 12, 8); ell(g, P.hay3, 11, 9, 6, 3);
    for (let i = 0; i < 26; i++) { const x = 4 + Math.random() * 24, y = 6 + Math.random() * 16; R(g, i % 2 ? P.hay2 : P.hay3, x, y, 3, 1); }
    if (v) { R(g, OUT, 14, 1, 4, 6); R(g, P.hay2, 15, 2, 2, 5); }
    return c;
  }
  function mkBarrel() {
    const [c, g] = U.mk(14, 18);
    ell(g, 'rgba(0,0,0,0.35)', 7, 16, 6, 2);
    R(g, OUT, 1, 3, 12, 13); R(g, P.wood, 2, 4, 10, 11); R(g, P.wood2, 2, 4, 3, 11); R(g, P.wood3, 9, 4, 3, 11);
    R(g, '#2a2a34', 1, 6, 12, 1); R(g, '#2a2a34', 1, 12, 12, 1);
    ell(g, OUT, 7, 4, 6, 3); ell(g, P.wood2, 7, 4, 5, 2); ell(g, P.wood3, 7, 4, 3, 1);
    return c;
  }
  function mkCrate() {
    const [c, g] = U.mk(16, 18);
    ell(g, 'rgba(0,0,0,0.35)', 8, 16, 7, 2);
    R(g, OUT, 1, 3, 14, 13); R(g, P.wood2, 2, 4, 12, 11); R(g, P.wood3, 2, 4, 12, 1); R(g, P.wood3, 2, 14, 12, 1);
    line(g, P.wood3, 3, 5, 12, 13, 1); line(g, P.wood3, 12, 5, 3, 13, 1); R(g, P.woodL, 3, 5, 1, 9);
    return c;
  }
  function mkGrave(v) {
    const [c, g] = U.mk(16, 22);
    ell(g, 'rgba(0,0,0,0.4)', 8, 20, 7, 2);
    if (v === 0) { R(g, OUT, 2, 5, 12, 15); R(g, OUT, 4, 3, 8, 3); R(g, '#8c8a9c', 3, 6, 10, 13); R(g, '#8c8a9c', 5, 4, 6, 3); R(g, '#b2b0c2', 3, 6, 3, 13); R(g, '#5a586e', 11, 6, 2, 13); R(g, '#3f5c34', 3, 17, 5, 2); R(g, '#3a3848', 7, 8, 2, 7); R(g, '#3a3848', 5, 10, 6, 2); }
    else if (v === 1) { R(g, OUT, 5, 1, 6, 19); R(g, OUT, 1, 6, 14, 6); R(g, '#8c8a9c', 6, 2, 4, 17); R(g, '#8c8a9c', 2, 7, 12, 4); R(g, '#b2b0c2', 6, 2, 1, 17); R(g, '#5a586e', 9, 2, 1, 17); R(g, '#3f5c34', 6, 17, 4, 2); }
    else { R(g, OUT, 3, 8, 10, 12); R(g, OUT, 5, 6, 6, 3); R(g, '#7c7a8c', 4, 9, 8, 10); R(g, '#7c7a8c', 6, 7, 4, 3); R(g, '#a2a0b4', 4, 9, 2, 10); R(g, '#3f5c34', 8, 17, 4, 2); R(g, '#3a3848', 7, 11, 2, 4); }
    return c;
  }
  function mkLanternPost(tall) {
    const h = tall ? 40 : 24, [c, g] = U.mk(20, h);
    R(g, 'rgba(0,0,0,0.4)', 4, h - 3, 9, 2);
    R(g, OUT, 4, 2, 5, h - 3); R(g, P.wood3, 5, 3, 3, h - 5); R(g, P.wood, 5, 3, 1, h - 5);
    R(g, OUT, 4, 1, 13, 4); R(g, P.wood3, 5, 2, 11, 2);
    R(g, OUT, 11, 4, 7, 11); R(g, '#1a1220', 12, 5, 5, 9); R(g, '#ffb53a', 13, 7, 3, 5); R(g, '#fff0a0', 14, 8, 1, 3); R(g, '#2a2030', 11, 4, 7, 1); R(g, '#2a2030', 11, 14, 7, 1);
    return c;
  }
  function mkJack() {
    const [c, g] = U.mk(16, 15);
    ell(g, 'rgba(0,0,0,0.4)', 8, 13, 7, 2);
    ell(g, OUT, 8, 8, 8, 6); ell(g, P.orange2, 8, 8, 7, 5); ell(g, P.orange, 8, 8, 6, 5); ell(g, P.orange3, 5, 6, 3, 2);
    R(g, P.orange2, 4, 4, 1, 8); R(g, P.orange2, 11, 4, 1, 8);
    R(g, OUT, 7, 0, 3, 4); R(g, '#4a7a2a', 8, 1, 2, 3);
    R(g, '#ffd43a', 4, 6, 3, 3); R(g, '#ffd43a', 9, 6, 3, 3); R(g, '#fff6b0', 5, 7, 1, 1); R(g, '#fff6b0', 10, 7, 1, 1);
    R(g, '#ffd43a', 5, 10, 6, 1); R(g, '#ffd43a', 6, 11, 4, 1); R(g, OUT, 7, 10, 1, 1); R(g, OUT, 9, 10, 1, 1);
    return c;
  }
  function mkPumpkin() {
    const [c, g] = U.mk(14, 12);
    ell(g, 'rgba(0,0,0,0.35)', 7, 11, 6, 1);
    ell(g, OUT, 7, 6, 7, 5); ell(g, P.orange2, 7, 6, 6, 4); ell(g, P.orange, 7, 6, 5, 4); ell(g, P.orange3, 4, 4, 2, 2);
    R(g, P.orange2, 4, 3, 1, 7); R(g, P.orange2, 9, 3, 1, 7); R(g, OUT, 6, 0, 2, 3); R(g, '#4a7a2a', 6, 0, 2, 2);
    return c;
  }
  function mkScarecrow() {
    const [c, g] = U.mk(30, 44);
    ell(g, 'rgba(0,0,0,0.4)', 15, 41, 8, 2);
    R(g, OUT, 13, 14, 4, 28); R(g, P.wood, 14, 15, 2, 26);
    R(g, OUT, 2, 19, 26, 4); R(g, P.wood2, 3, 20, 24, 2);
    R(g, OUT, 8, 16, 14, 16); R(g, '#6a2a3a', 9, 17, 12, 14); R(g, '#8a3a3a', 9, 17, 4, 14); R(g, '#3a1a22', 14, 26, 6, 5);
    R(g, P.hay, 2, 22, 3, 5); R(g, P.hay, 25, 22, 3, 5);
    ell(g, OUT, 15, 8, 9, 8); ell(g, P.orange, 15, 8, 8, 7); ell(g, P.orange3, 12, 5, 3, 2);
    R(g, '#ffe05a', 10, 6, 3, 3); R(g, '#ffe05a', 17, 6, 3, 3); R(g, '#ffe05a', 11, 11, 8, 1); R(g, '#ffe05a', 12, 12, 6, 1);
    R(g, OUT, 3, 0, 24, 2); R(g, '#4a3220', 8, -1, 14, 4);
    return c;
  }
  function mkStall() {
    const [c, g] = U.mk(64, 60);
    ell(g, 'rgba(0,0,0,0.4)', 32, 56, 28, 3);
    R(g, OUT, 6, 22, 4, 34); R(g, P.wood2, 7, 22, 2, 33); R(g, OUT, 54, 22, 4, 34); R(g, P.wood2, 55, 22, 2, 33);
    R(g, OUT, 5, 34, 54, 22); R(g, P.wood, 6, 35, 52, 20);
    for (let x = 0; x < 52; x += 6) R(g, P.wood3, 6 + x, 35, 1, 20);
    R(g, P.woodL, 6, 35, 52, 2);
    // goods
    R(g, '#3a8a5a', 12, 28, 4, 7); R(g, '#8a3ad6', 18, 29, 4, 6); R(g, '#e8e8f0', 26, 31, 8, 4); R(g, '#c43030', 28, 29, 4, 3);
    R(g, '#ffd23a', 46, 31, 5, 4); R(g, '#c8a010', 46, 34, 5, 1); disc(g, P.orange, 40, 32, 3);
    // awning
    for (let x = 0; x < 62; x += 8) { R(g, OUT, 1 + x, 10, 9, 14); R(g, (x / 8) % 2 ? '#7b2fa8' : '#e8741e', 2 + x, 10, 8, 12); R(g, (x / 8) % 2 ? '#9a4fc8' : '#ff9a2e', 2 + x, 10, 3, 12); R(g, (x / 8) % 2 ? '#7b2fa8' : '#e8741e', 3 + x, 22, 6, 2); }
    R(g, OUT, 1, 6, 62, 6); R(g, '#3a1a50', 2, 7, 60, 4);
    // sign
    R(g, OUT, 20, 0, 24, 9); R(g, P.wood3, 21, 1, 22, 7); R(g, P.gold, 24, 3, 3, 3); R(g, P.gold, 29, 3, 3, 3); R(g, P.gold, 34, 3, 3, 3); R(g, P.gold, 39, 3, 2, 3);
    return c;
  }
  function mkCrow() {
    const [c, g] = U.mk(12, 10);
    R(g, OUT, 2, 2, 8, 6); R(g, '#1c1a26', 3, 3, 6, 5); R(g, '#2c2a3c', 3, 3, 3, 2); R(g, OUT, 0, 3, 3, 2); R(g, '#e0a030', 0, 3, 2, 1); R(g, '#d8d8f0', 3, 3, 1, 1);
    R(g, OUT, 4, 8, 1, 2); R(g, OUT, 7, 8, 1, 2); R(g, OUT, 9, 5, 3, 2);
    return c;
  }
  function mkSkull() {
    const [c, g] = U.mk(10, 10);
    R(g, OUT, 1, 1, 8, 8); R(g, '#d8d0b8', 2, 2, 6, 5); R(g, '#d8d0b8', 3, 7, 4, 2); R(g, OUT, 3, 4, 1, 2); R(g, OUT, 6, 4, 1, 2); R(g, OUT, 5, 6, 1, 1);
    return c;
  }
  function mkTrough() {
    const [c, g] = U.mk(40, 20);
    R(g, OUT, 0, 4, 40, 15); R(g, P.wood2, 1, 5, 38, 13); R(g, '#2a6a9a', 3, 7, 34, 8); R(g, '#4a9acc', 5, 8, 14, 2); R(g, P.wood3, 1, 16, 38, 2);
    return c;
  }
  function mkSkeleton() {
    const [c, g] = U.mk(14, 28);
    ell(g, 'rgba(0,0,0,0.4)', 7, 26, 6, 2);
    R(g, '#cfc8b0', 5, 1, 5, 5); R(g, OUT, 6, 3, 1, 2); R(g, OUT, 8, 3, 1, 2);
    R(g, '#cfc8b0', 7, 6, 1, 8); for (let y = 7; y < 13; y += 2) R(g, '#cfc8b0', 4, y, 7, 1);
    R(g, '#cfc8b0', 5, 14, 1, 10); R(g, '#cfc8b0', 9, 14, 1, 10); R(g, '#cfc8b0', 2, 7, 1, 9); R(g, '#cfc8b0', 12, 7, 1, 9);
    return c;
  }

  /* ---------------- player structures ---------------- */
  function mkFence(vertical, hurt) {
    if (!vertical) {
      const [c, g] = U.mk(20, 16);
      R(g, OUT, 0, 0, 5, 16); R(g, P.wood2, 1, 1, 3, 14); R(g, P.woodL, 1, 1, 1, 14); R(g, '#d09a62', 0, 0, 5, 1);
      R(g, OUT, 4, 3, 16, 4); R(g, P.wood, 4, 4, 16, 2); R(g, P.woodL, 4, 4, 16, 1);
      R(g, OUT, 4, 9, 16, 4); R(g, P.wood, 4, 10, 16, 2); R(g, P.woodL, 4, 10, 16, 1);
      R(g, 'rgba(0,0,0,0.3)', 5, 14, 14, 2);
      if (hurt) { line(g, OUT, 7, 3, 10, 7, 1); line(g, OUT, 13, 9, 16, 13, 1); R(g, OUT, 9, 4, 2, 2); }
      return c;
    }
    const [c, g] = U.mk(10, 24);
    R(g, OUT, 2, 6, 6, 18); R(g, P.wood, 3, 8, 4, 14); R(g, P.woodL, 3, 8, 1, 14);
    R(g, OUT, 0, 0, 10, 10); R(g, P.wood2, 1, 1, 8, 8); R(g, P.woodL, 1, 1, 8, 2); R(g, P.wood3, 1, 7, 8, 2);
    R(g, 'rgba(0,0,0,0.3)', 2, 22, 7, 2);
    if (hurt) { line(g, OUT, 2, 2, 7, 7, 1); line(g, OUT, 4, 14, 6, 20, 1); }
    return c;
  }
  function mkBarricade(hurt) {
    const [c, g] = U.mk(20, 24);
    R(g, 'rgba(0,0,0,0.35)', 1, 20, 18, 3);
    R(g, OUT, 1, 4, 18, 18); R(g, P.wood, 2, 5, 16, 16); R(g, P.wood2, 2, 5, 16, 4);
    R(g, P.wood3, 2, 12, 16, 2);
    line(g, P.wood3, 3, 6, 16, 19, 2); line(g, P.wood3, 16, 6, 3, 19, 2);
    for (let x = 3; x < 18; x += 5) { R(g, OUT, x, 0, 3, 5); R(g, '#c8c8d8', x, 1, 2, 4); }
    R(g, '#3a3a48', 3, 8, 2, 2); R(g, '#3a3a48', 15, 8, 2, 2); R(g, '#3a3a48', 3, 17, 2, 2); R(g, '#3a3a48', 15, 17, 2, 2);
    if (hurt) { line(g, OUT, 5, 5, 11, 12, 1); line(g, OUT, 11, 12, 8, 20, 1); R(g, OUT, 12, 7, 3, 3); }
    return c;
  }
  function mkTrap(armed) {
    const [c, g] = U.mk(18, 18);
    R(g, OUT, 1, 3, 16, 14); R(g, '#3c3a4a', 2, 4, 14, 12); R(g, '#55536a', 2, 4, 14, 1);
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
      const x = 4 + i * 4, y = 6 + j * 4;
      if (armed) { R(g, OUT, x, y - 3, 3, 5); R(g, '#d8d8e8', x, y - 3, 2, 4); R(g, '#fff', x, y - 3, 1, 1); } else { R(g, '#8a8aa0', x, y, 3, 2); }
    }
    return c;
  }
  function mkTurretBase() {
    const [c, g] = U.mk(20, 28);
    R(g, 'rgba(0,0,0,0.4)', 3, 24, 14, 3);
    R(g, OUT, 4, 14, 12, 12); R(g, P.stone2, 5, 15, 10, 10); R(g, P.stone3, 5, 15, 3, 10); R(g, P.stone, 5, 15, 10, 2);
    R(g, OUT, 7, 10, 6, 6); R(g, P.wood3, 8, 11, 4, 5);
    ell(g, OUT, 10, 8, 8, 7); ell(g, '#2e6a9a', 10, 8, 7, 6); ell(g, '#4aa0d8', 8, 6, 3, 2);
    R(g, '#9af0ff', 6, 7, 3, 3); R(g, '#9af0ff', 11, 7, 3, 3); R(g, '#fff', 7, 8, 1, 1); R(g, '#fff', 12, 8, 1, 1); R(g, '#9af0ff', 7, 12, 6, 1);
    R(g, OUT, 9, 0, 2, 3);
    return c;
  }

  /* ---------------- inventory icons (16x16) ---------------- */
  function ic(name, fn) { const [c, g] = U.mk(16, 16); fn(g); SP.icons[name] = c; }
  function buildIcons() {
    const D = OUT;
    ic('flash', g => {
      line(g, D, 3, 13, 10, 6, 5); line(g, '#2b2e5a', 3, 13, 10, 6, 3); line(g, '#4a4f92', 3, 12, 9, 6, 1);
      line(g, D, 9, 4, 13, 8, 5); line(g, '#3a3d70', 10, 5, 12, 7, 3);
      R(g, '#ffe7a0', 12, 2, 3, 3); R(g, '#fff', 13, 3, 1, 1); R(g, '#fff2a8', 14, 1, 2, 1); R(g, '#fff2a8', 15, 4, 1, 2);
    });
    ic('flash2', g => {
      line(g, D, 2, 14, 9, 7, 6); line(g, '#2b2e5a', 2, 14, 9, 7, 4); line(g, '#ffb02a', 4, 12, 6, 10, 2); line(g, '#4a4f92', 2, 13, 8, 7, 1);
      line(g, D, 9, 5, 13, 9, 6); line(g, '#3a3d70', 9, 5, 12, 8, 4);
      R(g, '#fff6c0', 11, 1, 4, 4); R(g, '#fff', 12, 2, 2, 2); R(g, '#ffd23a', 15, 0, 1, 3); R(g, '#ffd23a', 10, 0, 1, 2);
    });
    ic('shotgun', g => {
      R(g, D, 0, 8, 6, 5); R(g, '#7a4a28', 0, 9, 6, 3); R(g, '#9a6436', 0, 9, 5, 1);
      R(g, D, 5, 6, 11, 4); R(g, '#6a6a7e', 6, 7, 10, 2); R(g, '#9a9ab0', 6, 7, 10, 1);
      R(g, D, 8, 9, 6, 3); R(g, '#7a4a28', 9, 10, 4, 1); R(g, D, 6, 10, 2, 3);
    });
    ic('rifle', g => {
      R(g, D, 0, 8, 5, 5); R(g, '#7a4a28', 0, 9, 5, 3); R(g, D, 4, 7, 12, 3); R(g, '#8a8a9e', 5, 8, 11, 1); R(g, '#4a4a5e', 5, 9, 11, 1);
      R(g, D, 6, 4, 6, 3); R(g, '#3a5a8a', 7, 5, 4, 1); R(g, '#9ad0ff', 7, 5, 1, 1);
      R(g, D, 7, 10, 3, 3); R(g, '#7a4a28', 7, 10, 3, 2);
    });
    ic('ammo', g => {
      [[3, 3], [8, 5]].forEach(p => { R(g, D, p[0] - 1, p[1] - 1, 6, 12); R(g, '#c43030', p[0], p[1], 4, 7); R(g, '#e85a4a', p[0], p[1], 1, 7); R(g, '#e8c040', p[0], p[1] + 7, 4, 3); R(g, '#fff0a0', p[0], p[1] + 7, 1, 3); });
    });
    ic('battery', g => {
      R(g, D, 3, 2, 10, 14); R(g, '#e8861e', 4, 4, 8, 11); R(g, '#ffb04a', 4, 4, 2, 11); R(g, '#b8560f', 10, 4, 2, 11);
      R(g, '#9a9ab0', 6, 1, 4, 3); R(g, D, 6, 0, 4, 1); R(g, '#2a1a10', 6, 7, 4, 5); R(g, '#ffe05a', 8, 7, 1, 2); R(g, '#ffe05a', 7, 9, 2, 1); R(g, '#ffe05a', 7, 10, 1, 2);
    });
    ic('medkit', g => {
      R(g, D, 5, 1, 6, 3); R(g, '#6a6a7e', 6, 2, 4, 1);
      R(g, D, 0, 3, 16, 12); R(g, '#e8e8f0', 1, 4, 14, 10); R(g, '#b8b8c8', 1, 12, 14, 2); R(g, '#fff', 1, 4, 14, 1);
      R(g, '#d62a2a', 6, 5, 4, 8); R(g, '#d62a2a', 4, 7, 8, 4); R(g, '#ff6a5a', 6, 5, 1, 8);
    });
    ic('seed', g => {
      ell(g, D, 8, 8, 4, 6); ell(g, '#e8b860', 8, 8, 3, 5); ell(g, '#fadf9a', 7, 6, 1, 2); R(g, '#a07a30', 9, 5, 1, 7);
    });
    ic('coin', g => {
      disc(g, D, 8, 8, 7); disc(g, '#c8860a', 8, 8, 6); disc(g, '#ffd23a', 8, 8, 5); disc(g, '#ffe88a', 7, 7, 2);
      R(g, '#c8860a', 7, 5, 2, 6); R(g, '#a06a08', 6, 6, 4, 1);
    });
    ic('heart', g => {
      disc(g, D, 5, 5, 4); disc(g, D, 11, 5, 4); R(g, D, 2, 6, 12, 3); for (let i = 0; i < 6; i++) R(g, D, 3 + i, 9 + i, 10 - i * 2, 1);
      disc(g, '#d62a3a', 5, 5, 3); disc(g, '#d62a3a', 11, 5, 3); R(g, '#d62a3a', 3, 6, 10, 3); for (let i = 0; i < 5; i++) R(g, '#d62a3a', 4 + i, 9 + i, 8 - i * 2, 1);
      R(g, '#ff8a8a', 4, 3, 2, 2);
    });
    ic('barn', g => { R(g, D, 1, 4, 14, 11); R(g, '#a3362b', 2, 6, 12, 8); R(g, '#5a5470', 2, 3, 12, 3); R(g, '#d9ceb4', 6, 8, 4, 6); R(g, '#150b10', 7, 9, 2, 5); R(g, '#d9ceb4', 2, 6, 12, 1); });
    ic('dmg', g => { line(g, D, 3, 13, 12, 4, 4); line(g, '#c8c8d8', 3, 13, 12, 4, 2); R(g, D, 11, 1, 4, 4); R(g, '#fff', 12, 2, 2, 2); R(g, '#7a4a28', 1, 12, 3, 3); R(g, '#ffd23a', 4, 10, 3, 1); });
    ic('rate', g => { R(g, D, 8, 0, 6, 8); R(g, '#ffd23a', 9, 1, 4, 6); R(g, D, 3, 6, 8, 3); R(g, '#ffd23a', 4, 7, 6, 1); R(g, D, 2, 8, 7, 8); R(g, '#ffb02a', 3, 9, 5, 5); R(g, '#fff0a0', 4, 9, 2, 3); });
    ic('hp', g => { SP.icons.heart && g.drawImage(SP.icons.heart, 0, 0); R(g, '#fff', 7, 6, 2, 6); R(g, '#fff', 5, 8, 6, 2); });
    ic('range', g => { disc(g, D, 8, 8, 7); disc(g, '#ffe28a', 8, 8, 5); disc(g, '#fff6c8', 8, 8, 3); R(g, '#ffd23a', 7, 0, 2, 2); R(g, '#ffd23a', 7, 14, 2, 2); R(g, '#ffd23a', 0, 7, 2, 2); R(g, '#ffd23a', 14, 7, 2, 2); });
    ic('speed', g => { R(g, D, 3, 4, 8, 9); R(g, '#7a4a28', 4, 5, 6, 7); R(g, D, 2, 11, 12, 4); R(g, '#9a6436', 3, 12, 10, 2); R(g, '#d8d8e8', 1, 5, 2, 1); R(g, '#d8d8e8', 0, 8, 3, 1); R(g, '#d8d8e8', 1, 11, 2, 1); });
    ic('fence', g => { R(g, D, 1, 2, 4, 12); R(g, '#9a6436', 2, 3, 2, 10); R(g, D, 11, 2, 4, 12); R(g, '#9a6436', 12, 3, 2, 10); R(g, D, 2, 5, 12, 3); R(g, '#b8814a', 3, 6, 10, 1); R(g, D, 2, 10, 12, 3); R(g, '#b8814a', 3, 11, 10, 1); });
    ic('barricade', g => { R(g, D, 1, 3, 14, 12); R(g, '#7a4a28', 2, 4, 12, 10); line(g, '#4e2e1a', 3, 5, 13, 13, 2); line(g, '#4e2e1a', 13, 5, 3, 13, 2); R(g, '#c8c8d8', 3, 1, 2, 3); R(g, '#c8c8d8', 7, 1, 2, 3); R(g, '#c8c8d8', 11, 1, 2, 3); });
    ic('trap', g => { R(g, D, 0, 9, 16, 6); R(g, '#4a485a', 1, 10, 14, 4); for (let i = 0; i < 4; i++) { R(g, D, 1 + i * 4, 2, 3, 8); R(g, '#e0e0f0', 2 + i * 4, 3, 1, 7); } });
    ic('turret', g => { R(g, D, 4, 9, 8, 7); R(g, '#7a7886', 5, 10, 6, 5); disc(g, D, 8, 6, 6); disc(g, '#2e6a9a', 8, 6, 5); R(g, '#9af0ff', 5, 5, 2, 2); R(g, '#9af0ff', 9, 5, 2, 2); R(g, '#9af0ff', 6, 9, 4, 1); });
    ic('repair', g => { line(g, D, 3, 13, 11, 5, 4); line(g, '#9a6436', 3, 13, 11, 5, 2); R(g, D, 9, 1, 6, 5); R(g, '#a0a0b8', 10, 2, 4, 3); });
    ic('quest', g => { R(g, D, 2, 1, 12, 14); R(g, '#e8d8a8', 3, 2, 10, 12); R(g, '#a07a30', 4, 4, 8, 1); R(g, '#a07a30', 4, 7, 8, 1); R(g, '#a07a30', 4, 10, 5, 1); });
  }

  SP.icon = name => SP.icons[name] || SP.icons.coin;
  SP.iconURL = (() => { const cache = {}; return name => cache[name] || (cache[name] = SP.icon(name).toDataURL()); })();

  SP.build = function () {
    if (SP.built) return; SP.built = true;
    buildIcons();
    SP.tree = [mkTree(11, 86, false, true), mkTree(23, 78, true, false), mkTree(37, 94, false, false), mkTree(41, 70, true, true), mkTree(53, 82, false, true)];
    SP.treeBig = [mkTree(101, 128, false, true), mkTree(133, 118, false, true)];
    SP.barn = mkBarn(); SP.silo = mkSilo(); SP.windTower = mkWindTower(); SP.well = mkWell(); SP.shed = mkShed();
    SP.cart = [mkCart(0), mkCart(1), mkCart(2)];
    SP.hay = [mkHay(0), mkHay(1)];
    SP.barrel = mkBarrel(); SP.crate = mkCrate();
    SP.grave = [mkGrave(0), mkGrave(1), mkGrave(2)];
    SP.post = mkLanternPost(false); SP.postTall = mkLanternPost(true);
    SP.jack = mkJack(); SP.pumpkin = mkPumpkin(); SP.scarecrow = mkScarecrow(); SP.stall = mkStall();
    SP.crow = mkCrow(); SP.skull = mkSkull(); SP.trough = mkTrough(); SP.skeleton = mkSkeleton();
    SP.fenceH = mkFence(false, false); SP.fenceHh = mkFence(false, true); SP.fenceV = mkFence(true, false); SP.fenceVh = mkFence(true, true);
    SP.barricade = mkBarricade(false); SP.barricadeH = mkBarricade(true);
    SP.trapUp = mkTrap(true); SP.trapDown = mkTrap(false); SP.turretBase = mkTurretBase();
  };
})();
