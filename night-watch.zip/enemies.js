/* Enemies: pumpkin monsters, zombie farmers, fast pumpkins, big pumpkins, ghosts and the Pumpkin King boss */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U, R = U.R, F = NW.farm;
  const OUT = '#0e0a14';
  const EN = NW.enemies = { list: [], defs: {} };

  EN.defs = {
    pumpkin: { name: 'Pumpkin Monster', hp: 34, speed: 36, r: 7, dmg: 8, reward: 5, rate: 1.0, aggro: 52 },
    zombie: { name: 'Zombie Farmer', hp: 85, speed: 21, r: 6, dmg: 14, reward: 10, rate: 1.1, aggro: 60 },
    fast: { name: 'Fast Pumpkin', hp: 20, speed: 74, r: 5, dmg: 7, reward: 15, rate: 0.8, aggro: 44, explode: true },
    big: { name: 'Big Pumpkin', hp: 280, speed: 25, r: 11, dmg: 26, reward: 50, rate: 1.3, aggro: 70 },
    ghost: { name: 'Ghost', hp: 32, speed: 33, r: 6, dmg: 7, reward: 20, rate: 1.2, aggro: 110, fly: true },
    king: { name: 'Pumpkin King', hp: 1200, speed: 20, r: 16, dmg: 40, reward: 150, rate: 1.5, aggro: 80, boss: true }
  };

  EN.alive = () => EN.list.filter(e => !e.dead).length;
  EN.clear = () => { EN.list.length = 0; };

  EN.spawn = function (type, key, night) {
    const d = EN.defs[type], n = night || NW.game.night;
    let sp = F.spawns[key] || F.spawns.S;
    let x = sp.x + U.rnd(-8, 8), y = sp.y + U.rnd(-4, 4);
    if (type === 'ghost') {
      const side = Math.floor(Math.random() * 3);
      if (side === 0) { x = U.rnd(0, 40); y = U.rnd(60, 260); } else if (side === 1) { x = U.rnd(728, 768); y = U.rnd(60, 260); } else { x = U.rnd(640, 760); y = U.rnd(340, 430); }
    }
    if (key === 'S') y = Math.min(y, 428);
    const hpM = 1 + 0.12 * (n - 1) + (d.boss ? 0.35 * (n / 5 - 1) : 0), spM = Math.min(1.5, 1 + 0.035 * (n - 1));
    const e = {
      type, d, x, y, hp: d.hp * hpM, max: d.hp * hpM, r: d.r, speed: d.speed * spM * U.rnd(0.92, 1.08), fly: !!d.fly, dmg: d.dmg * (1 + 0.06 * (n - 1)),
      reward: d.reward, vx: 0, vy: 1, kx: 0, ky: 0, flash: 0, atkCd: 0.5, spawnT: 0.7, t: Math.random() * 10, seed: Math.random() * 100,
      dead: false, deathT: 0, slow: 0, trapCd: 0, ph: 0, atk: 0, lx: x, ly: y, stuck: 0, nudge: 0, nx: 0, ny: 0, fy: 1, growlT: U.rnd(2, 8), slamT: 5, summonT: 8, slamAnim: 0, dash: 0, dashCd: U.rnd(1, 3), atBarn: false, wspd: 9
    };
    EN.list.push(e);
    NW.fx.burst(x, y - 4, 6, d.fly ? ['#cfe8ff', '#9ad0ff'] : ['#2a2030', '#4a3a28', '#6a4a30'], 40, 0.6);
    if (type === 'ghost') NW.audio.sfx('ghost'); else if (d.boss) NW.audio.sfx('boss'); else if (Math.random() < 0.35) NW.audio.sfx(type === 'zombie' ? 'moan' : 'growl');
    return e;
  };

  EN.damage = function (e, dmg, ang, knock, o) {
    if (e.dead) return;
    o = o || {};
    if (e.type === 'ghost' && e.ph > 0.82 && !o.beam) { NW.fx.text(e.x, e.y - 14, 'MISS', '#9ad0ff'); return; }
    e.hp -= dmg; e.flash = 0.13;
    const kres = e.d.boss ? 0.15 : e.type === 'big' ? 0.4 : 1;
    e.kx += Math.cos(ang) * (knock || 0) * kres; e.ky += Math.sin(ang) * (knock || 0) * kres;
    NW.fx.text(e.x + U.rnd(-4, 4), e.y - e.r * 2 - 4, Math.round(dmg), o.beam ? '#fff6a0' : '#ffd0a0');
    const cols = e.type === 'zombie' ? ['#7a9a5a', '#a83a3a'] : e.fly ? ['#cfe8ff', '#fff'] : ['#e8741e', '#ff9a2e', '#b8500f'];
    NW.fx.burst(e.x, e.y - e.r * 0.8, 4, cols, 70, 0.4, ang, 1);
    NW.audio.sfx(e.fly ? 'hit' : 'squish');
    if (e.hp <= 0) EN.kill(e);
  };

  EN.kill = function (e) {
    if (e.dead) return;
    e.dead = true; e.deathT = 0.4;
    const cx = e.x, cy = e.y - e.r * 0.8;
    if (e.fly) { NW.fx.burst(cx, cy, 16, ['#cfe8ff', '#9ad0ff', '#fff'], 60, 1.2, -Math.PI / 2, 1.2, true); }
    else if (e.type === 'zombie') NW.fx.burst(cx, cy, 16, ['#7a9a5a', '#a83a3a', '#2f4a8a', '#4a6a3a'], 110, 0.9);
    else NW.fx.burst(cx, cy, e.d.boss ? 50 : e.type === 'big' ? 28 : 16, ['#e8741e', '#ff9a2e', '#b8500f', '#4a7a2a', '#ffd23a'], 120, 0.9);
    NW.audio.sfx(e.d.boss ? 'boom' : 'kill');
    NW.fx.coins(e.x, e.y - 4, e.reward);
    NW.store.p.totalKills = (NW.store.p.totalKills || 0) + 1;
    NW.fx.drops(e);
    if (e.d.boss) { NW.game.shake(10); NW.fx.addLight(cx, cy, 160, '255,160,60', 1.5, 0.4); }
    NW.game.onKill(e);
  };

  function bite(e, s) {
    if (e.atkCd > 0) return;
    e.atkCd = e.d.rate; e.atk = 0.2;
    F.damageStruct(s, e.dmg * 0.7 * (e.d.boss ? 2 : 1));
    NW.audio.sfx('wood');
    if (s.type === 'barricade' && !s.dead) { EN.damage(e, 3 + NW.game.night * 0.5, Math.atan2(e.y - s.y, e.x - s.x), 20, { thorn: true }); }
    NW.fx.burst(s.x + s.w / 2, s.y + s.h / 2, 3, ['#9a6436', '#7a4a28'], 50, 0.4);
  }

  EN.update = function (dt, playing) {
    const L = EN.list, PL = NW.player, game = NW.game, bd = F.barn.door;
    const doorX = bd.x + bd.w / 2, doorY = bd.y + bd.h / 2;
    for (let i = L.length - 1; i >= 0; i--) {
      const e = L[i];
      if (e.dead) { e.deathT -= dt; if (e.deathT <= 0) L.splice(i, 1); continue; }
      e.t += dt; e.flash -= dt; e.atkCd -= dt; e.atk -= dt; e.trapCd -= dt; e.slow = Math.max(0, e.slow - dt); e.spawnT = Math.max(0, e.spawnT - dt);
      e.growlT -= dt; if (e.growlT <= 0) { e.growlT = U.rnd(5, 12); if (Math.random() < 0.5) NW.audio.sfx(e.type === 'zombie' ? 'moan' : e.fly ? 'ghost' : 'growl'); }
      let vx = 0, vy = 0, sp = e.speed * (e.slow > 0 ? 0.45 : 1) * (e.spawnT > 0 ? 0.4 : 1);
      const toP = U.dist(e.x, e.y, PL.x, PL.y);
      let chase = PL.alive && toP < e.d.aggro && (e.fly || F.lineClear(e.x, e.y, PL.x, PL.y));
      const dB = e.fly ? U.dist(e.x, e.y, doorX, doorY) : 0;
      const nearBarn = e.fly ? dB < 22 : (e.y < bd.y + bd.h + e.r + 8 && e.x > bd.x - 8 && e.x < bd.x + bd.w + 8);
      e.atBarn = nearBarn && !chase;
      if (e.atBarn) {
        // attack the barn
        if (e.atkCd <= 0) {
          e.atkCd = e.d.rate; e.atk = 0.25;
          if (e.d.explode) { NW.fx.burst(e.x, e.y - 6, 20, ['#ff9a2e', '#ffd23a', '#fff'], 140, 0.7); NW.audio.sfx('boom'); NW.fx.addLight(e.x, e.y, 70, '255,160,50', 1.3, 0.25); game.damageBarn(e.dmg * 1.8); e.reward = Math.ceil(e.reward * 0.5); EN.kill(e); continue; }
          game.damageBarn(e.dmg * (e.d.boss ? 1.2 : 1));
          NW.audio.sfx('wood'); NW.fx.burst(doorX + U.rnd(-12, 12), bd.y + 4, 4, ['#7a4a28', '#c43030'], 60, 0.4);
        }
      } else if (e.fly) {
        // unpredictable drifting ghost
        let a = Math.atan2(doorY - e.y, doorX - e.x) + Math.sin(e.t * 1.6 + e.seed) * 1.15 + Math.sin(e.t * 0.7 + e.seed * 2) * 0.6;
        if (chase) a = Math.atan2(PL.y - e.y, PL.x - e.x) + Math.sin(e.t * 3) * 0.5;
        e.dashCd -= dt; if (e.dashCd <= 0) { e.dashCd = U.rnd(2.5, 5); e.dash = 0.45; }
        e.dash -= dt; const sm = e.dash > 0 ? 2.6 : 1;
        vx = Math.cos(a) * sp * sm; vy = Math.sin(a) * sp * sm;
        e.ph = (Math.sin(e.t * 0.9 + e.seed) + 1) / 2;
      } else {
        let dx, dy;
        if (chase) { dx = PL.x - e.x; dy = PL.y - e.y; const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l; }
        else { const d = F.flowDir(e.x, e.y); dx = d.x; dy = d.y; }
        if (e.nudge > 0) { e.nudge -= dt; dx = e.nx; dy = e.ny; }
        vx = dx * sp; vy = dy * sp;
        // stuck detection
        e.stuck += dt;
        if (e.stuck > 0.5) {
          if (U.dist(e.x, e.y, e.lx, e.ly) < 1.8 && !chase) { e.nudge = 0.5; const a = Math.random() * U.TAU; e.nx = Math.cos(a); e.ny = Math.sin(a); }
          e.lx = e.x; e.ly = e.y; e.stuck = 0;
        }
      }
      // separation
      if (!e.fly && !e.atBarn) {
        for (let j = 0; j < L.length; j++) {
          const o = L[j]; if (o === e || o.dead || o.fly) continue;
          const dx = e.x - o.x, dy = e.y - o.y, m = e.r + o.r - 2;
          if (Math.abs(dx) < m && Math.abs(dy) < m) { const d = Math.hypot(dx, dy) || 0.1; if (d < m) { const p = (m - d) * 0.5 * Math.min(1, dt * 14); vx += dx / d * p / dt * 0.12; vy += dy / d * p / dt * 0.12; } }
        }
      }
      e.kx *= Math.pow(0.02, dt); e.ky *= Math.pow(0.02, dt);
      const mvx = (e.atBarn ? 0 : vx) + e.kx, mvy = (e.atBarn ? 0 : vy) + e.ky;
      if (Math.abs(vx) + Math.abs(vy) > 1) { e.vx = U.lerp(e.vx, vx, Math.min(1, dt * 10)); e.vy = U.lerp(e.vy, vy, Math.min(1, dt * 10)); }
      if (e.fly) { e.x += mvx * dt; e.y += mvy * dt; e.x = U.clamp(e.x, 2, NW.W - 2); e.y = U.clamp(e.y, 2, NW.H - 2); }
      else {
        const hs = []; F.move(e, mvx * dt, mvy * dt, e.r, hs);
        if (hs.length) { for (let k = 0; k < hs.length; k++) { const s = hs[k]; if (!s.dead && (s.orig || s.solid)) { const away = Math.atan2(e.y - (s.y + s.h / 2), e.x - (s.x + s.w / 2)); if (vx * -Math.cos(away) + vy * -Math.sin(away) > -2 || true) { bite(e, s); break; } } } }
        // traps
        for (let k = 0; k < F.structs.length; k++) {
          const s = F.structs[k]; if (s.type !== 'trap' || s.uses <= 0 || e.trapCd > 0) continue;
          if (e.x > s.x - 2 && e.x < s.x + s.w + 2 && e.y > s.y - 2 && e.y < s.y + s.h + 2) {
            e.trapCd = 0.7; e.slow = 1.6; s.uses--; s.trig = 0.3;
            NW.audio.sfx('trap'); NW.fx.burst(e.x, e.y - 3, 6, ['#d8d8e8', '#c43030'], 60, 0.4);
            EN.damage(e, 18 + NW.game.night * 2, -Math.PI / 2, 10, { trap: true });
            if (s.uses <= 0) { F.removeStruct(s); NW.ui.toast('A trap was destroyed', 'bad'); }
            if (e.dead) break;
          }
        }
        if (e.dead) continue;
      }
      // contact with player
      if (playing && PL.alive && !e.atBarn) {
        const reach = e.r + PL.r + (e.d.boss ? 6 : 2);
        if (toP < reach + 1 && e.atkCd <= 0) { e.atkCd = e.d.rate; e.atk = 0.25; PL.hurt(e.dmg, e.x, e.y); if (e.fly) NW.audio.sfx('ghost'); }
      }
      // boss mechanics
      if (e.d.boss && playing) {
        e.slamT -= dt; e.summonT -= dt;
        if (e.slamT <= 0 && e.slamAnim <= 0) { e.slamAnim = 0.7; e.slamT = 6; NW.audio.sfx('growl'); }
        if (e.slamAnim > 0) {
          e.slamAnim -= dt;
          if (e.slamAnim <= 0) {
            NW.game.shake(9); NW.audio.sfx('boom'); NW.fx.ring(e.x, e.y, 70);
            NW.fx.burst(e.x, e.y, 24, ['#e8741e', '#6a4a2e', '#ffd23a'], 140, 0.8);
            if (U.dist(e.x, e.y, PL.x, PL.y) < 62) PL.hurt(e.dmg * 0.8, e.x, e.y);
            F.structs.slice().forEach(s => { if (s.type !== 'trap' && U.dist(e.x, e.y, s.x + s.w / 2, s.y + s.h / 2) < 52) F.damageStruct(s, 70); });
          }
        }
        if (e.summonT <= 0) { e.summonT = 10; for (let k = 0; k < 2; k++) { const f = EN.spawn('fast', 'S'); f.x = e.x + U.rnd(-16, 16); f.y = e.y + U.rnd(-6, 16); f.reward = 3; } }
      }
      // dynamic eye-glow light
      if (!e.fly) NW.fx.addLight(e.x, e.y - e.r, e.type === 'zombie' ? 20 : 30 + e.r, e.type === 'zombie' ? '255,70,70' : '255,170,50', e.type === 'zombie' ? 0.35 : 0.55, 0.02);
      else NW.fx.addLight(e.x, e.y - 8, 34, '150,200,255', 0.5 * (1 - e.ph * 0.7), 0.02);
    }
  };

  /* ---------------- drawing ---------------- */
  function Rf(g, F_, c, x, y, w, h) { R(g, F_ ? '#ffffff' : c, Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h))); }
  function Ef(g, F_, c, x, y, rx, ry) { U.ell(g, F_ ? '#ffffff' : c, Math.round(x), Math.round(y), Math.max(1, Math.round(rx)), Math.max(1, Math.round(ry))); }

  function drawPumpkin(g, e, x, y, k, opt) {
    const Fl = e.flash > 0, front = e.fy >= -0.1, w = Math.sin(e.t * e.wspd * (opt.fast ? 1.6 : 1)), leg = Math.round(w * 2 * k);
    const orange = opt.col || '#e8741e', dark = opt.dark || '#b8500f', lite = opt.lite || '#ff9a2e', eye = opt.eye || '#ffd43a';
    const squash = e.atk > 0 ? 1 + e.atk * 0.8 : 1;
    // legs
    Rf(g, Fl, OUT, x - 5 * k, y - 5 * k + leg, 4 * k, 5 * k + 1); Rf(g, Fl, '#6a4a30', x - 4 * k, y - 4 * k + leg, 2 * k, 4 * k);
    Rf(g, Fl, OUT, x + 1 * k, y - 5 * k - leg, 4 * k, 5 * k + 1); Rf(g, Fl, '#6a4a30', x + 2 * k, y - 4 * k - leg, 2 * k, 4 * k);
    const by = y - 10 * k, rx = 9 * k, ry = 8 * k * (1 / squash) + (e.atk > 0 ? 0 : 0);
    // arms
    const arm = Math.round(-w * 2 * k) + (e.atk > 0 ? -3 * k : 0);
    Rf(g, Fl, OUT, x - rx - 3 * k, by + arm - 1, 4 * k, 7 * k); Rf(g, Fl, '#7a5436', x - rx - 2 * k, by + arm, 2 * k, 5 * k);
    Rf(g, Fl, OUT, x + rx - 1 * k, by - arm - 1, 4 * k, 7 * k); Rf(g, Fl, '#7a5436', x + rx, by - arm, 2 * k, 5 * k);
    // body
    Ef(g, Fl, OUT, x, by, rx + 1, ry + 1); Ef(g, Fl, dark, x, by, rx, ry); Ef(g, Fl, orange, x, by - 1, rx - 1 * k, ry - 1 * k); Ef(g, Fl, lite, x - rx / 3, by - ry / 2.2, rx / 3, ry / 3.5);
    Rf(g, Fl, dark, x - rx * 0.55, by - ry * 0.7, 1, ry * 1.4); Rf(g, Fl, dark, x + rx * 0.55, by - ry * 0.7, 1, ry * 1.4); Rf(g, Fl, dark, x, by - ry + 1, 1, ry * 2 - 2);
    // stem
    Rf(g, Fl, OUT, x - 2 * k, by - ry - 4 * k, 5 * k, 5 * k); Rf(g, Fl, '#4a7a2a', x - 1 * k, by - ry - 3 * k, 3 * k, 4 * k); Rf(g, Fl, '#7aaa4a', x - 1 * k, by - ry - 3 * k, 1, 3 * k);
    if (front && !Fl) {
      Rf(g, false, eye, x - 5 * k, by - 3 * k, 3 * k, 3 * k); Rf(g, false, eye, x + 2 * k, by - 3 * k, 3 * k, 3 * k);
      Rf(g, false, '#fff6b0', x - 4 * k, by - 2 * k, k, k); Rf(g, false, '#fff6b0', x + 3 * k, by - 2 * k, k, k);
      Rf(g, false, OUT, x - 4 * k, by + 2 * k, 8 * k, 3 * k); Rf(g, false, eye, x - 3 * k, by + 3 * k, 6 * k, k);
      Rf(g, false, OUT, x - 2 * k, by + 2 * k, k, 2 * k); Rf(g, false, OUT, x + 1 * k, by + 2 * k, k, 2 * k);
      if (opt.angry) { Rf(g, false, OUT, x - 6 * k, by - 5 * k, 4 * k, k); Rf(g, false, OUT, x + 2 * k, by - 5 * k, 4 * k, k); }
    }
    if (opt.cracks) { U.line(g, OUT, x - 2 * k, by - ry + 2, x + 1 * k, by - 1, 1); U.line(g, OUT, x + 5 * k, by - 2 * k, x + 2 * k, by + 4 * k, 1); }
    if (opt.crown) {
      const cy2 = by - ry - 5 * k; Rf(g, Fl, OUT, x - 8 * k, cy2 - 2, 16 * k, 6 * k); Rf(g, Fl, '#ffd23a', x - 7 * k, cy2 - 1, 14 * k, 4 * k);
      for (let q = -7; q <= 5; q += 4) { Rf(g, Fl, OUT, x + q * k - 1, cy2 - 7, 5, 6); Rf(g, Fl, '#ffd23a', x + q * k, cy2 - 6, 3, 5); }
      Rf(g, Fl, '#c43030', x - 1, cy2, 3, 2); Rf(g, Fl, '#9ad0ff', x - 5 * k, cy2, 2, 2); Rf(g, Fl, '#7dff7a', x + 4 * k, cy2, 2, 2);
    }
  }

  function drawZombie(g, e, x, y) {
    const Fl = e.flash > 0, w = Math.sin(e.t * 6), leg = Math.round(w * 2);
    const side = Math.abs(e.vx) > Math.abs(e.vy) * 1.2, d = e.vx >= 0 ? 1 : -1, front = e.fy >= 0;
    // legs
    Rf(g, Fl, OUT, x - 5, y - 8 + (leg > 0 ? 1 : 0), 4, 9); Rf(g, Fl, '#2f4a8a', x - 4, y - 8, 2, 7 + (leg > 0 ? 0 : 1)); Rf(g, Fl, '#1a1210', x - 5, y, 4, 1);
    Rf(g, Fl, OUT, x + 1, y - 8 + (leg < 0 ? 1 : 0), 4, 9); Rf(g, Fl, '#2f4a8a', x + 2, y - 8, 2, 7 + (leg < 0 ? 0 : 1)); Rf(g, Fl, '#1a1210', x + 1, y, 4, 1);
    // torso
    const ty = y - 18 + Math.round(Math.abs(w) * -1);
    Rf(g, Fl, OUT, x - 6, ty - 1, 12, 12); Rf(g, Fl, '#a83a3a', x - 5, ty, 10, 10); Rf(g, Fl, '#7a2a2a', x - 5, ty + 3, 10, 1); Rf(g, Fl, '#7a2a2a', x - 2, ty, 1, 10);
    if (front) { Rf(g, Fl, '#2f4a8a', x - 3, ty + 4, 6, 7); Rf(g, Fl, '#c8a030', x - 3, ty + 4, 1, 1); Rf(g, Fl, '#c8a030', x + 2, ty + 4, 1, 1); }
    else { Rf(g, Fl, '#2f4a8a', x - 4, ty + 6, 8, 5); }
    // arms outstretched
    const ar = Math.round(Math.sin(e.t * 5) * 1.5) + (e.atk > 0 ? 2 : 0);
    if (side) { Rf(g, Fl, OUT, x + d * 4 - (d < 0 ? 7 : 0), ty + 2 + ar, 9, 4); Rf(g, Fl, '#7a9a5a', x + d * 4 + (d < 0 ? -6 : 1), ty + 3 + ar, 7, 2); Rf(g, Fl, '#a83a3a', x + d * 3 - (d < 0 ? 1 : 0), ty + 3 + ar, 2, 2); }
    else if (front) { Rf(g, Fl, OUT, x - 9, ty + 3, 4, 8 + ar); Rf(g, Fl, '#7a9a5a', x - 8, ty + 7, 2, 4 + ar); Rf(g, Fl, '#a83a3a', x - 8, ty + 3, 2, 4); Rf(g, Fl, OUT, x + 5, ty + 3, 4, 8 - ar); Rf(g, Fl, '#7a9a5a', x + 6, ty + 7, 2, 4 - ar); Rf(g, Fl, '#a83a3a', x + 6, ty + 3, 2, 4); }
    else { Rf(g, Fl, OUT, x - 9, ty, 4, 7); Rf(g, Fl, '#7a9a5a', x - 8, ty, 2, 4); Rf(g, Fl, OUT, x + 5, ty, 4, 7); Rf(g, Fl, '#7a9a5a', x + 6, ty, 2, 4); }
    // head + hat
    const hy = ty - 8;
    Rf(g, Fl, OUT, x - 5, hy, 10, 9); Rf(g, Fl, '#7a9a5a', x - 4, hy + 1, 8, 7);
    if (front) { Rf(g, Fl, '#d62a2a', x - 3, hy + 3, 2, 2); Rf(g, Fl, '#d62a2a', x + 1, hy + 3, 2, 2); Rf(g, Fl, '#fff', x - 3, hy + 3, 1, 1); Rf(g, Fl, OUT, x - 2, hy + 6, 4, 1); Rf(g, Fl, '#4a6a3a', x - 4, hy + 5, 1, 2); }
    else if (side) { Rf(g, Fl, '#d62a2a', x + d * 2 - 1, hy + 3, 2, 2); Rf(g, Fl, OUT, x + d * 2, hy + 6, 2, 1); }
    Rf(g, Fl, OUT, x - 8, hy - 1, 16, 3); Rf(g, Fl, '#6a4a2a', x - 7, hy, 14, 2); Rf(g, Fl, OUT, x - 4, hy - 5, 8, 5); Rf(g, Fl, '#7a5a34', x - 3, hy - 4, 6, 4); Rf(g, Fl, '#3a2a18', x - 3, hy - 1, 6, 1);
  }

  function drawGhost(g, e, x, y) {
    const Fl = e.flash > 0, t = e.t, a = U.clamp((1 - e.ph * 0.85) * (e.spawnT > 0 ? 1 - e.spawnT / 0.7 : 1), 0.1, 1) * 0.82;
    const fy = y - 10 + Math.round(Math.sin(t * 2.2) * 3);
    g.globalAlpha = 0.25 * a; U.ell(g, '#000', x, y + 2, 8, 3);
    g.globalAlpha = a * 0.35; U.disc(g, '#9ad0ff', x, fy, 14);
    g.globalAlpha = a;
    const body = Fl ? '#fff' : '#dfeaff', sh = Fl ? '#fff' : '#a8bce8';
    U.disc(g, sh, x, fy - 3, 8); U.disc(g, body, x - 1, fy - 4, 7);
    for (let i = -7; i <= 7; i++) { const h = 8 + Math.round(Math.sin(t * 5 + i * 0.9) * 2) + (Math.abs(i) > 5 ? -3 : 0); R(g, i > 3 ? sh : body, x + i, fy - 3, 1, h); }
    R(g, '#1a1c3a', x - 4, fy - 6, 3, 4); R(g, '#1a1c3a', x + 1, fy - 6, 3, 4); R(g, '#1a1c3a', x - 2, fy + 1, 4, 3);
    const arm = Math.round(Math.sin(t * 3) * 2); R(g, body, x - 10, fy + arm, 3, 5); R(g, body, x + 8, fy - arm, 3, 5);
    g.globalAlpha = 1;
  }

  EN.drawOne = function (g, e) {
    const x = Math.round(e.x), y = Math.round(e.y);
    if (Math.abs(e.vy) > 2 || Math.abs(e.vx) < 2) e.fy = e.vy;
    let alpha = 1, sc = 1;
    if (e.dead) { alpha = U.clamp(e.deathT / 0.4, 0, 1); sc = 0.4 + alpha * 0.6; g.globalAlpha = alpha; }
    else if (e.spawnT > 0 && !e.fly) g.globalAlpha = 1 - e.spawnT / 0.7;
    U.ell(g, 'rgba(0,0,0,0.38)', x, y + 1, e.r + 2, Math.max(2, e.r * 0.4));
    const type = e.type;
    if (type === 'pumpkin') drawPumpkin(g, e, x, y, 1, {});
    else if (type === 'fast') drawPumpkin(g, e, x, y, 0.65, { col: '#f0501a', dark: '#a82a10', lite: '#ff8a3a', eye: '#fff06a', fast: true, angry: true });
    else if (type === 'big') drawPumpkin(g, e, x, y, 1.6, { col: '#cf5a1a', dark: '#8a3410', lite: '#f08a2a', eye: '#ff5a2a', cracks: true, angry: true });
    else if (type === 'king') {
      const slam = e.slamAnim > 0 ? Math.sin((1 - e.slamAnim / 0.7) * 3.14) : 0;
      g.globalAlpha = 0.18; U.disc(g, '#b45cff', x, y - 18, 28); g.globalAlpha = alpha;
      drawPumpkin(g, e, x, y - Math.round(slam * 6), 2.1, { col: '#c0481a', dark: '#6a2410', lite: '#e87a2a', eye: '#ff3a3a', cracks: true, angry: true, crown: true });
    } else if (type === 'zombie') drawZombie(g, e, x, y);
    else drawGhost(g, e, x, y);
    g.globalAlpha = 1;
    if (!e.dead && e.hp < e.max && !e.d.boss) {
      const w = Math.max(10, e.r * 2 + 2), bx = x - w / 2, by = y - e.r * 2 - (type === 'zombie' ? 14 : 9) - (type === 'big' ? 6 : 0);
      R(g, '#000', bx - 1, by - 1, w + 2, 4); R(g, '#5a1a1a', bx, by, w, 2); R(g, e.fly ? '#9ad0ff' : '#e8452a', bx, by, Math.max(1, Math.round(w * e.hp / e.max)), 2);
    }
  };
  EN.sortedList = function () { return EN.list.slice().sort((a, b) => a.y - b.y); };
})();
