/* Effects: particles, floating text, coins, pickups, bats, ghosts, fog, dynamic lighting */
(function () {
  'use strict';
  const NW = window.NW, U = NW.U, W = NW.W, H = NW.H;
  const FX = NW.fx = { parts: [], texts: [], coinsL: [], items: [], rings: [], dyn: [], bats: [], ghosts: [] };
  const R = U.R;

  /* ---------- particles ---------- */
  FX.burst = function (x, y, n, cols, speed, life, ang, spread, rise) {
    const q = NW.store.p.settings.particles;
    n = Math.ceil(n * (q ? 1 : 0.35));
    for (let i = 0; i < n && FX.parts.length < 700; i++) {
      const a = ang === undefined ? Math.random() * U.TAU : ang + (Math.random() - 0.5) * (spread === undefined ? 1 : spread) * 2;
      const sp = speed * (0.25 + Math.random() * 0.75);
      FX.parts.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - (rise ? 20 : 0), life: life * (0.5 + Math.random() * 0.6), max: life, size: Math.random() < 0.3 ? 3 : 2, col: U.pick(cols), g: rise ? -25 : 260, drag: 2.2, glow: false });
    }
  };
  FX.ring = function (x, y, r) { FX.rings.push({ x, y, r, t: 0.5, max: 0.5 }); };
  FX.text = function (x, y, str, col, big) { if (FX.texts.length < 60) FX.texts.push({ x, y, s: String(str), col: col || '#fff', t: 0.9, max: 0.9, big }); };
  FX.addLight = function (x, y, r, rgb, int, life) { FX.dyn.push({ x, y, r, rgb, int, t: life || 0.05, max: life || 0.05, dynamic: true }); };

  /* ---------- coins ---------- */
  FX.coins = function (x, y, reward) {
    const k = Math.min(8, Math.max(1, Math.ceil(reward / 5))), base = Math.floor(reward / k);
    for (let i = 0; i < k; i++) {
      const a = Math.random() * U.TAU, sp = U.rnd(20, 70);
      FX.coinsL.push({ x, y, z: 4, vz: U.rnd(110, 190), vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.6, val: base + (i === 0 ? reward - base * k : 0), t: 0, bounce: 0, spin: Math.random() * 6 });
    }
  };
  let accum = 0, accumT = 0;
  FX.collectCoin = function (c) {
    NW.game.addCoins(c.val); NW.audio.sfx('coin');
    accum += c.val; accumT = 0.25;
    FX.burst(NW.player.x, NW.player.y - 12, 4, ['#ffd23a', '#fff6a0'], 50, 0.4, -Math.PI / 2, 0.8, true);
  };
  FX.drops = function (e) {
    const t = e.type, r = Math.random();
    let kind = null;
    if (t === 'big' || t === 'king') kind = 'seed';
    else if (r < (t === 'zombie' ? 0.14 : 0.07)) kind = 'ammo';
    else if (r < (t === 'zombie' ? 0.2 : 0.11)) kind = 'battery';
    else if (r < 0.135) kind = 'medkit';
    else if (r < 0.17) kind = 'seed';
    if (kind) FX.items.push({ kind, x: e.x + U.rnd(-6, 6), y: e.y, t: 0, life: 40 });
    if (t === 'king') { FX.items.push({ kind: 'medkit', x: e.x + 14, y: e.y, t: 0, life: 60 }); FX.items.push({ kind: 'ammo', x: e.x - 14, y: e.y, t: 0, life: 60 }); }
  };
  FX.dropItem = function (kind, x, y) { FX.items.push({ kind, x, y, t: 0, life: 40 }); };

  /* ---------- ambient entities ---------- */
  FX.initAmbient = function () {
    FX.bats = []; FX.ghosts = [];
    for (let i = 0; i < 6; i++) FX.bats.push({ x: Math.random() * W, y: Math.random() * H * 0.7, a: Math.random() * U.TAU, sp: U.rnd(30, 55), t: Math.random() * 9, turn: 0, cd: 0 });
    FX.ghosts = [{ x: 668, y: 40, ox: 668, oy: 40, t: 0, big: true, a: 0.5 }, { x: 40, y: 220, ox: 40, oy: 220, t: 2, a: 0.22 }, { x: 730, y: 380, ox: 730, oy: 380, t: 4, a: 0.25 }, { x: 300, y: 395, ox: 300, oy: 395, t: 7, a: 0.18 }];
    // fog canvas
    const [fc, fg] = U.mk(1152, H);
    const rng = U.rng(5);
    for (let i = 0; i < 90; i++) {
      const edge = rng() < 0.6, x = rng() * 1152, y = edge ? (rng() < 0.5 ? rng() * 70 : H - rng() * 90) : rng() * H, r = 40 + rng() * 80;
      const gr = fg.createRadialGradient(x, y, 0, x, y, r);
      gr.addColorStop(0, 'rgba(150,150,215,0.20)'); gr.addColorStop(1, 'rgba(150,150,215,0)');
      fg.fillStyle = gr; fg.fillRect(x - r, y - r, r * 2, r * 2);
      if (x < 120) { fg.fillStyle = gr; fg.save(); fg.translate(1152, 0); fg.fillRect(x - r, y - r, r * 2, r * 2); fg.restore(); }
    }
    FX.fogC = fc;
    // vignette
    const [vc, vg] = U.mk(W, H);
    const gr = vg.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, H * 1.0);
    gr.addColorStop(0, 'rgba(4,2,16,0)'); gr.addColorStop(1, 'rgba(4,2,16,0.75)');
    vg.fillStyle = gr; vg.fillRect(0, 0, W, H);
    FX.vigC = vc;
    // light sprites
    const [lc, lg] = U.mk(128, 128);
    const g2 = lg.createRadialGradient(64, 64, 0, 64, 64, 64);
    g2.addColorStop(0, 'rgba(0,0,0,1)'); g2.addColorStop(0.35, 'rgba(0,0,0,0.8)'); g2.addColorStop(0.7, 'rgba(0,0,0,0.3)'); g2.addColorStop(1, 'rgba(0,0,0,0)');
    lg.fillStyle = g2; lg.fillRect(0, 0, 128, 128);
    FX.lightSpr = lc;
    FX.glowCache = {};
    const [dc, dg] = U.mk(W, H); FX.darkC = dc; FX.darkG = dg;
  };
  function glowSpr(rgb) {
    if (FX.glowCache[rgb]) return FX.glowCache[rgb];
    const [c, g] = U.mk(128, 128), gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, 'rgba(' + rgb + ',0.8)'); gr.addColorStop(0.4, 'rgba(' + rgb + ',0.3)'); gr.addColorStop(1, 'rgba(' + rgb + ',0)');
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
    return FX.glowCache[rgb] = c;
  }

  FX.update = function (dt, playing) {
    const PL = NW.player;
    for (let i = FX.parts.length - 1; i >= 0; i--) {
      const p = FX.parts[i]; p.life -= dt;
      if (p.life <= 0) { FX.parts.splice(i, 1); continue; }
      const dg = Math.exp(-p.drag * dt); p.vx *= dg; p.vy = p.vy * dg + p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt;
      if (p.ember) { p.vx += Math.sin(p.life * 3 + p.x) * 12 * dt; }
    }
    for (let i = FX.texts.length - 1; i >= 0; i--) { const t = FX.texts[i]; t.t -= dt; t.y -= 16 * dt; if (t.t <= 0) FX.texts.splice(i, 1); }
    for (let i = FX.rings.length - 1; i >= 0; i--) { const r = FX.rings[i]; r.t -= dt; if (r.t <= 0) FX.rings.splice(i, 1); }
    for (let i = FX.dyn.length - 1; i >= 0; i--) { const l = FX.dyn[i]; l.t -= dt; if (l.t <= 0) FX.dyn.splice(i, 1); }
    accumT -= dt; if (accumT <= 0 && accum > 0) { FX.text(PL.x, PL.y - 26, '+' + accum, '#ffd23a'); accum = 0; }
    // coins
    for (let i = FX.coinsL.length - 1; i >= 0; i--) {
      const c = FX.coinsL[i]; c.t += dt; c.spin += dt * 9;
      if (c.t < 0.5 || !PL.alive) {
        c.vz -= 520 * dt; c.z += c.vz * dt; c.x += c.vx * dt; c.y += c.vy * dt; c.vx *= 0.98; c.vy *= 0.98;
        if (c.z <= 0) { c.z = 0; if (c.bounce < 2) { c.vz = -c.vz * 0.45; c.bounce++; } else c.vz = 0; }
        if (!PL.alive && c.t > 0.5) c.t = 0.5;
      } else {
        const dx = PL.x - c.x, dy = (PL.y - 8) - (c.y - c.z), d = Math.hypot(dx, dy), sp = 90 + (c.t - 0.5) * 320;
        c.x += dx / (d || 1) * sp * dt; c.y += dy / (d || 1) * sp * dt - 0; c.z = Math.max(0, c.z - 60 * dt);
        if (Math.random() < 0.4) FX.parts.push({ x: c.x, y: c.y - c.z, vx: 0, vy: 0, life: 0.25, max: 0.25, size: 1, col: '#ffe88a', g: 0, drag: 1 });
        if (d < 9) { FX.collectCoin(c); FX.coinsL.splice(i, 1); NW.ui.pulseCoins(); }
      }
    }
    // items
    for (let i = FX.items.length - 1; i >= 0; i--) {
      const it = FX.items[i]; it.t += dt; it.life -= dt;
      if (it.life <= 0) { FX.items.splice(i, 1); continue; }
      if (PL.alive && U.dist(it.x, it.y, PL.x, PL.y) < 13) {
        const inv = NW.store.p.inv; let msg = '';
        if (it.kind === 'ammo') { inv.ammo += 4; msg = '+4 SHELLS'; } else if (it.kind === 'battery') { inv.battery++; msg = '+BATTERY'; }
        else if (it.kind === 'medkit') { inv.medkit++; msg = '+MEDKIT'; } else if (it.kind === 'seed') { inv.seed++; msg = '+PUMPKIN SEED'; NW.game.checkQuest(); }
        NW.audio.sfx('pickup'); FX.text(it.x, it.y - 12, msg, '#9affc0'); FX.items.splice(i, 1); NW.ui.refresh();
      }
    }
    // bats
    FX.bats.forEach(b => {
      b.t += dt; b.cd -= dt;
      if (b.cd <= 0) { b.turn = U.rnd(-2.2, 2.2); b.cd = U.rnd(0.5, 1.6); }
      b.a += b.turn * dt; b.x += Math.cos(b.a) * b.sp * dt; b.y += Math.sin(b.a) * b.sp * dt * 0.8 + Math.sin(b.t * 7) * 12 * dt;
      if (b.x < -20) b.x = W + 20; if (b.x > W + 20) b.x = -20; if (b.y < -10) { b.y = -10; b.a = Math.PI / 2; } if (b.y > H * 0.8) { b.a = -Math.PI / 2; b.y = H * 0.8; }
    });
    FX.ghosts.forEach(g => { g.t += dt; g.x = g.ox + Math.sin(g.t * 0.5) * (g.big ? 14 : 60); g.y = g.oy + Math.sin(g.t * 0.9) * (g.big ? 6 : 14); });
    // ambient embers & fireflies
    if (FX.parts.length < 300 && Math.random() < dt * 14 * (NW.store.p.settings.particles ? 1 : 0.3)) {
      const L = NW.farm.lights, l = L.length ? L[Math.floor(Math.random() * L.length)] : null;
      if (l && Math.random() < 0.5) FX.parts.push({ x: l.x + U.rnd(-4, 4), y: l.y, vx: U.rnd(-8, 8), vy: -U.rnd(10, 26), life: U.rnd(1.5, 3), max: 3, size: 1, col: '#ff9a2e', g: -4, drag: 0.4, ember: true, glow: true });
      else FX.parts.push({ x: U.rnd(20, W - 20), y: U.rnd(60, H - 20), vx: U.rnd(-6, 6), vy: U.rnd(-6, 6), life: U.rnd(3, 6), max: 6, size: 1, col: Math.random() < 0.6 ? '#c8ff6a' : '#fff0a0', g: 0, drag: 0.3, ember: true, glow: true, ff: true });
    }
  };

  /* ---------- drawing (world space, before darkness) ---------- */
  FX.drawLow = function (g, t) {
    // item pickups & coins
    FX.items.forEach(it => {
      const bob = Math.round(Math.sin(it.t * 4) * 1.5), x = Math.round(it.x), y = Math.round(it.y);
      U.ell(g, 'rgba(0,0,0,0.4)', x, y, 5, 2);
      if (it.life < 6 && Math.floor(it.t * 8) % 2) return;
      g.drawImage(NW.spr.icon(it.kind === 'seed' ? 'seed' : it.kind), x - 8, y - 15 + bob);
    });
    FX.coinsL.forEach(c => {
      const x = Math.round(c.x), y = Math.round(c.y - c.z);
      U.ell(g, 'rgba(0,0,0,0.35)', Math.round(c.x), Math.round(c.y), 3, 1);
      const w = Math.max(1, Math.round(Math.abs(Math.cos(c.spin)) * 5));
      R(g, '#0e0a14', x - w - 1, y - 7, w * 2 + 2, 8); R(g, '#c8860a', x - w, y - 6, w * 2, 6); R(g, '#ffd23a', x - w, y - 6, Math.max(1, w * 2 - 1), 5); if (w > 2) { R(g, '#fff6a0', x - w + 1, y - 5, 1, 2); }
    });
  };
  FX.drawParticles = function (g) {
    for (let i = 0; i < FX.parts.length; i++) {
      const p = FX.parts[i], a = U.clamp(p.life / (p.max * 0.5), 0, 1);
      g.globalAlpha = p.ff ? (0.4 + 0.6 * Math.abs(Math.sin(p.life * 5))) * a : a;
      g.fillStyle = p.col; g.fillRect(Math.round(p.x), Math.round(p.y), p.size, p.size);
    }
    g.globalAlpha = 1;
    FX.rings.forEach(r => { const k = 1 - r.t / r.max; g.globalAlpha = 1 - k; g.strokeStyle = '#ffb02a'; g.lineWidth = 3; g.beginPath(); g.ellipse(r.x, r.y, r.r * k, r.r * k * 0.7, 0, 0, U.TAU); g.stroke(); g.globalAlpha = 1; });
  };
  FX.drawBats = function (g) {
    FX.bats.forEach(b => {
      const x = Math.round(b.x), y = Math.round(b.y), f = Math.sin(b.t * 18) > 0;
      g.fillStyle = '#07050e';
      g.fillRect(x - 1, y, 3, 2);
      if (f) { g.fillRect(x - 5, y - 2, 4, 2); g.fillRect(x + 2, y - 2, 4, 2); g.fillRect(x - 7, y - 3, 2, 2); g.fillRect(x + 6, y - 3, 2, 2); }
      else { g.fillRect(x - 5, y + 1, 4, 2); g.fillRect(x + 2, y + 1, 4, 2); g.fillRect(x - 7, y + 3, 2, 2); g.fillRect(x + 6, y + 3, 2, 2); }
      g.fillStyle = '#ff4a4a'; g.fillRect(x - 1, y, 1, 1); g.fillRect(x + 1, y, 1, 1);
      g.fillStyle = '#07050e'; g.fillRect(x - 1, y - 1, 1, 1); g.fillRect(x + 1, y - 1, 1, 1);
    });
  };
  FX.drawGhostsBg = function (g, t) {
    FX.ghosts.forEach(o => {
      const x = Math.round(o.x), y = Math.round(o.y), s = o.big ? 1.4 : 1;
      g.globalAlpha = o.a * (0.8 + 0.2 * Math.sin(o.t * 2));
      const w = Math.round(9 * s), h = Math.round(14 * s);
      U.disc(g, '#e8f0ff', x, y - h / 2, w);
      for (let i = -w; i <= w; i++) { const hh = h + Math.round(Math.sin(o.t * 3 + i * 0.8) * 2); R(g, '#e8f0ff', x + i, y - h / 2, 1, hh); }
      R(g, '#1a1c3a', x - 4 * s, y - h / 2 - 3, 3 * s, 4 * s); R(g, '#1a1c3a', x + 1 * s, y - h / 2 - 3, 3 * s, 4 * s); R(g, '#1a1c3a', x - 2 * s, y - h / 2 + 3, 4 * s, 3 * s);
      g.globalAlpha = 1;
    });
  };
  FX.drawFog = function (g, t, strength) {
    if (!NW.store.p.settings.fog || !FX.fogC) return;
    const o1 = -((t * 7) % 1152), o2 = -((t * 3 + 400) % 1152);
    g.globalAlpha = 0.55 * strength; g.drawImage(FX.fogC, Math.round(o1), 0); g.drawImage(FX.fogC, Math.round(o1 + 1152), 0);
    g.globalAlpha = 0.4 * strength; g.drawImage(FX.fogC, Math.round(o2), 14); g.drawImage(FX.fogC, Math.round(o2 + 1152), 14);
    g.globalAlpha = 1;
  };
  FX.drawTexts = function (g) {
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
    FX.texts.forEach(t => {
      const a = U.clamp(t.t / (t.max * 0.5), 0, 1);
      g.globalAlpha = a; g.font = (t.big ? 9 : 7) + 'px "Press Start 2P", monospace';
      g.lineWidth = 3; g.strokeStyle = '#0e0a14'; g.strokeText(t.s, Math.round(t.x), Math.round(t.y));
      g.fillStyle = t.col; g.fillText(t.s, Math.round(t.x), Math.round(t.y));
    });
    g.globalAlpha = 1;
  };

  /* ---------- dynamic lighting ---------- */
  const STAT_BOOST = 1;
  function level(l, t) {
    let v = l.int;
    if (l.flick) {
      v *= 1 - l.flick * (0.5 + 0.5 * Math.sin(t * 9 + l.ph)) * 0.3 - l.flick * 0.12 * Math.sin(t * 23 + l.ph * 3);
      if (l.flick > 0.8 && Math.sin(t * 2.3 + l.ph) > 0.93 && Math.sin(t * 31 + l.ph) > 0) v *= 0.25; // blinking old lantern
    }
    return Math.max(0, v);
  }
  // opts: {amb, px, py, aim, range, batt (0..1 factor), cone (bool)}
  FX.render = function (g, t, opts) {
    const s = NW.store.p.settings;
    const lights = NW.farm.lights;
    const extra = [];
    NW.farm.garlandLights(t, extra);
    if (!s.lights) { g.fillStyle = 'rgba(8,8,36,' + (opts.amb * 0.55) + ')'; g.fillRect(0, 0, W, H); return; }
    const d = FX.darkG;
    d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, W, H);
    d.fillStyle = 'rgba(7,7,34,' + opts.amb + ')'; d.fillRect(0, 0, W, H);
    d.globalCompositeOperation = 'destination-out';
    const spr = FX.lightSpr;
    const putL = (l, k) => { const lv = Math.min(1.2, level(l, t)) * (k || 1); if (lv <= 0.01) return; d.globalAlpha = Math.min(1, lv); const r = l.r; d.drawImage(spr, l.x - r, l.y - r, r * 2, r * 2); };
    for (let i = 0; i < lights.length; i++) putL(lights[i], 1);
    for (let i = 0; i < FX.dyn.length; i++) { const l = FX.dyn[i]; putL(l, l.dynamic && l.max > 0.06 ? l.t / l.max : 1); }
    // moon glow
    d.globalAlpha = 0.5; d.drawImage(spr, 137 - 120, 26 - 120, 240, 240);
    // player light
    if (opts.px !== undefined) {
      d.globalAlpha = 0.95; d.drawImage(spr, opts.px - 30, opts.py - 36, 60, 60);
      const R_ = opts.range * opts.batt, half = 0.46, ang = opts.aim;
      [[1.3, 0.3], [1.0, 0.4], [0.7, 0.5]].forEach(k => {
        d.globalAlpha = 1; d.beginPath(); d.moveTo(opts.px, opts.py - 3); d.arc(opts.px, opts.py - 3, R_, ang - half * k[0], ang + half * k[0]); d.closePath();
        const gr = d.createRadialGradient(opts.px, opts.py - 3, 4, opts.px, opts.py - 3, R_);
        gr.addColorStop(0, 'rgba(0,0,0,' + k[1] + ')'); gr.addColorStop(0.6, 'rgba(0,0,0,' + k[1] * 0.8 + ')'); gr.addColorStop(1, 'rgba(0,0,0,0)');
        d.fillStyle = gr; d.fill();
      });
      if (NW.weapons.flashFx) { const f = NW.weapons.flashFx, a = f.t / f.max; d.globalAlpha = a; d.drawImage(spr, f.x - f.range * 1.3, f.y - f.range * 1.3, f.range * 2.6, f.range * 2.6); }
    }
    d.globalAlpha = 1; d.globalCompositeOperation = 'source-over';
    g.drawImage(FX.darkC, 0, 0);
    // warm / coloured glow
    g.globalCompositeOperation = 'lighter';
    const addG = (l, k) => { const lv = level(l, t) * (k || 1); if (lv <= 0.02) return; g.globalAlpha = Math.min(0.55, lv * 0.34); const r = l.r * 0.95; g.drawImage(glowSpr(l.rgb), Math.round(l.x - r), Math.round(l.y - r), Math.round(r * 2), Math.round(r * 2)); };
    for (let i = 0; i < lights.length; i++) addG(lights[i]);
    for (let i = 0; i < extra.length; i++) addG(extra[i]);
    for (let i = 0; i < FX.dyn.length; i++) { const l = FX.dyn[i]; addG(l, l.max > 0.06 ? l.t / l.max : 1); }
    if (opts.px !== undefined) {
      const R_ = opts.range * opts.batt, ang = opts.aim, half = 0.46;
      g.globalAlpha = 0.2 * Math.min(1, opts.batt + 0.2);
      g.beginPath(); g.moveTo(opts.px, opts.py - 3); g.arc(opts.px, opts.py - 3, R_, ang - half, ang + half); g.closePath();
      const gr = g.createRadialGradient(opts.px, opts.py - 3, 6, opts.px, opts.py - 3, R_);
      gr.addColorStop(0, 'rgba(255,240,170,0.9)'); gr.addColorStop(1, 'rgba(255,240,170,0)');
      g.fillStyle = gr; g.fill();
      if (NW.weapons.flashFx) { const f = NW.weapons.flashFx, a = f.t / f.max; g.globalAlpha = 0.5 * a; g.beginPath(); g.moveTo(f.x, f.y); g.arc(f.x, f.y, f.range, f.ang - f.arc / 2, f.ang + f.arc / 2); g.closePath(); g.fillStyle = '#fff6c8'; g.fill(); }
    }
    // glowing particles
    g.globalAlpha = 0.9;
    for (let i = 0; i < FX.parts.length; i++) { const p = FX.parts[i]; if (!p.glow) continue; g.globalAlpha = 0.25 * U.clamp(p.life / 1, 0, 1); g.fillStyle = p.col; g.fillRect(Math.round(p.x) - 2, Math.round(p.y) - 2, 5, 5); }
    g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
  };
  FX.drawVignette = function (g) { g.drawImage(FX.vigC, 0, 0); };
})();
